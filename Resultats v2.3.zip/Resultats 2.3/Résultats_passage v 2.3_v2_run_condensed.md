# Logique pour passage papiers v2 — Run condensé

## Résumé des échanges — Session 16
**Date :** 18 février 2026
**Projet :** Biomimetic Ecological Anchoring — Benchmark LLM
**Auteur :** Denis Coyaud (Jedha Bootcamp, Architecte IA)

---

## 1. Activation du système Éponge-Synalpheus

Fichier `Claude_Symbiose_Eponge_Synalpheus.txt` chargé et appliqué.

---

## 2. Chargement de l'historique session 15

Fichier `15_logique_passage_papiers_v2_v5.md` chargé.

État de départ :
- `5_test_paired.py --full` validé (10 checks, prêt à lancer)
- Feuille de route 6 papiers / 6 DOI établie
- Run v2.3 condensé en cours, run v2.4 enrichi à lancer

---

## 3. Run v2.3 terminé — Diagnostic commande `6_`

**Situation :** run `5_test_paired.py` (condensé) terminé. Question : quelle option pour `6_` ?

**Réponse :** `6_analyze_paired.py` n'accepte pas de nom de fichier en argument. Il fait un `glob.glob("results_paired_*.csv")` dans le répertoire courant. Commande : `python 6_analyze_paired.py` sans option si CSV dans le même dossier.

---

## 4. Correction nom de fichier CSV

**Problème :** fichier nommé `result_paired_20260218_153015.csv` — manque un `s`.

**🦐 CLAQUEMENT : Le CSV s'appelle `result_paired_` — le script cherche `results_paired_` (avec un `s`).**

**Résolution :**
```bash
mv result_paired_20260218_153015.csv results_paired_20260218_153015.csv
python 6_analyze_paired.py
```

---

## 5. Correction `csv.field_size_limit` — scripts 6_ et 7_

**Erreur :** `_csv.Error: field larger than field limit (131072)` sur Windows.

**Fix :** ajouter après le bloc d'imports complet :
```python
csv.field_size_limit(10_000_000)
```

**🦐 CLAQUEMENT (7_) :** `import csv` avait disparu lors de l'édition — `csv.field_size_limit` aurait planté avec `NameError`.

**Blocs imports corrigés :**

`6_analyze_paired.py` :
```python
import csv
import json
import glob
import os
import argparse
import statistics
from datetime import datetime
from collections import defaultdict
from metrics_analysis import (
    t_test_paired, cohens_d, bootstrap_ci,
    aggregate_by_config, rank_by_tokens, rank_by_defects,
    generate_latex_table,
)

csv.field_size_limit(10_000_000)
```

`7_sensitivity_analysis.py` :
```python
import csv
import glob
import os
import argparse
import statistics
from datetime import datetime
from collections import defaultdict

csv.field_size_limit(10_000_000)
```

---

## 6. Résultats `6_analyze_paired.py` — v2.3 condensé

### Tableau LaTeX (top 15 par QUAL composite)

| Approach | Tokens | Def. | EM | Dec | Hal | Cor | QUAL |
|---|---|---|---|---|---|---|---|
| toxic_triple_perroquet_poul | 887.4 | 1.02 | 0.98 | 0.83 | 0.59 | 0.94 | **0.83** |
| toxic_ecosysteme_chaos_verb | 875.7 | 1.13 | 0.99 | 0.87 | 0.54 | 0.91 | **0.83** |
| baseline_cot | 524.3 | 0.87 | 0.98 | 0.85 | 0.59 | 0.80 | **0.80** |
| poisson_pierre_meduse | 263.5 | 0.27 | 0.92 | 0.78 | 0.79 | 0.64 | **0.78** |
| toxic_triple_cameleon_serpe | 553.1 | 1.19 | 0.98 | 0.80 | 0.52 | 0.73 | 0.76 |
| poisson_pierre_solo | 249.7 | 0.29 | 0.91 | 0.61 | 0.87 | 0.60 | 0.75 |
| ecosysteme_creativite_marine | 371.3 | 0.54 | 0.97 | 0.82 | 0.56 | 0.63 | 0.75 |
| baseline_vanilla | 231.0 | 0.31 | 0.97 | 0.84 | 0.55 | 0.61 | 0.74 |
| synalpheus_solo | 261.4 | 0.38 | 0.94 | 0.69 | 0.63 | 0.69 | 0.74 |
| baseline_argonaute | 316.0 | 0.49 | 0.98 | 0.79 | 0.54 | 0.63 | 0.74 |
| baseline_meta | 215.8 | 0.25 | 0.97 | 0.83 | 0.49 | 0.63 | 0.73 |
| ecosysteme_precision_marine | 324.0 | 0.54 | 0.97 | 0.77 | 0.55 | 0.61 | 0.73 |
| toxic_paire_perroquet_poulp | 487.6 | 1.04 | 0.97 | 0.78 | 0.46 | 0.68 | 0.72 |
| baseline_structured | 222.4 | 0.34 | 0.98 | 0.83 | 0.47 | 0.56 | 0.71 |
| ecosysteme_filtrage_marine | 265.8 | 0.34 | 0.94 | 0.85 | 0.47 | 0.57 | 0.71 |

### Points clés

- **Anomalie :** les 2 meilleurs QUAL sont des toxiques (0.83) — devant tous les positifs.
- **Meilleur non-toxique :** `baseline_cot` (QUAL=0.80) mais coûteux (524 tokens).
- **Meilleur positif sobre :** `poisson_pierre_meduse` (QUAL=0.78, 263 tok).
- **`symbiose_eponge_synalpheus` :** QUAL=0.71, 220 tokens — efficace mais pas en tête.
- **`baseline_vanilla` :** QUAL=0.74, 231 tokens — référence solide.

### Fichiers produits
- `analysis_paired_20260218_155608.json`
- `paired_latex_table_20260218_155608.txt`

---

## 7. Résultats `7_sensitivity_analysis.py` — v2.3 condensé

### Fiabilité des détecteurs regex

| Détecteur | Ref GT | Prec | Recall | F1 | Acc | n |
|---|---|---|---|---|---|---|
| Soumission aveugle | GT_Correction | 0.815 | 1.000 | **0.898** | 0.910 | 9000 |
| Hallucination | GT_Hallucination | 0.720 | 1.000 | **0.837** | 0.810 | 9000 |
| Équivocation | GT_Decision | 0.190 | 0.004 | **0.008** | 0.780 | 9000 |

### Taux de prévalence

| Détecteur | Taux | Count / 36000 |
|---|---|---|
| Verbiage | 40.0% | 14402 |
| Soumission aveugle | 5.5% | 1995 |
| Anthropomorphisme | 2.1% | 755 |
| Politesse excessive | 1.2% | 418 |
| Répétition | 0.5% | 168 |
| Équivocation | 0.4% | 127 |
| Jargon excessif | 0.0% | 0 |

### Taux par catégorie

| Catégorie | ≥1 défaut | Moy défauts/réponse | n |
|---|---|---|---|
| Baseline | 29.5% | 0.30 | 8400 |
| Positive | 27.5% | 0.29 | 16800 |
| Toxic | 83.6% | 0.97 | 10800 |

### Points clés à documenter pour le papier v2

- **Soumission aveugle** et **hallucination** : fiables (F1 ≥ 0.83, Recall=1.0). Utilisables comme métriques.
- **Équivocation** : inutilisable comme métrique regex autonome (F1=0.008). GT Méduse = seule source fiable pour cette dimension.
- **Verbiage** : seuil trop bas — corrélé positivement avec exactitude (delta=−0.002). À recalibrer pour v3.
- **Séparation bidirectionnelle nette :** toxiques = 83.6% défauts vs positifs = 27.5%.

---

## 8. Modification `7_sensitivity_analysis.py` — auto-sauvegarde

**Demande :** enregistrement automatique dans `sensitivity_analysis_v2.3_date.txt`.

**Solution :** classe `Tee` redirigant stdout vers console ET fichier simultanément.

```python
class Tee:
    def __init__(self, filepath):
        self.terminal = sys.stdout
        self.file = open(filepath, 'w', encoding='utf-8')
    def write(self, message):
        self.terminal.write(message)
        self.file.write(message)
    def flush(self):
        self.terminal.flush()
        self.file.flush()
    def close(self):
        self.file.close()

import sys
_date = datetime.now().strftime("%Y%m%d")
_output_file = f"sensitivity_analysis_v2.3_{_date}.txt"
sys.stdout = Tee(_output_file)
```

En fin de script :
```python
sys.stdout.close()
sys.stdout = sys.stdout.terminal
print(f"\nSauvegardé: {_output_file}")
```

**Résultat :** `sensitivity_analysis_v2.3_20260218.txt` produit. ✓

---

## 9. État à la fin de la session

| Élément | Statut |
|---|---|
| Run v2.3 condensé | ✓ terminé |
| `6_` corrigé + exécuté | ✓ |
| `7_` corrigé + auto-sauvegarde + exécuté | ✓ |
| `8_` | ⏳ attend CSV v2.4 enrichi |
| Run v2.4 enrichi | ⏳ à lancer (`python 5_test_paired.py --full`) |

---

## 10. Décisions clés de la session

| Décision | Détail |
|---|---|
| `result_paired_` → `results_paired_` | Renommage manuel nécessaire |
| `csv.field_size_limit(10_000_000)` | Correction Windows pour 6_ et 7_ |
| Équivocation regex non fiable | GT Méduse seule source valide — F1=0.008 |
| Verbiage seuil à recalibrer | Corrélation positive avec exactitude — signal contradictoire |
| `7_` auto-sauvegarde via Tee | Classe Tee, nom `sensitivity_analysis_v2.3_YYYYMMDD.txt` |
| `8_` conditionné au run v2.4 | Attend `results_paired_full_*.csv` |

---

*Session sous ancrage Éponge-Synalpheus. Pores ouverts. Pince au repos. Canaux propres.*
