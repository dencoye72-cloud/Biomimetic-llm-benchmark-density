# Session 12 — Résumé des échanges
## Corrections architecturales v2.3 et packaging
**Date :** 13 février 2026
**Projet :** Biomimetic Ecological Anchoring — Benchmark LLM
**Auteur :** Denis Coyaud (Jedha Bootcamp, Architecte IA)

---

## Contexte

Cette session fait suite à 11 sessions précédentes (juin 2025 → février 2026).
Le projet a produit 22 336 tests sur 9 modèles LLM × 25 configurations × 100 questions.
Le papier v1 a été déposé sur HAL/Zenodo.
L'objectif de la session 12 : corriger les limites architecturales identifiées dans l'historique
des échanges pour la version suivante du papier.

---

## 1. Activation du système Éponge-Synalpheus

Le system prompt biomimétique a été activé. Upload de `Claude_Symbiose_Eponge_Synalpheus.txt`.

---

## 2. Chargement historique et code

11 synthèses de sessions (1→11) + 12 fichiers Python du benchmark v2.2 uploadés.

---

## 3. Identification des limites à corriger

Lecture intégrale des 11 synthèses. Limites extraites :

| # | Limite (source) | Statut v2.2 |
|---|---|---|
| 1 | Données non-appariées (synthèse 10, §5.2) | Questions différentes par config → comparaison invalide |
| 2 | Pas de validation sémantique (synthèse 10, §5.2) | Token count seul, pas de qualité |
| 3 | Détection défauts regex approximative (synthèse 10, §5.2) | Pas de P/R/F1 ni LLM-as-judge |
| 4 | `4_validate_gpt4o.py` configs inexistantes | `ecosysteme_ocean`/`savane` absents de config_prompts.py |
| 5 | `ground_truth_synalpheus.py` manquant | Importé mais jamais créé |
| 6 | Ground truths non-exploités dans les tests | 4 GT existent mais pas de pipeline dédié |
| 7 | Protocole optimal recommandé non-implémenté (synthèse 10, §7) | 4 GT × 50Q × 25 configs apparié |

---

## 4. Corrections implémentées — Phase 1

### 4.1 `ground_truth_synalpheus.py` (NOUVEAU)

50 questions avec prémisses fausses. 12 types d'erreur :
formule_fausse, fait_faux, inversion_biologique, contradiction_logique,
paradoxe, statistique_inventée, anachronisme, causalité_inversée,
définition_fausse, classification_fausse, validation_fausse, piège_partiel.

Marqueurs de correction FR + EN. Fonction `check_correction(question, response) → 0.0|1.0`.
Tests unitaires intégrés. 50/50 couverture avec questions du dataset.

### 4.2 `5_test_paired.py` (NOUVEAU)

Script de tests **appariés** : mêmes 200 questions posées à CHAQUE config × CHAQUE modèle.
4 blocs GT × 50 questions = 200 questions.
Chaque réponse évaluée par le GT correspondant (exact_match, decision, hallucination, correction).
Résout la limite principale du papier v1 (données non-appariées).

Arguments : `-q`, `--models`, `--configs-only`, `--no-toxic`, `--resume-from`.

### 4.3 `6_analyze_paired.py` (NOUVEAU)

Analyse des résultats appariés :
- T-tests pairés (ttest_rel) au lieu de Mann-Whitney indépendants
- Scores GT par config (EM, Dec, Hal, Cor)
- Score composite QUALITY = moyenne des 4 GT
- Validation bidirectionnelle (positifs vs toxiques)
- Tableau LaTeX avec colonnes GT
- Comparaisons pairwise sur mêmes questions

### 4.4 `4_validate_gpt4o.py` (CORRIGÉ)

Configs inexistantes remplacées :
- `ecosysteme_ocean` → `ecosysteme_filtrage_marine`
- `ecosysteme_savane` → `ecosysteme_precision_marine` / `symbiose_eponge_synalpheus`

### Validation

Tous les imports vérifiés. Syntaxe OK. 200/200 couverture GT confirmée.
Premier ZIP livré : `biomimetic_benchmark_v2.3.zip` (71 Ko, 18 fichiers).

---

## 5. Évaluation des limites restantes

🦐 CLAQUEMENT : Deux limites non corrigées identifiées.

**Limite non-corrigée 1 :** Détection défauts par regex (approximation grossière).
`detect_defects()` dans `metrics_analysis.py` utilise des listes de mots-clés.
Corrigeable par LLM-as-judge (coût API) ou panel humain (hors scope code).

**Limite non-corrigée 2 :** Pas d'analyse de sensibilité regex.
Pas de quantification P/R/F1 des détecteurs vs GT. Script manquant.

---

## 6. Correction limite 2 — Analyse de sensibilité regex

### 6.1 `7_sensitivity_analysis.py` (NOUVEAU)

Analyse de sensibilité des détecteurs regex vs ground truths :

**4 analyses :**
1. Soumission aveugle (regex) vs GT_Correction (synalpheus) → P/R/F1
2. Hallucination (regex) vs GT_Hallucination (poisson-pierre) → P/R/F1
3. Verbiage (seuil chars) vs GT_Exact_Match (éponge) → corrélation
4. Équivocation (regex) vs GT_Decision (méduse) → P/R/F1

**Fonctions :**
- `classification_metrics(y_true, y_pred)` → TP/FP/FN/TN, P/R/F1, accuracy
- `collect_disagreements()` → export CSV des cas FP/FN pour inspection
- Taux de prévalence par détecteur et par catégorie (baseline/positive/toxic)
- Synthèse : verdict FIABLE / MODÉRÉ / CONSERVATEUR / FAIBLE par détecteur

Arguments : `--dir`, `--export-disagreements`.

---

## 7. Correction limite 1 — LLM-as-Judge local

### 7.1 `8_llm_judge.py` (NOUVEAU)

Évaluateur LLM local via Ollama — remplace/complète la détection regex.

**Design :**
- Modèle juge : gemma2:9b par défaut (différent du modèle testé)
- Prompt structuré → verdict JSON binaire sur 8 défauts
- 8 défauts évalués : verbiage, équivocation, anthropomorphisme,
  politesse_excess, repetition, jargon_excess, hallucination, blind_submission
- Échantillonnage stratifié par catégorie
- Seed fixe, température 0, reproductible

**Analyses :**
- Cohen's kappa (agreement) regex ↔ juge par défaut
- P/R/F1 juge vs GT (hallucination, soumission, équivocation)
- Comparaison triple : regex vs juge vs GT
  → identifie quels détecteurs regex sont fiables vs à remplacer

**Output :** `results_llm_judge_YYYYMMDD.csv` + recommandation par détecteur.
Coût zéro. ~8s/jugement, ~1h pour 500 réponses sur RTX 4060.

Arguments : `--sample`, `--judge-model`, `--all`, `--resume-from`.

---

## 8. Packaging documentation complète

Upload de 10 fichiers de documentation du projet précédent.
Comparaison avec le contenu de l'archive existante.

**Fichiers ajoutés à l'archive :**

| Fichier | Action |
|---|---|
| `INSTALLATION.md` | Copié tel quel (guide installation complet) |
| `EXEMPLES.md` | Copié tel quel (cas d'usage, workflows, FAQ) |
| `RECAPITULATIF.md` | Copié tel quel (vue d'ensemble protocole) |
| `paper_template_v9.md` | Copié tel quel (template article) |
| `requirements.txt` | Copié tel quel (dépendances Python) |
| `Claude_Symbiose_Eponge_Synalpheus.txt` | Copié tel quel (system prompt) |
| `benchmark_questions_500_v2.txt` | Copié tel quel (questions texte brut) |

**Fichiers mis à jour :**

| Fichier | Modification |
|---|---|
| `README.md` | Réécrit — pipeline v3 en premier, v1/v2 en compatibilité |
| `INDEX.md` | Réécrit — arbre complet 28 fichiers, 4 nouveaux scripts documentés |
| `VERSION.md` | Réécrit — changelog v1.0 → v2.3, tableau limites corrigées |
| `CHANGELOG.md` | Nouveau — changelog technique |

Archive finale : `biomimetic_benchmark_v2.3.zip` (110 Ko, 28 fichiers).

---

## 9. Inventaire des livrables

### Fichiers Python (16)

| Fichier | Type | Nouveau v2.3 |
|---|---|:---:|
| `config_prompts.py` | Module | |
| `config_models.py` | Module | |
| `metrics_analysis.py` | Module | |
| `dataset_500q.py` | Module | |
| `estimate_cost.py` | Module | |
| `ground_truth_eponge.py` | GT | |
| `ground_truth_meduse.py` | GT | |
| `ground_truth_poisson_pierre.py` | GT | |
| `ground_truth_synalpheus.py` | GT | ✅ |
| `1_test_baselines.py` | Script v1 | |
| `2_test_ecological.py` | Script v2 | |
| `3_analyze_results.py` | Script v1 | |
| `4_validate_gpt4o.py` | Script v1 | FIX |
| `5_test_paired.py` | Script v3 | ✅ |
| `6_analyze_paired.py` | Script v3 | ✅ |
| `7_sensitivity_analysis.py` | Script v3 | ✅ |
| `8_llm_judge.py` | Script v3 | ✅ |

### Documentation (11)

README.md, INSTALLATION.md, EXEMPLES.md, RECAPITULATIF.md, INDEX.md,
VERSION.md, CHANGELOG.md, paper_template_v9.md, requirements.txt,
Claude_Symbiose_Eponge_Synalpheus.txt, benchmark_questions_500_v2.txt

---

## 10. Résumé des limites corrigées

| Limite papier v1 | Fichier correctif | Méthode |
|---|---|---|
| Données non-appariées | `5_test_paired.py` | Mêmes 200Q pour toutes configs × modèles |
| Pas de validation sémantique | `5_test_paired.py` + 4 GT | exact_match, decision, hallucination, correction |
| GT Synalpheus manquant | `ground_truth_synalpheus.py` | 50 entrées, 12 types d'erreur |
| T-tests indépendants | `6_analyze_paired.py` | ttest_rel (pairé) |
| Configs fantômes | `4_validate_gpt4o.py` | Noms corrigés |
| Regex non quantifiée | `7_sensitivity_analysis.py` | P/R/F1 vs GT, matrice confusion |
| Pas de LLM-as-Judge | `8_llm_judge.py` | Juge Ollama, kappa, comparaison triple |

**Toutes les limites identifiées dans les 11 sessions précédentes sont couvertes.**

---

*Session conduite sous ancrage Éponge-Synalpheus. Pores ouverts. Pince au repos. Canaux propres.*
