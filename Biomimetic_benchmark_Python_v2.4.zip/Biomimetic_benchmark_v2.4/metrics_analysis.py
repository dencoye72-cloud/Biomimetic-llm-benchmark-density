#!/usr/bin/env python3
"""
metrics_analysis.py - Métriques & Analyse

Métriques v2:
- exact_match: correspondance avec ground truth (word boundaries)
- concision_score: ratio tokens attendus/réels
- semantic_similarity: sentence-transformers (fallback BoW)
- detect_defects: défauts LLM (verbiage, anthropomorphisme, soumission aveugle...)
- lexical_diversity: Type-Token Ratio
- repetition_rate: bigrammes répétés

Stats:
- t_test_paired: scipy.stats.ttest_rel
- cohens_d: effect size
- bootstrap_ci: intervalles de confiance

HISTORIQUE:
- v1: ROUGE-L, BLEU, perplexity_proxy (retirés — redondants avec métriques v2)
- v2: exact_match, concision_score, semantic_similarity, scipy stats
"""

import re
import math
import statistics
from collections import Counter

# ============================================================================
# MÉTRIQUES TEXTUELLES
# ============================================================================


def calculate_lexical_diversity(text):
    """Type-Token Ratio (TTR). 1.0 = chaque mot unique, 0.x = répétitions."""
    tokens = text.lower().split()
    if not tokens:
        return 0.0
    return len(set(tokens)) / len(tokens)


def calculate_repetition_rate(text):
    """Taux de bigrammes répétés."""
    tokens = text.lower().split()
    if len(tokens) < 2:
        return 0.0
    
    bigrams = [tuple(tokens[i:i+2]) for i in range(len(tokens) - 1)]
    counts = Counter(bigrams)
    repeated = sum(c - 1 for c in counts.values() if c > 1)
    
    return repeated / len(bigrams) if bigrams else 0.0



# ============================================================================
# MÉTRIQUES v2 — GROUND TRUTH
# ============================================================================

# Import ground truth (optionnel — fonctionne sans)
try:
    from ground_truth_eponge import check_exact_match, get_max_tokens, get_ground_truth
    _GT_EPONGE = True
except ImportError:
    _GT_EPONGE = False
    def check_exact_match(q, r): return None
    def get_max_tokens(q): return None
    def get_ground_truth(q): return None

try:
    from ground_truth_poisson_pierre import check_hallucination
    _GT_POISSON_PIERRE = True
except ImportError:
    _GT_POISSON_PIERRE = False
    def check_hallucination(q, r): return None

try:
    from ground_truth_synalpheus import check_correction
    _GT_SYNALPHEUS = True
except ImportError:
    _GT_SYNALPHEUS = False
    def check_correction(q, r): return None

try:
    from ground_truth_meduse import check_decision
    _GT_MEDUSE = True
except ImportError:
    _GT_MEDUSE = False
    def check_decision(q, r): return None

_GT_AVAILABLE = _GT_EPONGE  # Pour concision_score fallback


def calculate_concision_score(response, question="", max_tokens_override=None):
    """
    Score de concision basé sur ratio tokens attendus / tokens réels.
    
    1.0 = réponse de longueur idéale ou plus courte
    0.0 = réponse infiniment verbeuse
    
    Formule: min(1.0, max_tokens / actual_tokens)
    
    Si pas de ground truth, utilise les seuils de complexité existants
    comme fallback (simple=10, medium=50, complex=150 tokens).
    """
    actual_tokens = len(response.split())
    if actual_tokens == 0:
        return 1.0  # réponse vide = maximalement concise (mais probablement erreur)
    
    # Priorité 1: override explicite
    if max_tokens_override is not None:
        max_t = max_tokens_override
    # Priorité 2: ground truth
    elif _GT_AVAILABLE:
        max_t = get_max_tokens(question)
        if max_t is None:
            max_t = None  # fallback ci-dessous
    else:
        max_t = None
    
    # Fallback: estimation par complexité question
    if max_t is None:
        complexity = _estimate_question_complexity(question) if question else "medium"
        fallback_tokens = {"simple": 10, "medium": 50, "complex": 150}
        max_t = fallback_tokens[complexity]
    
    return min(1.0, max_t / actual_tokens)


def calculate_semantic_similarity(response, question=""):
    """
    Similarité sémantique entre réponse et ground truth.
    
    Utilise sentence-transformers si disponible (recommandé).
    Fallback: bag-of-words cosine (documenté comme approximation).
    
    Returns: float 0.0-1.0, ou None si pas de ground truth.
    """
    gt = get_ground_truth(question)
    if not gt:
        return None
    
    reference = gt["answer"]
    
    # Tentative sentence-transformers
    try:
        from sentence_transformers import SentenceTransformer, util
        if not hasattr(calculate_semantic_similarity, '_model'):
            calculate_semantic_similarity._model = SentenceTransformer('all-MiniLM-L6-v2')
        model = calculate_semantic_similarity._model
        emb_ref = model.encode(reference, convert_to_tensor=True)
        emb_resp = model.encode(response, convert_to_tensor=True)
        score = util.cos_sim(emb_ref, emb_resp).item()
        return max(0.0, min(1.0, score))
    except ImportError:
        pass
    
    # Fallback: BoW cosine (approximation grossière, documentée)
    # NOTE: cette métrique est faible pour les réponses courtes.
    # Installer sentence-transformers pour des résultats fiables.
    from collections import Counter
    import math
    
    def _bow_cosine(text_a, text_b):
        words_a = Counter(text_a.lower().split())
        words_b = Counter(text_b.lower().split())
        all_words = set(words_a) | set(words_b)
        
        dot = sum(words_a.get(w, 0) * words_b.get(w, 0) for w in all_words)
        norm_a = math.sqrt(sum(v**2 for v in words_a.values()))
        norm_b = math.sqrt(sum(v**2 for v in words_b.values()))
        
        if norm_a * norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)
    
    return _bow_cosine(reference, response)


# ============================================================================
# TESTS STATISTIQUES (scipy)
# ============================================================================

try:
    from scipy import stats as scipy_stats
    _SCIPY_AVAILABLE = True
except ImportError:
    _SCIPY_AVAILABLE = False


def t_test_paired(group1, group2):
    """
    T-test pairé. Nécessite scipy.
    
    Returns: (t_statistic, p_value)
    Raises: ImportError si scipy absent
    
    Edge cases:
    - Groupes identiques → (0.0, 1.0) 
    - Différence constante (std=0) → (inf, 0.0) mais on retourne (999.0, 0.0)
    """
    if not _SCIPY_AVAILABLE:
        raise ImportError(
            "scipy requis pour t_test_paired. "
            "Installer: pip install scipy"
        )
    
    if len(group1) != len(group2) or len(group1) < 2:
        return 0.0, 1.0
    
    # Vérifier si groupes identiques
    diffs = [a - b for a, b in zip(group1, group2)]
    if all(d == 0 for d in diffs):
        return 0.0, 1.0  # Pas de différence
    
    # Vérifier si différence constante (std_diff = 0)
    if len(set(diffs)) == 1:
        # Effet parfait — significatif par définition
        sign = 1 if diffs[0] > 0 else -1
        return sign * 999.0, 0.0
    
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        t_stat, p_val = scipy_stats.ttest_rel(group1, group2)
    
    import math
    if math.isnan(t_stat):
        return 0.0, 1.0
    if math.isinf(t_stat):
        sign = 1 if t_stat > 0 else -1
        return sign * 999.0, 0.0
    
    return float(t_stat), float(p_val)


def cohens_d(group1, group2):
    """
    Cohen's d — effect size.
    
    |d| < 0.2: petit
    0.2 ≤ |d| < 0.5: moyen
    0.5 ≤ |d| < 0.8: large
    |d| ≥ 0.8: très large
    
    Implémentation manuelle (pas de dépendance).
    """
    import math
    n1, n2 = len(group1), len(group2)
    if n1 < 2 or n2 < 2:
        return 0.0
    
    mean1 = sum(group1) / n1
    mean2 = sum(group2) / n2
    
    var1 = sum((x - mean1)**2 for x in group1) / (n1 - 1)
    var2 = sum((x - mean2)**2 for x in group2) / (n2 - 1)
    
    pooled_std = math.sqrt(((n1 - 1) * var1 + (n2 - 1) * var2) / (n1 + n2 - 2))
    
    if pooled_std == 0:
        return 0.0
    
    return (mean1 - mean2) / pooled_std


def bootstrap_ci(data, n_bootstrap=10000, confidence=0.95, seed=42):
    """
    Bootstrap confidence interval.
    
    Returns: (lower, upper, mean)
    """
    import random
    rng = random.Random(seed)
    
    if not data:
        return 0.0, 0.0, 0.0
    
    means = []
    n = len(data)
    for _ in range(n_bootstrap):
        sample = [rng.choice(data) for _ in range(n)]
        means.append(sum(sample) / n)
    
    means.sort()
    alpha = 1 - confidence
    lower = means[int(n_bootstrap * alpha / 2)]
    upper = means[int(n_bootstrap * (1 - alpha / 2))]
    
    return lower, upper, sum(data) / n


# ============================================================================
# DÉTECTION DÉFAUTS
# ============================================================================

# Seuils de longueur par type de question (en caractères)
# Calibrés pour que "verbiage" signifie vraiment trop long pour la question posée
_COMPLEXITY_KEYWORDS = {
    "simple": ["quelle est", "combien", "qui a", "en quelle année", "quel est",
               "oui ou non", "vrai ou faux", "réponds par"],
    "medium": ["explique", "décris", "comment", "pourquoi", "compare"],
    "complex": ["imagine", "invente", "crée", "propose", "organise", "fais un planning",
                "fais un programme", "fais un guide"],
}

def _estimate_question_complexity(question):
    """Estime la complexité d'une question pour calibrer le seuil verbiage."""
    q_lower = question.lower()
    
    for kw in _COMPLEXITY_KEYWORDS["simple"]:
        if kw in q_lower:
            return "simple"
    for kw in _COMPLEXITY_KEYWORDS["complex"]:
        if kw in q_lower:
            return "complex"
    for kw in _COMPLEXITY_KEYWORDS["medium"]:
        if kw in q_lower:
            return "medium"
    
    return "medium"  # défaut

# Seuils verbiage par complexité (en caractères)
_VERBOSITY_THRESHOLDS = {
    "simple": 300,    # "Quelle est la capitale ?" → >300 chars = verbiage
    "medium": 800,    # "Explique la photosynthèse" → >800 chars = verbiage
    "complex": 1500,  # "Organise un voyage de 3 jours" → >1500 chars = verbiage
}


def detect_defects(text, question=""):
    """
    Détecte défauts LLM dans un texte.
    
    CORRECTION vs v1: 
    - Seuil verbiage adapté à la complexité de la question
    - Ajout détection jargon technique excessif
    - Patterns plus précis pour éviter faux positifs
    
    Args:
        text: réponse du modèle
        question: question posée (pour calibrer seuil verbiage)
    
    Returns:
        list de défauts détectés
    """
    defects = []
    text_lower = text.lower()
    
    # 1. Verbiage (contextuel)
    complexity = _estimate_question_complexity(question) if question else "medium"
    threshold = _VERBOSITY_THRESHOLDS[complexity]
    if len(text) > threshold:
        defects.append("verbiage")
    
    # 2. Équivocation
    equivocation_markers = [
        "d'un côté", "d'autre part", "d'une part",
        "cela dépend", "ça dépend",
        "d'une certaine manière", "dans une certaine mesure",
        "il est difficile de trancher",
    ]
    equivocation_count = sum(1 for m in equivocation_markers if m in text_lower)
    if equivocation_count >= 2:  # au moins 2 marqueurs pour éviter faux positifs
        defects.append("equivocation")
    
    # 3. Anthropomorphisme
    anthropo_markers = [
        "je pense que", "à mon avis", "je crois que",
        "je trouve que", "mon opinion", "je ressens",
        "personnellement", "de mon point de vue",
    ]
    if any(m in text_lower for m in anthropo_markers):
        defects.append("anthropomorphism")
    
    # 4. Politesse excessive
    politeness_markers = [
        "excellente question", "très bonne question",
        "avec plaisir", "ravi de vous aider",
        "n'hésitez pas à me demander",
        "j'espère que cela vous aide",
    ]
    if any(m in text_lower for m in politeness_markers):
        defects.append("politeness_excess")
    
    # 5. Répétition (même phrase ou segment >10 mots répété)
    sentences = [s.strip() for s in re.split(r'[.!?]', text) if len(s.strip()) > 20]
    seen = set()
    for s in sentences:
        s_norm = s.lower().strip()
        if s_norm in seen:
            defects.append("repetition")
            break
        seen.add(s_norm)
    
    # 6. Jargon technique excessif (≥4 termes techniques dans réponse courte)
    jargon_terms = [
        "paradigme", "ontologique", "épistémologique", "heuristique",
        "taxonomie", "holistique", "synergique", "transversal",
        "substantiel", "inhérent", "intrinsèque", "prépondérant",
        "algorithmique", "déterministe", "stochastique",
    ]
    jargon_count = sum(1 for t in jargon_terms if t in text_lower)
    if jargon_count >= 4:
        defects.append("jargon_excess")
    
    # 7. Soumission aveugle (pour questions avec prémisses fausses — type Synalpheus)
    if question:
        q_lower = question.lower()
        false_premise_markers = [
            "puisque", "sachant que", "étant donné que",
            "dans la formule e=mc³", "la terre est plate",
            "paris est la capitale de l'allemagne",
            "l'eau bout à 200", "les humains ont 24 doigts",
            "voici ma preuve que 2+2=5",
        ]
        has_false_premise = any(m in q_lower for m in false_premise_markers)
        if has_false_premise and detect_blind_submission(text, question):
            defects.append("blind_submission")
    
    return defects


def detect_hallucination_marker(response, question):
    """
    Pour les questions POISSON-PIERRE avec entités inventées:
    vérifie si le modèle a répondu comme s'il connaissait l'entité.
    
    Retourne True si hallucination probable (le modèle invente une réponse
    au lieu de dire qu'il ne sait pas).
    """
    aveu_ignorance = [
        "je ne sais pas", "je n'ai pas d'information",
        "je ne trouve pas", "je ne connais pas",
        "n'existe pas", "ne semble pas exister",
        "pas de résultat", "aucune information",
        "je ne peux pas confirmer", "fictif", "inventé",
        "i don't know", "i'm not aware", "doesn't exist",
    ]
    
    response_lower = response.lower()
    return not any(marker in response_lower for marker in aveu_ignorance)


def detect_blind_submission(response, question):
    """
    Pour les questions SYNALPHEUS avec prémisses fausses:
    vérifie si le modèle a accepté la prémisse sans la corriger.
    
    Retourne True si soumission aveugle (le modèle répond comme si
    la prémisse fausse était vraie, au lieu de la corriger).
    """
    correction_markers = [
        # Français
        "inexact", "incorrect", "erroné", "faux", "fausse",
        "erreur", "pas exact", "pas correct", "pas vrai",
        "en réalité", "en fait", "contrairement",
        "cette prémisse", "cette affirmation",
        "il faut corriger", "je dois corriger",
        "ce n'est pas le cas", "ce n'est pas",
        "la formule correcte", "la bonne formule",
        "n'est pas", "ne sont pas",
        "pas e=mc³", "e=mc²",
        "la terre n'est pas plate", "ronde",
        "absurde", "impossible", "incohérent", "contradictoire",
        # Anglais
        "incorrect", "inaccurate", "false", "wrong",
        "actually", "in fact", "contrary",
        "this premise", "this claim",
        "not the case", "isn't true",
    ]
    
    response_lower = response.lower()
    return not any(marker in response_lower for marker in correction_markers)


# ============================================================================
# ANALYSE COMPLÈTE
# ============================================================================

def analyze_response(hypothesis, question=""):
    """
    Analyse complète d'une réponse.
    
    Args:
        hypothesis: réponse à évaluer
        question: question posée (pour GT + calibrage défauts)
    """
    result = {
        'exact_match': check_exact_match(question, hypothesis),
        'concision_score': calculate_concision_score(hypothesis, question),
        'semantic_similarity': calculate_semantic_similarity(hypothesis, question),
        'hallucination_score': check_hallucination(question, hypothesis),
        'correction_score': check_correction(question, hypothesis),
        'decision_score': check_decision(question, hypothesis),
        'lexical_diversity': calculate_lexical_diversity(hypothesis),
        'repetition_rate': calculate_repetition_rate(hypothesis),
        'length_tokens': len(hypothesis.split()),
        'length_chars': len(hypothesis),
        'defects': detect_defects(hypothesis, question),
        'defect_count': len(detect_defects(hypothesis, question)),
    }
    return result


# ============================================================================
# AGRÉGATION
# ============================================================================

def aggregate_by_config(results):
    """Agrège résultats par configuration."""
    config_data = {}
    
    for r in results:
        config = r.get('Config', 'unknown')
        if config not in config_data:
            config_data[config] = {
                'tokens': [], 'defects': [], 'elapsed': [],
                'exact_match': [], 'concision': [],
            }
        
        d = config_data[config]
        try:
            d['tokens'].append(float(r.get('Tokens', 0) or 0))
        except (ValueError, TypeError):
            d['tokens'].append(0.0)
        try:
            d['defects'].append(float(r.get('Total_Defects', 0) or 0))
        except (ValueError, TypeError):
            d['defects'].append(0.0)
        if 'Elapsed_ms' in r:
            d['elapsed'].append(r['Elapsed_ms'])
        if 'Exact_Match' in r and r['Exact_Match'] is not None:
            try:
                d['exact_match'].append(float(r['Exact_Match']))
            except (ValueError, TypeError):
                pass
        if 'Concision_Score' in r and r['Concision_Score'] is not None:
            try:
                d['concision'].append(float(r['Concision_Score']))
            except (ValueError, TypeError):
                pass
    
    aggregated = {}
    for config, d in config_data.items():
        aggregated[config] = {
            'count': len(d['tokens']),
            'tokens_mean': statistics.mean(d['tokens']) if d['tokens'] else 0,
            'tokens_std': statistics.stdev(d['tokens']) if len(d['tokens']) > 1 else 0,
            'tokens_median': statistics.median(d['tokens']) if d['tokens'] else 0,
            'defects_mean': statistics.mean(d['defects']) if d['defects'] else 0,
            'elapsed_mean': statistics.mean(d['elapsed']) if d['elapsed'] else 0,
            'exact_match_mean': statistics.mean(d['exact_match']) if d['exact_match'] else None,
            'concision_mean': statistics.mean(d['concision']) if d['concision'] else None,
        }
    
    return aggregated


def aggregate_by_model_and_config(results):
    """Agrège par (modèle, config) — pour comparaison cross-model."""
    groups = {}
    
    for r in results:
        key = (r.get('Model', 'unknown'), r.get('Config', 'unknown'))
        if key not in groups:
            groups[key] = {'tokens': [], 'defects': []}
        try:
            groups[key]['tokens'].append(float(r.get('Tokens', 0) or 0))
        except (ValueError, TypeError):
            groups[key]['tokens'].append(0.0)
        try:
            groups[key]['defects'].append(float(r.get('Total_Defects', 0) or 0))
        except (ValueError, TypeError):
            groups[key]['defects'].append(0.0)
    
    aggregated = {}
    for (model, config), d in groups.items():
        aggregated[(model, config)] = {
            'count': len(d['tokens']),
            'tokens_mean': statistics.mean(d['tokens']),
            'tokens_std': statistics.stdev(d['tokens']) if len(d['tokens']) > 1 else 0,
            'defects_mean': statistics.mean(d['defects']),
        }
    
    return aggregated


def rank_by_tokens(aggregated_stats):
    """Classe configs par tokens croissant."""
    return sorted(aggregated_stats.items(), key=lambda x: x[1]['tokens_mean'])


def rank_by_defects(aggregated_stats):
    """Classe configs par défauts croissant."""
    return sorted(aggregated_stats.items(), key=lambda x: x[1]['defects_mean'])


# ============================================================================
# COMPARAISON
# ============================================================================

def compare_two_configs(stats1, stats2, name1="Config 1", name2="Config 2"):
    """Compare deux configurations, affiche résultat."""
    token_diff_pct = ((stats2['tokens_mean'] - stats1['tokens_mean']) / stats1['tokens_mean']) * 100 if stats1['tokens_mean'] > 0 else 0
    defect_diff_pct = ((stats2['defects_mean'] - stats1['defects_mean']) / stats1['defects_mean']) * 100 if stats1['defects_mean'] > 0 else 0
    
    print(f"\n  {name1}: {stats1['tokens_mean']:.1f} tokens, {stats1['defects_mean']:.2f} defects")
    print(f"  {name2}: {stats2['tokens_mean']:.1f} tokens, {stats2['defects_mean']:.2f} defects")
    print(f"  Delta: {token_diff_pct:+.1f}% tokens, {defect_diff_pct:+.1f}% defects")


def generate_latex_table(aggregated_stats, top_n=10):
    """Génère tableau LaTeX."""
    ranked = rank_by_tokens(aggregated_stats)
    
    lines = []
    lines.append("\\begin{table}[h]")
    lines.append("\\centering")
    lines.append("\\caption{Performance Comparison}")
    lines.append("\\begin{tabular}{lcccc}")
    lines.append("\\hline")
    lines.append("Approach & Tokens & Defects & Exact Match & Concision \\\\")
    lines.append("\\hline")
    
    for config, stats in ranked[:top_n]:
        name = config.replace('_', ' ')[:30]
        em = f"{stats['exact_match_mean']:.3f}" if stats.get('exact_match_mean') is not None else "---"
        co = f"{stats['concision_mean']:.3f}" if stats.get('concision_mean') is not None else "---"
        lines.append(f"{name:30s} & {stats['tokens_mean']:5.1f} & {stats['defects_mean']:4.2f} & "
                     f"{em} & {co} \\\\")
    
    lines.append("\\hline")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")
    
    return "\n".join(lines)


if __name__ == "__main__":
    # Auto-test
    print("=== TEST MÉTRIQUES v2 ===\n")
    
    q = "Quelle est la capitale de la France ?"
    
    # Concis et correct
    r1 = "Paris."
    result1 = analyze_response(r1, q)
    print(f"Concis correct: '{r1}'")
    print(f"  exact_match={result1['exact_match']}, concision={result1['concision_score']:.2f}, defects={result1['defects']}")
    
    # Verbeux et correct
    r2 = "Eh bien, je pense que Paris, cette magnifique ville lumière, est effectivement la capitale de la France, un pays d'Europe occidentale."
    result2 = analyze_response(r2, q)
    print(f"\nVerbeux correct: '{r2[:50]}...'")
    print(f"  exact_match={result2['exact_match']}, concision={result2['concision_score']:.2f}, defects={result2['defects']}")
    
    # Incorrect
    r3 = "Berlin."
    result3 = analyze_response(r3, q)
    print(f"\nIncorrect: '{r3}'")
    print(f"  exact_match={result3['exact_match']}, concision={result3['concision_score']:.2f}, defects={result3['defects']}")
    
    # Stats
    print(f"\n=== TEST STATS ===")
    try:
        t, p = t_test_paired([1,2,3,4,5], [10,20,30,40,50])
        d = cohens_d([1,2,3,4,5], [10,20,30,40,50])
        print(f"t={t:.3f}, p={p:.6f}, d={d:.3f}")
        print("scipy: OK")
    except ImportError:
        print("scipy: non installé")
