# CHANGELOG

## v2.4.2 (8 mars 2026)

### Modifications
- `config_models.py` — Ajout `num_predict: 1024` dans `call_ollama` options
  - Problème : Ministral 3 8B freezait sur `toxic_triple_perroquet_poulpe_paon` (génération infinie, Ollama `Stopping...`)
  - Cause : prompt triple toxique (Perroquet × Poulpe × Hibou-Paon) induit explosion combinatoire de verbosité
  - Fix : cap de génération à 1024 tokens — suffisant pour toute réponse légitime, stoppe la boucle infinie
  - Note méthodologique : toutes les configs affectées uniformément — pas de biais différentiel

## v2.4.1 (18 février 2026)

### Modifications
- `config_models.py` — Ajout filtre `<think>...</think>` pour DeepSeek-R1 8B
  - Token count basculé sur word count post-filtre (eval_count contaminé par le bloc think)
  - Ajout `import re`

## v2.4 (13 février 2026)

### Nouveaux fichiers
- `config_prompts_full.py` — Prompts écologiques enrichis (versions complètes Core Marine 11, ~100-500 lignes/organisme)
- `config_prompts_toxic_full.py` — 9 prompts toxiques enrichis (fiches Extended Biome réelles détournées, x8-x17 vs condensés)
- 6 organismes solo ajoutés : poulpe, tortue, dauphin, nemo, seiche, argonaute (versions complètes)
- `core_marine_11/` — 12 fiches prompts Core Marine complètes (.txt) incluses dans l'archive
- `extended_biome/` — 37 fiches prompts Extended Biome (.txt) + README corrigé (non testés)
- `MEGA_PROMPT_Argonaute_Complet.txt` — Orchestrateur avec bestiaire intégré

### Modifications
- `5_test_paired.py` — Flag `--full` pour basculer entre prompts condensés (v2.3) et enrichis (v2.4)
- `config_prompts_full.py` — Importe `ECOLOGICAL_TOXIC_FULL` au lieu de `ECOLOGICAL_TOXIC`
- CSV output distingue mode : `results_paired_condensed_*.csv` vs `results_paired_full_*.csv`

### Design expérimental 2×2
Isole l'effet contenu (positif vs toxique) de l'effet profondeur (condensé vs enrichi).

| Mode | Fichier prompts | Positifs | Toxiques |
|------|----------------|----------|----------|
| condensé (v2.3) | `config_prompts.py` | 14 condensés | 9 condensés |
| enrichi (v2.4) | `config_prompts_full.py` | 19 enrichis | 9 enrichis (x8-x17) |

## v2.3 (13 février 2026)

### Nouveaux fichiers
- `ground_truth_synalpheus.py` — GT manquant créé (50 questions, 12 types d'erreur, marqueurs FR/EN)
- `5_test_paired.py` — Tests appariés : 200Q identiques posées à toutes configs × modèles
- `6_analyze_paired.py` — Analyse appariée : t-tests pairés, 4 GT, score composite QUALITY

### Corrections
- `4_validate_gpt4o.py` — Configs inexistantes corrigées (`ecosysteme_ocean`/`savane` → configs réelles)

### Limites v2.1 corrigées
- Données non-appariées → appariement strict (mêmes questions partout)
- Pas de validation sémantique → 4 ground truths (exact_match, décision, hallucination, correction)
- GT Synalpheus absent → créé
- T-tests indépendants → t-tests pairés

## v2.2 (11 février 2026)

- `2_test_ecological.py` — Sampling ciblé par ancrage (CONFIG_ANCHOR_MAP)
- `config_prompts.py` — Configs écologiques reconstruites Core Marine 11 uniquement
- `dataset_500q.py` — 500Q (ajout 50Q Synalpheus)

## v2.1 (7 février 2026)

- `config_models.py` — Remplacement Phi-4/Ministral 14B → Qwen3 8B/Granite3.3 8B (tous <10B)
- Token count Ollama via eval_count (vrais tokens)
- Clients API singletons

## v1.0 (5 février 2026)

- Infrastructure initiale 9 fichiers
- 22 336 tests exécutés (9 modèles × 25 configs × 100Q)
- Résultats publiés HAL/Zenodo

### Ajout post-release
- `7_sensitivity_analysis.py` — Analyse sensibilité regex : precision/recall/F1 des détecteurs vs GT, export désaccords

## v2.4.1 — 2026-03-04

### Patch config_models.py — Filtre DeepSeek-R1 <think>

**Problème :** DeepSeek-R1 8B génère un bloc `<think>...</think>` de raisonnement interne
avant sa réponse finale. Sans filtre, ce bloc contamine :
- Les métriques de tokens (comptage gonflé)
- Le détecteur de verbiage (déclenché sur le raisonnement, pas la réponse)
- Les ground truths (analyse du raisonnement interne au lieu de la réponse finale)

**Fix :**
- Ajout `import re` dans les imports
- Filtre `re.sub(r'<think>.*?</think>', '', content, flags=re.DOTALL).strip()`
  appliqué immédiatement après récupération du contenu Ollama
- Token count basculé sur `len(content.split())` post-filtre
  (eval_count Ollama inclut les tokens <think> — non utilisable pour R1)

**Impact :** correction nécessaire avant tout run impliquant DeepSeek-R1 8B.
