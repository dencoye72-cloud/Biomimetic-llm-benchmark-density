# VERSION

## v2.4 — 13 février 2026

### Nouveaux fichiers

- `config_prompts_full.py` — 35 prompts (7 baselines + 19 positifs enrichis + 9 toxiques enrichis). Les solos utilisent les versions complètes des fiches Core Marine (~100-500 lignes). Les paires/écosystèmes restent condensés.
- `config_prompts_toxic_full.py` — 9 prompts toxiques enrichis construits à partir des fiches Extended Biome réelles (Perroquet, Poulpe, Singe, Hibou, Moqueur, Éléphant, Renard, Lézard Anole, Morpho, Gorille, Ver de Terre, Scarabée), détournés vers un usage toxique. Résout le confound profondeur vs contenu.

### Modifications

- `5_test_paired.py` — Ajout flag `--full` pour tester avec prompts enrichis. CSV output inclut le mode (condensed/full).
- `config_prompts_full.py` — Importe désormais `ECOLOGICAL_TOXIC_FULL` (enrichi) au lieu de `ECOLOGICAL_TOXIC` (condensé).

### Design expérimental 2×2

| Condition | Condensé (v2.3) | Enrichi (v2.4) |
|-----------|-----------------|-----------------|
| Positifs | `config_prompts.py` | `config_prompts_full.py` |
| Toxiques | `config_prompts.py` | `config_prompts_toxic_full.py` |
| Baselines | identiques | identiques |

Ce design isole l'effet contenu (positif vs toxique) de l'effet profondeur (condensé vs enrichi).

### Comparaison v2.3 vs v2.4

| Aspect | v2.3 (condensé) | v2.4 (enrichi) |
|--------|-----------------|-----------------|
| Fichier prompts | `config_prompts.py` | `config_prompts_full.py` |
| eponge_solo | ~20 lignes | ~173 lignes |
| meduse_solo | ~20 lignes | ~224 lignes |
| espadon_solo | ~20 lignes | ~474 lignes |
| poisson_pierre_solo | ~20 lignes | ~292 lignes |
| synalpheus_solo | ~20 lignes | ~215 lignes |
| Solos additionnels | — | poulpe, tortue, dauphin, nemo, seiche (complets) |
| Paires/écosystèmes | condensés | condensés (identiques) |
| Baselines | identiques | identiques |
| Toxiques | condensés (~200 chars) | enrichis (~3 000 chars, x8-x17) |

### Collections de prompts incluses

| Collection | Fichiers | Statut |
|-----------|---------|--------|
| `core_marine_11/` | 12 fiches .txt | Validé (pipeline v1/v2) |
| `extended_biome/` | 37 fiches .txt + README | Non testé (proposé) |
| `MEGA_PROMPT_Argonaute_Complet.txt` | 1 fichier | Orchestrateur |

### Usage

```bash
# v2.3 — condensé (défaut, identique avant)
python 5_test_paired.py

# v2.4 — enrichi
python 5_test_paired.py --full
```

## v2.3 — 13 février 2026

### Nouveaux fichiers

- `ground_truth_synalpheus.py` — 50 questions à prémisses fausses, 12 types d'erreur, marqueurs FR/EN
- `5_test_paired.py` — Tests appariés : mêmes 200Q pour toutes configs × modèles (corrige données non-appariées v1)
- `6_analyze_paired.py` — Analyse appariée : t-tests pairés, 4 GT, score composite QUALITY, LaTeX
- `7_sensitivity_analysis.py` — Analyse sensibilité : P/R/F1 détecteurs regex vs ground truth, export désaccords
- `8_llm_judge.py` — LLM-as-Judge local Ollama : évaluation sémantique, Cohen's kappa, comparaison triple
- `INDEX.md` — Index complet mis à jour
- `CHANGELOG.md` — Changelog technique détaillé

### Corrections

- `4_validate_gpt4o.py` — Configs inexistantes corrigées (`ecosysteme_ocean`/`savane` → configs réelles)

### Limites v2.1 corrigées

| Limite | Correction |
|---|---|
| Données non-appariées | `5_test_paired.py` : mêmes 200Q partout |
| Pas de validation sémantique | 4 GT exploités (exact_match, décision, hallucination, correction) |
| GT Synalpheus manquant | `ground_truth_synalpheus.py` créé (50 entrées) |
| T-tests indépendants | `6_analyze_paired.py` : ttest_rel (pairé) |
| Détection regex non quantifiée | `7_sensitivity_analysis.py` : P/R/F1 vs GT |
| Pas de LLM-as-Judge | `8_llm_judge.py` : juge local Ollama, kappa, comparaison triple |
| Configs fantômes 4_validate | `4_validate_gpt4o.py` corrigé |

### Métriques v2 (inchangé depuis v2.2)

**Ground truth :**
- `exact_match` — correspondance avec ground truth éponge (word boundaries)
- `decision_score` — réponse binaire correcte (méduse)
- `hallucination_score` — admet ignorance sur entité inventée (poisson-pierre)
- `correction_score` — corrige prémisse fausse (synalpheus)
- `concision_score` — ratio tokens attendus/réels
- `semantic_similarity` — sentence-transformers si installé, BoW cosine fallback

**Statistiques :**
- `t_test_paired` — scipy.stats.ttest_rel
- `cohens_d` — effect size
- `bootstrap_ci` — intervalles de confiance 10 000 itérations

### Ce qui n'a PAS changé

- `config_prompts.py` — 30 configs, Core Marine 11
- `config_models.py` — 9 modèles (6 locaux <10B + 3 API)
- `dataset_500q.py` — 500 questions, 10 ancrages × 50
- `metrics_analysis.py` — Métriques et détection défauts
- `ground_truth_eponge.py`, `ground_truth_meduse.py`, `ground_truth_poisson_pierre.py`
- `1_test_baselines.py`, `2_test_ecological.py`, `3_analyze_results.py`
- Documentation : INSTALLATION.md, EXEMPLES.md, RECAPITULATIF.md, paper_template_v9.md

---

## v2.2 — 10 février 2026

### Métriques v2

**Ajoutées :**
- `exact_match` — word boundaries
- `concision_score` — ratio tokens attendus/réels
- `semantic_similarity` — sentence-transformers / BoW fallback
- `t_test_paired`, `cohens_d`, `bootstrap_ci` — stats scipy

**Retirées :**
- `calculate_rouge_l`, `calculate_bleu`, `calculate_perplexity_proxy` — redondants

**Scripts mis à jour :**
- `1_test_baselines.py`, `2_test_ecological.py`, `3_analyze_results.py`, `4_validate_gpt4o.py`

### Ground truth
- `ground_truth_eponge.py` : 50 entrées factuelles

### Config
- `config_models.py` : tous modèles <10B (Phi-4/Ministral 14B → Qwen3 8B/Granite3.3 8B)
- Token count Ollama via eval_count

---

## v2.1 — 7 février 2026

- Sampling ciblé par ancrage (`2_test_ecological.py`)
- Dataset 500Q avec 50Q Synalpheus
- Config prompts reconstruites Core Marine 11

---

## v1.0 — 5 février 2026

- Infrastructure initiale
- 22 336 tests exécutés
- Résultats publiés HAL/Zenodo
