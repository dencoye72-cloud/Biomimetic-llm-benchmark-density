#!/usr/bin/env python3
"""
5_test_paired.py - Tests APPARIÉS v3

CORRECTION MAJEURE vs v2:
- APPARIEMENT STRICT : mêmes questions pour toutes les configs et tous les modèles
- Corrige la limite principale du papier v1 (données non-appariées)
- 4 blocs de 50 questions par ground truth = 200 questions appariées
- Chaque question est posée à CHAQUE config ET CHAQUE modèle
- Permet t-test pairé et comparaisons directes valides

GROUND TRUTHS EXPLOITÉS:
- Éponge (50Q)       → exact_match (réponse factuelle courte)
- Méduse (50Q)        → decision_score (oui/non tranché)
- Poisson-pierre (50Q)→ hallucination_score (entités inventées)
- Synalpheus (50Q)    → correction_score (prémisses fausses)

DESIGN:
- 200 questions × 25 configs × N modèles locaux
- Seed fixe = reproductibilité totale
- Ollama uniquement (RTX 4060, 0€)
- CSV avec colonnes GT pour analyse sémantique

Usage:
    python 5_test_paired.py                    # 200Q × 30 configs condensés (v2.3)
    python 5_test_paired.py --full             # 200Q × 35 configs enrichis (v2.4, positifs ET toxiques enrichis)
    python 5_test_paired.py -q 50              # 50Q (rapide, 1 bloc GT)
    python 5_test_paired.py --models llama3.1:8b gemma2:9b
    python 5_test_paired.py --configs-only baseline_vanilla eponge_solo
"""

import time
import random
import csv
import argparse
from datetime import datetime

from config_prompts import ALL_PROMPTS
try:
    from config_prompts_full import ALL_PROMPTS_FULL
except ImportError:
    ALL_PROMPTS_FULL = None
from config_models import get_available_local_models, call_model
from dataset_500q import QUESTIONS_BY_ANCHOR

# Ground truths
from ground_truth_eponge import (
    check_exact_match as gt_eponge_match,
    get_max_tokens as gt_eponge_max_tokens,
)
from ground_truth_meduse import check_decision as gt_meduse_decision
from ground_truth_poisson_pierre import check_hallucination as gt_pp_hallucination
from ground_truth_synalpheus import check_correction as gt_syn_correction

from metrics_analysis import detect_defects, calculate_concision_score

# ============================================================================
# ARGUMENTS
# ============================================================================

parser = argparse.ArgumentParser(description='Tests APPARIÉS v3 — ground truths')
parser.add_argument('-q', '--questions', type=int, default=200,
                    help='Nombre total questions (50=1 bloc GT, 100=2, 150=3, 200=4)')
parser.add_argument('--seed', type=int, default=42)
parser.add_argument('--models', type=str, nargs='*',
                    help='Modèles spécifiques (ex: --models llama3.1:8b gemma2:9b)')
parser.add_argument('--skip-models', type=str, nargs='*',
                    help='Modèles à ignorer')
parser.add_argument('--configs-only', type=str, nargs='*',
                    help='Configs spécifiques seulement')
parser.add_argument('--full', action='store_true',
                    help='Utiliser prompts enrichis (config_prompts_full.py) au lieu des condensés')
parser.add_argument('--skip-configs', type=str, nargs='*',
                    help='Configs à ignorer')
parser.add_argument('--no-toxic', action='store_true',
                    help='Ignorer configs toxiques')
parser.add_argument('--resume-from', type=str, default=None,
                    help='CSV partiel pour reprendre (skip lignes existantes)')
parser.add_argument('--checkpoint-every', type=int, default=200,
                    help='Sauvegarde intermédiaire toutes les N questions par modèle (défaut: 200)')
parser.add_argument('--no-checkpoint', action='store_true',
                    help='Désactiver les checkpoints intermédiaires')
args = parser.parse_args()

# ============================================================================
# CONSTRUCTION DATASET APPARIÉ
# ============================================================================

# 4 blocs GT avec leurs questions (50 chacun)
GT_BLOCKS = [
    {
        "name": "eponge",
        "anchor": "eponge",
        "gt_func": lambda q, r: gt_eponge_match(q, r),
        "gt_column": "GT_Exact_Match",
        "description": "Exactitude factuelle (réponse courte)",
    },
    {
        "name": "meduse",
        "anchor": "meduse",
        "gt_func": lambda q, r: gt_meduse_decision(q, r),
        "gt_column": "GT_Decision",
        "description": "Décision binaire tranchée",
    },
    {
        "name": "poisson_pierre",
        "anchor": "poisson_pierre",
        "gt_func": lambda q, r: gt_pp_hallucination(q, r),
        "gt_column": "GT_Hallucination",
        "description": "Résistance hallucination (entités inventées)",
    },
    {
        "name": "synalpheus",
        "anchor": "synalpheus",
        "gt_func": lambda q, r: gt_syn_correction(q, r),
        "gt_column": "GT_Correction",
        "description": "Résistance soumission aveugle (prémisses fausses)",
    },
]

print("=" * 80)
print("TESTS APPARIÉS v3 — GROUND TRUTHS")
print("=" * 80)

# Construire le dataset apparié
random.seed(args.seed)

# Calculer combien de blocs GT inclure
n_blocks = min(4, max(1, args.questions // 50))
remaining = args.questions - (n_blocks * 50)

paired_questions = []
for i in range(n_blocks):
    block = GT_BLOCKS[i]
    anchor_questions = QUESTIONS_BY_ANCHOR[block["anchor"]]
    # Prendre les 50 questions du bloc (toutes, pas d'échantillonnage)
    for q in anchor_questions:
        paired_questions.append({
            "question": q,
            "gt_block": block["name"],
            "gt_column": block["gt_column"],
            "gt_func": block["gt_func"],
        })

# Si questions restantes, piocher équilibré dans les blocs actifs
if remaining > 0:
    extra_pool = []
    for i in range(n_blocks):
        block = GT_BLOCKS[i]
        extra_pool.extend([
            {"question": q, "gt_block": block["name"],
             "gt_column": block["gt_column"], "gt_func": block["gt_func"]}
            for q in QUESTIONS_BY_ANCHOR[block["anchor"]]
            if q not in [pq["question"] for pq in paired_questions]
        ])
    # S'il reste des questions non utilisées, les ajouter
    if extra_pool:
        paired_questions.extend(random.sample(extra_pool, min(remaining, len(extra_pool))))

N_QUESTIONS = len(paired_questions)
print(f"\nDataset apparié: {N_QUESTIONS} questions")
for i in range(n_blocks):
    block = GT_BLOCKS[i]
    count = sum(1 for pq in paired_questions if pq["gt_block"] == block["name"])
    print(f"  {block['name']:20s}: {count:3d} questions — {block['description']}")

# ============================================================================
# SÉLECTION PROMPTS (condensés v2.3 ou enrichis v2.4)
# ============================================================================

if args.full:
    if ALL_PROMPTS_FULL is None:
        print("ERREUR: config_prompts_full.py non trouvé. --full désactivé.")
        ACTIVE_PROMPTS = ALL_PROMPTS
        prompt_mode = "condensed"
    else:
        ACTIVE_PROMPTS = ALL_PROMPTS_FULL
        prompt_mode = "full"
        print(f"\n🔬 MODE ENRICHI (v2.4): {len(ACTIVE_PROMPTS)} prompts (versions complètes Core Marine)")
else:
    ACTIVE_PROMPTS = ALL_PROMPTS
    prompt_mode = "condensed"

if args.configs_only:
    CONFIG_NAMES = [c for c in args.configs_only if c in ACTIVE_PROMPTS]
else:
    CONFIG_NAMES = list(ACTIVE_PROMPTS.keys())
    if args.no_toxic:
        CONFIG_NAMES = [c for c in CONFIG_NAMES if 'toxic' not in c]
    if args.skip_configs:
        CONFIG_NAMES = [c for c in CONFIG_NAMES if c not in args.skip_configs]

if not CONFIG_NAMES:
    print("\nERREUR: Aucune config sélectionnée")
    exit(1)

# ============================================================================
# SÉLECTION MODÈLES
# ============================================================================

MODELS = get_available_local_models()
if args.models:
    MODELS = [m for m in MODELS if m['id'] in args.models]
if args.skip_models:
    MODELS = [m for m in MODELS if m['id'] not in args.skip_models]

if not MODELS:
    print("\nERREUR: Aucun modèle local disponible")
    print("Vérifiez qu'Ollama est lancé et que des modèles sont installés")
    exit(1)

# ============================================================================
# CHECKPOINT — DÉTECTION AUTO
# ============================================================================

import glob as _glob
import os as _os

def _checkpoint_path(prompt_mode):
    return f"checkpoint_paired_{prompt_mode}.csv"

def _save_checkpoint(rows, prompt_mode):
    """Écrit le checkpoint (résultats accumulés jusqu'ici)."""
    path = _checkpoint_path(prompt_mode)
    with open(path, 'w', newline='', encoding='utf-8') as f:
        if rows:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
    print(f"  💾 Checkpoint: {len(rows)} résultats → {path}")

# Détection auto du checkpoint si --resume-from absent
_auto_checkpoint = _checkpoint_path(
    "full" if (args.full and ALL_PROMPTS_FULL) else "condensed"
)
if not args.resume_from and not args.no_checkpoint and _os.path.exists(_auto_checkpoint):
    print(f"\n⚡ Checkpoint détecté: {_auto_checkpoint}")
    print(f"   Utilisation automatique pour reprise. (--no-checkpoint pour ignorer)")
    args.resume_from = _auto_checkpoint

# ============================================================================
# REPRISE OPTIONNELLE
# ============================================================================

existing_keys = set()
if args.resume_from:
    try:
        with open(args.resume_from, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                key = (row.get('Model_ID', ''), row.get('Config', ''), row.get('Question', ''))
                existing_keys.add(key)
        print(f"\nReprise: {len(existing_keys)} résultats existants chargés depuis {args.resume_from}")
    except FileNotFoundError:
        print(f"\n⚠️  Fichier reprise non trouvé: {args.resume_from} — démarrage from scratch")

# ============================================================================
# CALCUL TOTAL
# ============================================================================

total_tests = N_QUESTIONS * len(CONFIG_NAMES) * len(MODELS)
skip_count = 0
for model in MODELS:
    for config_name in CONFIG_NAMES:
        for pq in paired_questions:
            key = (model['id'], config_name, pq['question'])
            if key in existing_keys:
                skip_count += 1
effective_tests = total_tests - skip_count

print(f"\nConfiguration:")
print(f"  Questions appariées: {N_QUESTIONS}")
print(f"  Configs: {len(CONFIG_NAMES)}")
print(f"  Modèles: {len(MODELS)}")
print(f"  Total tests: {total_tests}")
if skip_count > 0:
    print(f"  Déjà faits (skip): {skip_count}")
    print(f"  Tests restants: {effective_tests}")
print(f"  Temps estimé: ~{effective_tests * 25 / 3600:.1f}h (à ~25s/test)")

print(f"\nModèles: {', '.join(m['name'] for m in MODELS)}")
n_baseline = sum(1 for c in CONFIG_NAMES if c.startswith('baseline_') and 'argonaute' not in c)
n_positive = sum(1 for c in CONFIG_NAMES if not c.startswith('baseline_') and 'toxic' not in c)
n_positive += sum(1 for c in CONFIG_NAMES if c == 'baseline_argonaute')
n_toxic = sum(1 for c in CONFIG_NAMES if 'toxic' in c)
print(f"Configs: {n_baseline} baselines + {n_positive} positifs + {n_toxic} toxiques = {len(CONFIG_NAMES)}")
print(f"\nLancement...\n")

# ============================================================================
# EXÉCUTION
# ============================================================================

results = []
current_test = 0
start_time = time.time()

# Structure: pour chaque question, on passe TOUTES les configs × modèles
# Cela garantit l'appariement (même question vue par tout le monde)
for model in MODELS:
    print(f"\n{'=' * 80}")
    print(f"  {model['name']} ({model.get('size', model['type'])})")
    print(f"{'=' * 80}\n")

    questions_done_this_model = 0  # compteur pour checkpoint par modèle

    for config_name in CONFIG_NAMES:
        system_prompt = ACTIVE_PROMPTS[config_name]
        config_short = config_name.replace('baseline_', 'B:').replace('toxic_', 'T:').replace('ecosysteme_', 'E:')
        category = "toxic" if "toxic" in config_name else ("baseline" if config_name in [
            'baseline_vanilla', 'baseline_cot', 'baseline_concise',
            'baseline_few_shot', 'baseline_negative', 'baseline_structured',
            'baseline_meta'] else "positive")

        for i, pq in enumerate(paired_questions, 1):
            current_test += 1
            question = pq["question"]

            # Skip si reprise
            key = (model['id'], config_name, question)
            if key in existing_keys:
                continue

            progress = (current_test / total_tests) * 100

            if i % max(1, N_QUESTIONS // 5) == 0 or i == 1:
                elapsed = time.time() - start_time
                done = current_test - skip_count if skip_count else current_test
                if done > 0:
                    eta = (elapsed / done) * (effective_tests - done)
                else:
                    eta = 0
                print(f"  [{progress:5.1f}%] {config_short:25s} | Q {i}/{N_QUESTIONS} | ETA: {eta/60:.1f}min")

            response, tokens, elapsed_ms = call_model(model, system_prompt, question)

            if response is None:
                continue

            # Métriques standard
            defects = detect_defects(response, question)
            concision = calculate_concision_score(response, question)

            # Ground truth spécifique au bloc
            gt_score = pq["gt_func"](question, response)

            # Exact match éponge (pour toutes les questions éponge)
            em = gt_eponge_match(question, response)

            row = {
                "Model": model['name'],
                "Model_ID": model['id'],
                "Model_Type": model['type'],
                "Provider": model['provider'],
                "Config": config_name,
                "Category": category,
                "GT_Block": pq["gt_block"],
                "Question": question,
                "Response": response,
                "Tokens": tokens,
                "Elapsed_ms": elapsed_ms,
                "Defects": ",".join(defects),
                "Total_Defects": len(defects),
                "Concision_Score": round(concision, 4),
                # Ground truths (None pour questions hors bloc)
                "GT_Exact_Match": em,
                "GT_Decision": gt_meduse_decision(question, response) if pq["gt_block"] == "meduse" else None,
                "GT_Hallucination": gt_pp_hallucination(question, response) if pq["gt_block"] == "poisson_pierre" else None,
                "GT_Correction": gt_syn_correction(question, response) if pq["gt_block"] == "synalpheus" else None,
            }
            results.append(row)
            existing_keys.add(key)  # évite doublons si crash + reprise mid-checkpoint

            # Checkpoint intermédiaire
            if not args.no_checkpoint:
                questions_done_this_model += 1
                if questions_done_this_model % args.checkpoint_every == 0:
                    # Fusionner avec anciens résultats pour checkpoint complet
                    if args.resume_from and _os.path.exists(args.resume_from):
                        try:
                            with open(args.resume_from, 'r', encoding='utf-8') as f_old:
                                old_rows = list(csv.DictReader(f_old))
                            _save_checkpoint(old_rows + results, prompt_mode)
                        except Exception:
                            _save_checkpoint(results, prompt_mode)
                    else:
                        _save_checkpoint(results, prompt_mode)

total_elapsed = time.time() - start_time
print(f"\nTemps total: {total_elapsed/60:.1f} min ({total_elapsed/3600:.1f}h)")

# ============================================================================
# SAUVEGARDE
# ============================================================================

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
csv_file = f"results_paired_{prompt_mode}_{timestamp}.csv"

# Si reprise, fusionner avec résultats existants
if args.resume_from and existing_keys:
    try:
        with open(args.resume_from, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            old_results = list(reader)
        results = old_results + results
        print(f"\nFusion: {len(old_results)} anciens + {len(results) - len(old_results)} nouveaux")
    except Exception as e:
        print(f"⚠️  Erreur fusion: {e}")

with open(csv_file, 'w', newline='', encoding='utf-8') as f:
    if results:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)

print(f"\nSauvegardé: {csv_file} ({len(results)} résultats)")

# Supprimer le checkpoint si run terminé proprement
if not args.no_checkpoint:
    _cp = _checkpoint_path(prompt_mode)
    if _os.path.exists(_cp):
        _os.remove(_cp)
        print(f"  🧹 Checkpoint supprimé: {_cp}")

# ============================================================================
# APERÇU RÉSULTATS
# ============================================================================

from metrics_analysis import aggregate_by_config, rank_by_tokens
import statistics

print(f"\n{'=' * 80}")
print("APERÇU — RANKING PAR TOKENS (toutes questions confondues)")
print(f"{'=' * 80}\n")

stats = aggregate_by_config(results)
ranked = rank_by_tokens(stats)

for i, (config, stat) in enumerate(ranked[:15], 1):
    co = f"{stat['concision_mean']:.2f}" if stat.get('concision_mean') is not None else "---"
    print(f"  {i:2d}. {config:35s} | {stat['tokens_mean']:6.1f} tok | {stat['defects_mean']:.2f} def | Con={co} | n={stat['count']}")

# Aperçu Ground Truths
print(f"\n{'=' * 80}")
print("APERÇU — SCORES GROUND TRUTH PAR CONFIG")
print(f"{'=' * 80}\n")

gt_columns = ["GT_Exact_Match", "GT_Decision", "GT_Hallucination", "GT_Correction"]
gt_labels = ["EM(éponge)", "Dec(méduse)", "Hal(pp)", "Cor(syn)"]

# Agrégation GT par config
gt_by_config = {}
for r in results:
    config = r.get('Config', 'unknown')
    if config not in gt_by_config:
        gt_by_config[config] = {col: [] for col in gt_columns}
    for col in gt_columns:
        val = r.get(col)
        if val is not None:
            try:
                gt_by_config[config][col].append(float(val))
            except (ValueError, TypeError):
                pass

# Affichage top 15 par tokens
for i, (config, _) in enumerate(ranked[:15], 1):
    if config not in gt_by_config:
        continue
    scores = []
    for col, label in zip(gt_columns, gt_labels):
        vals = gt_by_config[config][col]
        if vals:
            scores.append(f"{label}={statistics.mean(vals):.2f}")
        else:
            scores.append(f"{label}=---")
    print(f"  {i:2d}. {config:35s} | {' | '.join(scores)}")

print(f"\nProchaine étape: python 6_analyze_paired.py")
