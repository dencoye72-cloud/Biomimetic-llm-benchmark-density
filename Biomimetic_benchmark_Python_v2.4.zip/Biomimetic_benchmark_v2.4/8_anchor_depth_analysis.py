#!/usr/bin/env python3
"""
8_anchor_depth_analysis.py - Analyse de l'effet de la profondeur d'ancrage

OBJECTIF:
Quantifier l'effet de la profondeur des prompts bioméimétiques en comparant
directement les résultats condensés (v2.3) vs enrichis (v2.4 --full).

C'est la section "Effect of anchor depth" du papier v2.

MÉTHODE:
- Charge results_paired_condensed_*.csv  (5_test_paired.py sans --full)
- Charge results_paired_full_*.csv       (5_test_paired.py --full)
- Apparie les résultats par (Model, Config, Question)
- Calcule les deltas sur GT scores, tokens, défauts
- T-test pairé + Cohen's d + Bootstrap CI pour chaque métrique
- Identifie les configs qui bénéficient le plus de l'enrichissement
- Génère tableau LaTeX publication-ready

USAGE:
    python 8_anchor_depth_analysis.py
    python 8_anchor_depth_analysis.py --dir ./resultats
    python 8_anchor_depth_analysis.py --export-csv
    python 8_anchor_depth_analysis.py --focus eponge_solo symbiose_eponge_synalpheus
    python 8_anchor_depth_analysis.py --latex
"""

import csv
import glob
import os
import argparse
import statistics
import sys
from datetime import datetime
from collections import defaultdict

from metrics_analysis import (
    t_test_paired, cohens_d, bootstrap_ci,
    aggregate_by_config,
)

csv.field_size_limit(10_000_000)

# ============================================================================
# ENREGISTREMENT AUTOMATIQUE DE LA SORTIE CONSOLE
# ============================================================================

class Tee:
    """Redirige stdout vers console ET fichier simultanément."""
    def __init__(self, filepath):
        self.terminal = sys.__stdout__
        self.file = open(filepath, 'w', encoding='utf-8')
    def write(self, message):
        self.terminal.write(message)
        self.file.write(message)
    def flush(self):
        self.terminal.flush()
        self.file.flush()
    def close(self):
        self.file.close()

_date = datetime.now().strftime("%Y%m%d")
_output_file = f"anchor_depth_analysis_v2_{_date}.txt"
sys.stdout = Tee(_output_file)

# ============================================================================
# ARGUMENTS
# ============================================================================

parser = argparse.ArgumentParser(description='Analyse effet profondeur ancrage — condensé vs enrichi')
parser.add_argument('--dir', type=str, default='.', help='Dossier CSV résultats')
parser.add_argument('--export-csv', action='store_true',
                    help='Exporter les deltas par paire dans un CSV')
parser.add_argument('--focus', type=str, nargs='*',
                    help='Configs à analyser en détail (ex: --focus eponge_solo symbiose_eponge_synalpheus)')
parser.add_argument('--latex', action='store_true',
                    help='Générer le tableau LaTeX pour le papier v2')
parser.add_argument('--min-pairs', type=int, default=10,
                    help='Nombre minimum de paires pour inclure une config (défaut: 10)')
args = parser.parse_args()

print("=" * 80)
print("ANALYSE EFFET PROFONDEUR D'ANCRAGE — condensé vs enrichi")
print("Section: 'Effect of anchor depth' — Papier v2")
print("=" * 80)

# ============================================================================
# CHARGEMENT
# ============================================================================

search_dir = args.dir

condensed_files = sorted(glob.glob(os.path.join(search_dir, "results_paired_condensed_*.csv")))
full_files      = sorted(glob.glob(os.path.join(search_dir, "results_paired_full_*.csv")))

if not condensed_files:
    print(f"\nERREUR: Aucun results_paired_condensed_*.csv dans {search_dir}/")
    print("Exécutez d'abord: python 5_test_paired.py")
    exit(1)

if not full_files:
    print(f"\nERREUR: Aucun results_paired_full_*.csv dans {search_dir}/")
    print("Exécutez d'abord: python 5_test_paired.py --full")
    exit(1)


def load_csv(filepath):
    results = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Conversions numériques
            for int_col in ['Tokens', 'Total_Defects', 'Elapsed_ms']:
                if int_col in row:
                    try:
                        row[int_col] = int(row[int_col])
                    except (ValueError, TypeError):
                        row[int_col] = 0
            for float_col in ['GT_Exact_Match', 'GT_Decision', 'GT_Hallucination',
                               'GT_Correction', 'Concision_Score']:
                if float_col in row and row[float_col] not in (None, '', 'None'):
                    try:
                        row[float_col] = float(row[float_col])
                    except (ValueError, TypeError):
                        row[float_col] = None
                else:
                    row[float_col] = None
            results.append(row)
    return results


print("\nChargement des CSV condensés:")
condensed_data = []
for f in condensed_files:
    d = load_csv(f)
    condensed_data.extend(d)
    print(f"  {os.path.basename(f)}: {len(d)} résultats")

print("\nChargement des CSV enrichis:")
full_data = []
for f in full_files:
    d = load_csv(f)
    full_data.extend(d)
    print(f"  {os.path.basename(f)}: {len(d)} résultats")

print(f"\nTotal condensé : {len(condensed_data)} résultats")
print(f"Total enrichi  : {len(full_data)} résultats")

# ============================================================================
# APPARIEMENT (Model, Config, Question)
# ============================================================================

print(f"\n{'=' * 80}")
print("APPARIEMENT condensé ↔ enrichi")
print(f"{'=' * 80}")

def make_key(row):
    return (
        row.get('Model', '').strip(),
        row.get('Config', '').strip(),
        row.get('Question', '').strip(),
    )

condensed_index = {make_key(r): r for r in condensed_data}
full_index      = {make_key(r): r for r in full_data}

common_keys = set(condensed_index.keys()) & set(full_index.keys())
only_condensed = set(condensed_index.keys()) - set(full_index.keys())
only_full      = set(full_index.keys()) - set(condensed_index.keys())

print(f"\n  Paires appariées       : {len(common_keys)}")
print(f"  Seulement dans condensé: {len(only_condensed)}")
print(f"  Seulement dans enrichi : {len(only_full)}")

if len(common_keys) == 0:
    print("\nERREUR: Aucune paire appariée — vérifier que les CSV ont les mêmes modèles/questions.")
    exit(1)

# Construire les paires
pairs = [(condensed_index[k], full_index[k]) for k in sorted(common_keys)]

# ============================================================================
# CALCUL DES DELTAS
# ============================================================================

print(f"\n{'=' * 80}")
print("DELTAS GLOBAUX — enrichi vs condensé")
print(f"{'=' * 80}")


def safe_delta(row_full, row_condensed, col):
    """Delta enrichi - condensé pour une colonne numérique."""
    v_full = row_full.get(col)
    v_cond = row_condensed.get(col)
    if v_full is None or v_cond is None:
        return None
    try:
        return float(v_full) - float(v_cond)
    except (ValueError, TypeError):
        return None


# Métriques à comparer
METRICS = [
    ('GT_Exact_Match',   'GT Exact Match',   True,   'score [0-1]'),
    ('GT_Decision',      'GT Décision',       True,   'score [0-1]'),
    ('GT_Hallucination', 'GT Hallucination',  True,   'score [0-1]'),
    ('GT_Correction',    'GT Correction',     True,   'score [0-1]'),
    ('Tokens',           'Tokens',            False,  'tokens'),
    ('Total_Defects',    'Défauts totaux',    False,  'count'),
    ('Concision_Score',  'Score concision',   True,   'score [0-1]'),
]


def analyze_metric(pairs, col, higher_is_better):
    """Analyse une métrique sur toutes les paires valides."""
    vals_cond = []
    vals_full = []
    for r_cond, r_full in pairs:
        vc = r_cond.get(col)
        vf = r_full.get(col)
        if vc is None or vf is None:
            continue
        try:
            vals_cond.append(float(vc))
            vals_full.append(float(vf))
        except (ValueError, TypeError):
            continue
    if len(vals_cond) < 2:
        return None
    deltas = [f - c for f, c in zip(vals_full, vals_cond)]
    mean_cond = statistics.mean(vals_cond)
    mean_full = statistics.mean(vals_full)
    mean_delta = statistics.mean(deltas)
    try:
        t_stat, p_val = t_test_paired(vals_full, vals_cond)
    except Exception:
        t_stat, p_val = None, None
    d = cohens_d(vals_full, vals_cond)
    ci_lo, ci_hi, _ = bootstrap_ci(deltas)
    return {
        'n': len(vals_cond),
        'mean_condensed': mean_cond,
        'mean_full': mean_full,
        'mean_delta': mean_delta,
        'pct_change': (mean_delta / mean_cond * 100) if mean_cond != 0 else 0,
        't_stat': t_stat,
        'p_value': p_val,
        'cohens_d': d,
        'ci_lower': ci_lo,
        'ci_upper': ci_hi,
        'higher_is_better': higher_is_better,
    }


def effect_label(d_val):
    ad = abs(d_val)
    if ad < 0.2:   return "négligeable"
    elif ad < 0.5: return "petit"
    elif ad < 0.8: return "moyen"
    else:           return "large"


def significance_label(p_val):
    if p_val is None: return "n/a"
    if p_val < 0.001: return "***"
    if p_val < 0.01:  return "**"
    if p_val < 0.05:  return "*"
    return "ns"


global_results = {}
print(f"\n  {'Métrique':22s} | {'Condensé':>9s} | {'Enrichi':>9s} | {'Δ':>8s} | {'Δ%':>7s} | {'p':>8s} | {'sig':>4s} | {'Cohen d':>8s} | {'effet'}")
print("  " + "-" * 110)

for col, label, higher, unit in METRICS:
    res = analyze_metric(pairs, col, higher)
    if res is None:
        print(f"  {label:22s} | (données insuffisantes)")
        continue
    global_results[col] = res
    sig = significance_label(res['p_value'])
    eff = effect_label(res['cohens_d'])
    p_str = f"{res['p_value']:.4f}" if res['p_value'] is not None else "n/a"
    arrow = "↑" if res['mean_delta'] > 0 else ("↓" if res['mean_delta'] < 0 else "=")
    if higher:
        positive = res['mean_delta'] > 0
    else:
        positive = res['mean_delta'] < 0
    marker = "✓" if positive else ("✗" if res['mean_delta'] != 0 else "=")
    print(f"  {label:22s} | {res['mean_condensed']:9.4f} | {res['mean_full']:9.4f} | "
          f"{arrow}{abs(res['mean_delta']):7.4f} | {res['pct_change']:+6.1f}% | "
          f"{p_str:>8s} | {sig:>4s} | {res['cohens_d']:+8.4f} | {eff} {marker}")

# ============================================================================
# ANALYSE PAR GROUND TRUTH — SCORE COMPOSITE
# ============================================================================

print(f"\n{'=' * 80}")
print("SCORE COMPOSITE QUALITY (moyenne GT disponibles)")
print(f"{'=' * 80}")

GT_COLS = ['GT_Exact_Match', 'GT_Decision', 'GT_Hallucination', 'GT_Correction']


def compute_quality(row):
    vals = []
    for col in GT_COLS:
        v = row.get(col)
        if v is not None:
            try:
                vals.append(float(v))
            except (ValueError, TypeError):
                pass
    return statistics.mean(vals) if vals else None


quality_pairs_cond = []
quality_pairs_full = []
for r_cond, r_full in pairs:
    qc = compute_quality(r_cond)
    qf = compute_quality(r_full)
    if qc is not None and qf is not None:
        quality_pairs_cond.append(qc)
        quality_pairs_full.append(qf)

if len(quality_pairs_cond) >= 2:
    deltas_q = [f - c for f, c in zip(quality_pairs_full, quality_pairs_cond)]
    mean_q_cond = statistics.mean(quality_pairs_cond)
    mean_q_full = statistics.mean(quality_pairs_full)
    mean_dq = statistics.mean(deltas_q)
    try:
        t_q, p_q = t_test_paired(quality_pairs_full, quality_pairs_cond)
    except Exception:
        t_q, p_q = None, None
    d_q = cohens_d(quality_pairs_full, quality_pairs_cond)
    ci_lo_q, ci_hi_q, _ = bootstrap_ci(deltas_q)

    print(f"\n  n paires valides   : {len(quality_pairs_cond)}")
    print(f"  Quality condensé   : {mean_q_cond:.4f}")
    print(f"  Quality enrichi    : {mean_q_full:.4f}")
    print(f"  Δ Quality          : {mean_dq:+.4f}  ({mean_dq/mean_q_cond*100:+.1f}%)")
    print(f"  Bootstrap CI 95%   : [{ci_lo_q:+.4f}, {ci_hi_q:+.4f}]")
    if p_q is not None:
        print(f"  t-test pairé       : t={t_q:.3f}, p={p_q:.4f} {significance_label(p_q)}")
    print(f"  Cohen's d          : {d_q:.4f} ({effect_label(d_q)})")

    if p_q is not None and p_q < 0.05 and mean_dq > 0:
        print(f"\n  ✓ L'enrichissement améliore significativement la qualité globale.")
    elif p_q is not None and p_q < 0.05 and mean_dq < 0:
        print(f"\n  ✗ L'enrichissement dégrade significativement la qualité globale.")
    else:
        print(f"\n  ≈ Pas d'effet significatif de l'enrichissement sur la qualité globale.")

# ============================================================================
# ANALYSE PAR CONFIG
# ============================================================================

print(f"\n{'=' * 80}")
print("EFFET PAR CONFIG — classement par Δ Quality")
print(f"{'=' * 80}")

# Grouper les paires par config
config_pairs = defaultdict(list)
for r_cond, r_full in pairs:
    config = r_cond.get('Config', 'unknown')
    config_pairs[config].append((r_cond, r_full))

config_results = {}
for config, cpairs in config_pairs.items():
    if len(cpairs) < args.min_pairs:
        continue
    q_cond_list = []
    q_full_list = []
    for rc, rf in cpairs:
        qc = compute_quality(rc)
        qf = compute_quality(rf)
        if qc is not None and qf is not None:
            q_cond_list.append(qc)
            q_full_list.append(qf)
    if len(q_cond_list) < 2:
        continue
    deltas = [f - c for f, c in zip(q_full_list, q_cond_list)]
    mean_delta = statistics.mean(deltas)
    try:
        t_stat, p_val = t_test_paired(q_full_list, q_cond_list)
    except Exception:
        t_stat, p_val = None, None
    d = cohens_d(q_full_list, q_cond_list)
    ci_lo, ci_hi, _ = bootstrap_ci(deltas)
    config_results[config] = {
        'n': len(q_cond_list),
        'mean_cond': statistics.mean(q_cond_list),
        'mean_full': statistics.mean(q_full_list),
        'mean_delta': mean_delta,
        'cohens_d': d,
        'p_value': p_val,
        'ci_lower': ci_lo,
        'ci_upper': ci_hi,
    }

# Trier par delta décroissant
ranked_configs = sorted(config_results.items(), key=lambda x: x[1]['mean_delta'], reverse=True)

print(f"\n  {'Config':35s} | {'n':>5s} | {'Cond':>7s} | {'Full':>7s} | {'Δ':>7s} | {'p':>8s} | {'sig':>4s} | {'d':>7s}")
print("  " + "-" * 100)

for config, res in ranked_configs:
    sig = significance_label(res['p_value'])
    p_str = f"{res['p_value']:.4f}" if res['p_value'] is not None else "n/a"
    arrow = "▲" if res['mean_delta'] > 0 else ("▼" if res['mean_delta'] < 0 else "=")
    print(f"  {config:35s} | {res['n']:5d} | {res['mean_cond']:7.4f} | {res['mean_full']:7.4f} | "
          f"{arrow}{abs(res['mean_delta']):6.4f} | {p_str:>8s} | {sig:>4s} | {res['cohens_d']:+7.4f}")

# Top 3 gagnants / perdants
if ranked_configs:
    print(f"\n  TOP 3 configs qui bénéficient le plus de l'enrichissement:")
    for config, res in ranked_configs[:3]:
        sig = significance_label(res['p_value'])
        print(f"    + {config}: Δ={res['mean_delta']:+.4f} (d={res['cohens_d']:+.3f}, {sig})")

    print(f"\n  TOP 3 configs les moins aidées (ou dégradées):")
    for config, res in ranked_configs[-3:]:
        sig = significance_label(res['p_value'])
        print(f"    - {config}: Δ={res['mean_delta']:+.4f} (d={res['cohens_d']:+.3f}, {sig})")

# ============================================================================
# ANALYSE PAR MODÈLE
# ============================================================================

print(f"\n{'=' * 80}")
print("EFFET PAR MODÈLE")
print(f"{'=' * 80}")

model_pairs = defaultdict(list)
for r_cond, r_full in pairs:
    model = r_cond.get('Model', 'unknown')
    model_pairs[model].append((r_cond, r_full))

model_results = {}
for model, mpairs in model_pairs.items():
    q_cond_list, q_full_list = [], []
    for rc, rf in mpairs:
        qc = compute_quality(rc)
        qf = compute_quality(rf)
        if qc is not None and qf is not None:
            q_cond_list.append(qc)
            q_full_list.append(qf)
    if len(q_cond_list) < 2:
        continue
    deltas = [f - c for f, c in zip(q_full_list, q_cond_list)]
    try:
        t_stat, p_val = t_test_paired(q_full_list, q_cond_list)
    except Exception:
        t_stat, p_val = None, None
    d = cohens_d(q_full_list, q_cond_list)
    model_results[model] = {
        'n': len(q_cond_list),
        'mean_cond': statistics.mean(q_cond_list),
        'mean_full': statistics.mean(q_full_list),
        'mean_delta': statistics.mean(deltas),
        'cohens_d': d,
        'p_value': p_val,
    }

ranked_models = sorted(model_results.items(), key=lambda x: x[1]['mean_delta'], reverse=True)

print(f"\n  {'Modèle':30s} | {'n':>6s} | {'Cond':>7s} | {'Full':>7s} | {'Δ':>7s} | {'p':>8s} | {'sig':>4s} | {'d':>7s}")
print("  " + "-" * 100)
for model, res in ranked_models:
    sig = significance_label(res['p_value'])
    p_str = f"{res['p_value']:.4f}" if res['p_value'] is not None else "n/a"
    arrow = "▲" if res['mean_delta'] > 0 else ("▼" if res['mean_delta'] < 0 else "=")
    print(f"  {model:30s} | {res['n']:6d} | {res['mean_cond']:7.4f} | {res['mean_full']:7.4f} | "
          f"{arrow}{abs(res['mean_delta']):6.4f} | {p_str:>8s} | {sig:>4s} | {res['cohens_d']:+7.4f}")

# ============================================================================
# FOCUS CONFIGS
# ============================================================================

if args.focus:
    print(f"\n{'=' * 80}")
    print(f"FOCUS CONFIGS: {', '.join(args.focus)}")
    print(f"{'=' * 80}")

    for config in args.focus:
        focus_pairs = [(rc, rf) for rc, rf in pairs if rc.get('Config') == config]
        if not focus_pairs:
            print(f"\n  Config '{config}' non trouvée dans les données.")
            continue
        print(f"\n  Config: {config}  (n={len(focus_pairs)} paires)")

        for col, label, higher, unit in METRICS:
            res = analyze_metric(focus_pairs, col, higher)
            if res is None:
                continue
            sig = significance_label(res['p_value'])
            p_str = f"{res['p_value']:.4f}" if res['p_value'] is not None else "n/a"
            arrow = "↑" if res['mean_delta'] > 0 else ("↓" if res['mean_delta'] < 0 else "=")
            print(f"    {label:22s}: {res['mean_condensed']:.4f} → {res['mean_full']:.4f} "
                  f"({arrow}{abs(res['mean_delta']):.4f}, {res['pct_change']:+.1f}%) "
                  f"p={p_str} {sig}  d={res['cohens_d']:+.3f}")

# ============================================================================
# TABLEAU LATEX
# ============================================================================

if args.latex:
    print(f"\n{'=' * 80}")
    print("TABLEAU LATEX — Effect of Anchor Depth")
    print(f"{'=' * 80}")

    latex_lines = [
        "\\begin{table}[h]",
        "\\centering",
        "\\caption{Effect of anchor depth on model performance (condensed vs. enriched prompts). "
        "\\\\$\\Delta$ = enriched $-$ condensed. Cohen's $d$ effect size. "
        "$^{*}p<0.05$, $^{**}p<0.01$, $^{***}p<0.001$.}",
        "\\label{tab:anchor_depth}",
        "\\begin{tabular}{lcccccc}",
        "\\hline",
        "Metric & Condensed & Enriched & $\\Delta$ & $\\Delta$\\% & $p$ & Cohen's $d$ \\\\",
        "\\hline",
    ]

    for col, label, higher, unit in METRICS:
        res = global_results.get(col)
        if res is None:
            continue
        sig = significance_label(res['p_value'])
        p_str = f"{res['p_value']:.4f}" if res['p_value'] is not None else "---"
        delta_arrow = "+" if res['mean_delta'] >= 0 else ""
        latex_lines.append(
            f"{label} & {res['mean_condensed']:.4f} & {res['mean_full']:.4f} & "
            f"${delta_arrow}{res['mean_delta']:.4f}$ & "
            f"${res['pct_change']:+.1f}\\%$ & "
            f"{p_str}{'^{' + sig.replace('*','\\\\*') + '}' if sig not in ('ns','n/a') else ''} & "
            f"${res['cohens_d']:+.4f}$ \\\\"
        )

    latex_lines += [
        "\\hline",
        "\\end{tabular}",
        "\\end{table}",
    ]

    print()
    for line in latex_lines:
        print(line)

# ============================================================================
# EXPORT CSV
# ============================================================================

if args.export_csv:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_file = os.path.join(search_dir, f"anchor_depth_deltas_{timestamp}.csv")

    fieldnames = [
        'Model', 'Config', 'Question',
        'Tokens_condensed', 'Tokens_full', 'Delta_Tokens',
        'Defects_condensed', 'Defects_full', 'Delta_Defects',
        'GT_Exact_Match_condensed', 'GT_Exact_Match_full', 'Delta_GT_Exact_Match',
        'GT_Decision_condensed', 'GT_Decision_full', 'Delta_GT_Decision',
        'GT_Hallucination_condensed', 'GT_Hallucination_full', 'Delta_GT_Hallucination',
        'GT_Correction_condensed', 'GT_Correction_full', 'Delta_GT_Correction',
        'Quality_condensed', 'Quality_full', 'Delta_Quality',
    ]

    rows = []
    for r_cond, r_full in pairs:
        qc = compute_quality(r_cond)
        qf = compute_quality(r_full)
        row = {
            'Model': r_cond.get('Model', ''),
            'Config': r_cond.get('Config', ''),
            'Question': r_cond.get('Question', ''),
        }
        for col in ['Tokens', 'Total_Defects', 'GT_Exact_Match', 'GT_Decision',
                    'GT_Hallucination', 'GT_Correction']:
            vc = r_cond.get(col)
            vf = r_full.get(col)
            label = col.replace('Total_', '')
            row[f'{label}_condensed'] = vc
            row[f'{label}_full'] = vf
            if vc is not None and vf is not None:
                try:
                    row[f'Delta_{label}'] = float(vf) - float(vc)
                except (ValueError, TypeError):
                    row[f'Delta_{label}'] = None
            else:
                row[f'Delta_{label}'] = None
        row['Quality_condensed'] = qc
        row['Quality_full'] = qf
        row['Delta_Quality'] = (qf - qc) if (qc is not None and qf is not None) else None
        rows.append(row)

    with open(csv_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)

    print(f"\n  Deltas exportés: {csv_file} ({len(rows)} paires)")

# ============================================================================
# SYNTHÈSE FINALE
# ============================================================================

print(f"\n{'=' * 80}")
print("SYNTHÈSE — EFFET DE LA PROFONDEUR D'ANCRAGE")
print(f"{'=' * 80}")

print(f"\n  Paires appariées analysées : {len(pairs)}")
print(f"  Configs analysées          : {len(config_results)}")
print(f"  Modèles analysés           : {len(model_results)}")

# Verdict global
significant_positive = []
significant_negative = []
neutral = []

for col, label, higher, unit in METRICS:
    res = global_results.get(col)
    if res is None:
        continue
    p = res['p_value']
    delta = res['mean_delta']
    if p is not None and p < 0.05:
        if (higher and delta > 0) or (not higher and delta < 0):
            significant_positive.append(label)
        else:
            significant_negative.append(label)
    else:
        neutral.append(label)

if significant_positive:
    print(f"\n  ✓ Améliorations significatives (p<0.05): {', '.join(significant_positive)}")
if significant_negative:
    print(f"\n  ✗ Dégradations significatives (p<0.05): {', '.join(significant_negative)}")
if neutral:
    print(f"\n  ≈ Pas d'effet significatif: {', '.join(neutral)}")

if len(significant_positive) > len(significant_negative):
    print(f"\n  CONCLUSION: L'enrichissement des prompts améliore globalement les performances.")
    print(f"  → Supporte la section 'Effect of anchor depth' du papier v2.")
elif len(significant_negative) > len(significant_positive):
    print(f"\n  CONCLUSION: L'enrichissement dégrade certaines métriques — à analyser.")
else:
    print(f"\n  CONCLUSION: Effets mixtes ou non significatifs — contexte à préciser dans le papier.")

print(f"\n{'=' * 80}")
print("ANALYSE PROFONDEUR D'ANCRAGE TERMINÉE")
print(f"{'=' * 80}")

sys.stdout.close()
sys.stdout = sys.__stdout__
print(f"\nSauvegardé: {_output_file}")
