#!/usr/bin/env python3
"""
6_analyze_paired.py - Analyse des résultats APPARIÉS v3

CORRECTIONS vs 3_analyze_results.py:
- T-tests PAIRÉS (pas Mann-Whitney sur groupes indépendants)
- Exploitation des 4 ground truths (exact_match, decision, hallucination, correction)
- Score composite QUALITY = moyenne des GT disponibles
- Comparaisons directes config-vs-config sur MÊMES questions
- Tableau LaTeX publication-ready avec GT scores

Usage:
    python 6_analyze_paired.py
    python 6_analyze_paired.py --dir ./resultats
    python 6_analyze_paired.py --focus baseline_vanilla eponge_solo symbiose_eponge_synalpheus
"""

import csv
import json
import glob
import os
import argparse
import statistics
import sys
from datetime import datetime
from collections import defaultdict

from metrics_analysis import (
    t_test_paired, cohens_d, bootstrap_ci,
    aggregate_by_config, rank_by_tokens, rank_by_defects,
    generate_latex_table,
)

csv.field_size_limit(10_000_000)

# ============================================================================
# ENREGISTREMENT AUTOMATIQUE DE LA SORTIE CONSOLE
# ============================================================================

class Tee:
    """Redirige stdout vers console ET fichier simultanément."""
    def __init__(self, filepath):
        self.terminal = sys.__stdout__
        self.file = open(filepath, 'w', encoding='utf-8')
    def write(self, message):
        self.terminal.write(message)
        self.file.write(message)
    def flush(self):
        self.terminal.flush()
        self.file.flush()
    def close(self):
        self.file.close()

_date = datetime.now().strftime("%Y%m%d")
_output_file = f"analysis_paired_v2_4_{_date}.txt"
sys.stdout = Tee(_output_file)

parser = argparse.ArgumentParser(description='Analyse résultats appariés v3')
parser.add_argument('--dir', type=str, default='.', help='Dossier CSV')
parser.add_argument('--focus', type=str, nargs='*',
                    help='Configs à comparer en détail (pairwise)')
args = parser.parse_args()

print("=" * 80)
print("ANALYSE APPARIÉE v3 — GROUND TRUTHS")
print("=" * 80)

# ============================================================================
# CHARGEMENT
# ============================================================================

search_dir = args.dir
paired_files = sorted(glob.glob(os.path.join(search_dir, "results_paired_*.csv")))

if not paired_files:
    print(f"\nERREUR: Aucun results_paired_*.csv dans {search_dir}/")
    print("Exécutez d'abord: python 5_test_paired.py")
    exit(1)

def load_csv(filepath):
    results = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            for int_col in ['Tokens', 'Total_Defects', 'Elapsed_ms']:
                if int_col in row:
                    try:
                        row[int_col] = int(row[int_col])
                    except (ValueError, TypeError):
                        row[int_col] = 0
            for float_col in ['Concision_Score', 'GT_Exact_Match', 'GT_Decision',
                              'GT_Hallucination', 'GT_Correction']:
                if float_col in row and row[float_col] not in (None, '', 'None'):
                    try:
                        row[float_col] = float(row[float_col])
                    except (ValueError, TypeError):
                        row[float_col] = None
                else:
                    row[float_col] = None
            results.append(row)
    return results

all_results = []
for f in paired_files:
    data = load_csv(f)
    all_results.extend(data)
    print(f"  Chargé: {os.path.basename(f)} ({len(data)} résultats)")

print(f"\nTotal: {len(all_results)} résultats")

# ============================================================================
# INVENTAIRE
# ============================================================================

models_seen = sorted(set(r.get('Model', '') for r in all_results))
configs_seen = sorted(set(r.get('Config', '') for r in all_results))
questions_seen = sorted(set(r.get('Question', '') for r in all_results))
gt_blocks = sorted(set(r.get('GT_Block', '') for r in all_results))

print(f"  Modèles: {len(models_seen)}")
print(f"  Configs: {len(configs_seen)}")
print(f"  Questions uniques: {len(questions_seen)}")
print(f"  Blocs GT: {gt_blocks}")

# ============================================================================
# AGRÉGATION STANDARD
# ============================================================================

print(f"\n{'=' * 80}")
print("RANKING PAR TOKENS (toutes questions)")
print(f"{'=' * 80}")

stats = aggregate_by_config(all_results)
ranked = rank_by_tokens(stats)

# Séparer catégories
BASELINE_PE = ['baseline_vanilla', 'baseline_cot', 'baseline_concise',
               'baseline_few_shot', 'baseline_negative', 'baseline_structured',
               'baseline_meta']

baseline_stats = {k: v for k, v in stats.items() if k in BASELINE_PE}
positive_stats = {k: v for k, v in stats.items() if k not in BASELINE_PE and 'toxic' not in k}
toxic_stats = {k: v for k, v in stats.items() if 'toxic' in k}

if baseline_stats:
    print(f"\nBASELINES ({len(baseline_stats)}):\n")
    for i, (config, s) in enumerate(rank_by_tokens(baseline_stats), 1):
        name = config.replace('baseline_', '')
        print(f"  {i:2d}. {name:25s} | {s['tokens_mean']:6.1f} tok | {s['defects_mean']:.2f} def | n={s['count']}")

if positive_stats:
    print(f"\nÉCOLOGIQUES POSITIFS ({len(positive_stats)}):\n")
    for i, (config, s) in enumerate(rank_by_tokens(positive_stats), 1):
        print(f"  {i:2d}. {config:35s} | {s['tokens_mean']:6.1f} tok | {s['defects_mean']:.2f} def | n={s['count']}")

if toxic_stats:
    print(f"\nTOXIQUES ({len(toxic_stats)}, décroissant):\n")
    for i, (config, s) in enumerate(sorted(toxic_stats.items(), key=lambda x: -x[1]['tokens_mean']), 1):
        name = config.replace('toxic_', '')
        print(f"  {i:2d}. {name:35s} | {s['tokens_mean']:6.1f} tok | {s['defects_mean']:.2f} def | n={s['count']}")

# ============================================================================
# SCORES GROUND TRUTH PAR CONFIG
# ============================================================================

print(f"\n{'=' * 80}")
print("SCORES GROUND TRUTH PAR CONFIG")
print(f"{'=' * 80}")

GT_COLS = ['GT_Exact_Match', 'GT_Decision', 'GT_Hallucination', 'GT_Correction']
GT_LABELS = ['EM', 'Dec', 'Hal', 'Cor']

gt_by_config = defaultdict(lambda: {col: [] for col in GT_COLS})

for r in all_results:
    config = r.get('Config', 'unknown')
    for col in GT_COLS:
        val = r.get(col)
        if val is not None:
            gt_by_config[config][col].append(val)

# Score composite = moyenne des GT disponibles
composite_scores = {}
for config, gt_data in gt_by_config.items():
    means = []
    for col in GT_COLS:
        vals = gt_data[col]
        if vals:
            means.append(statistics.mean(vals))
    composite_scores[config] = statistics.mean(means) if means else 0.0

# Tri par score composite décroissant
sorted_gt = sorted(composite_scores.items(), key=lambda x: -x[1])

print(f"\n{'Config':35s} | {'EM':>5s} | {'Dec':>5s} | {'Hal':>5s} | {'Cor':>5s} | {'QUAL':>5s}")
print("-" * 80)

for config, composite in sorted_gt:
    parts = []
    for col in GT_COLS:
        vals = gt_by_config[config][col]
        if vals:
            parts.append(f"{statistics.mean(vals):5.2f}")
        else:
            parts.append(f"{'---':>5s}")
    print(f"  {config:33s} | {' | '.join(parts)} | {composite:5.2f}")

# ============================================================================
# TESTS STATISTIQUES PAIRÉS
# ============================================================================

print(f"\n{'=' * 80}")
print("TESTS PAIRÉS (t-test sur mêmes questions)")
print(f"{'=' * 80}")

# Construire vecteurs appariés par (modèle, question)
def get_paired_vectors(config_a, config_b, metric='Tokens'):
    """Retourne deux vecteurs appariés par (modèle, question)."""
    data_a = {}
    data_b = {}
    for r in all_results:
        key = (r.get('Model', ''), r.get('Question', ''))
        if r.get('Config') == config_a:
            try:
                data_a[key] = float(r.get(metric, 0))
            except (ValueError, TypeError):
                pass
        elif r.get('Config') == config_b:
            try:
                data_b[key] = float(r.get(metric, 0))
            except (ValueError, TypeError):
                pass

    # Intersection des clés (mêmes questions × mêmes modèles)
    common_keys = sorted(set(data_a.keys()) & set(data_b.keys()))
    vec_a = [data_a[k] for k in common_keys]
    vec_b = [data_b[k] for k in common_keys]
    return vec_a, vec_b, len(common_keys)


# Comparaisons clés
comparisons = []

# Best baseline vs best positive
if baseline_stats and positive_stats:
    best_bl = min(baseline_stats.items(), key=lambda x: x[1]['tokens_mean'])[0]
    best_eco = min(positive_stats.items(), key=lambda x: x[1]['tokens_mean'])[0]
    comparisons.append((best_bl, best_eco, "Best baseline vs Best écologique"))

# Vanilla vs chaque positif
for config in positive_stats:
    if 'baseline_vanilla' in baseline_stats:
        comparisons.append(('baseline_vanilla', config, f"vanilla vs {config}"))

# Few-shot vs best positive
if 'baseline_few_shot' in baseline_stats and positive_stats:
    best_eco = min(positive_stats.items(), key=lambda x: x[1]['tokens_mean'])[0]
    comparisons.append(('baseline_few_shot', best_eco, f"few_shot vs {best_eco}"))

# Focus pairwise si demandé
if args.focus and len(args.focus) >= 2:
    from itertools import combinations
    for a, b in combinations(args.focus, 2):
        if a in stats and b in stats:
            comparisons.append((a, b, f"FOCUS: {a} vs {b}"))

# Exécuter comparaisons
print(f"\n{'Comparaison':60s} | {'n':>5s} | {'t':>7s} | {'p':>10s} | {'d':>6s} | Interprétation")
print("-" * 120)

for config_a, config_b, label in comparisons[:30]:  # Limiter à 30
    for metric in ['Tokens']:
        vec_a, vec_b, n = get_paired_vectors(config_a, config_b, metric)
        if n < 5:
            continue

        try:
            t, p = t_test_paired(vec_a, vec_b)
            d = cohens_d(vec_a, vec_b)
        except Exception:
            continue

        # Interprétation
        if p > 0.05:
            interp = "NS"
        elif abs(d) < 0.2:
            interp = "négligeable"
        elif abs(d) < 0.5:
            interp = "petit"
        elif abs(d) < 0.8:
            interp = "moyen"
        else:
            interp = "GRAND"

        direction = "A<B" if statistics.mean(vec_a) < statistics.mean(vec_b) else "A>B"

        print(f"  {label:58s} | {n:5d} | {t:7.2f} | {p:10.6f} | {d:6.2f} | {interp} ({direction})")

# ============================================================================
# VALIDATION BIDIRECTIONNELLE (positifs vs toxiques)
# ============================================================================

print(f"\n{'=' * 80}")
print("VALIDATION BIDIRECTIONNELLE")
print(f"{'=' * 80}")

pos_tokens = [r['Tokens'] for r in all_results if r.get('Category') == 'positive']
tox_tokens = [r['Tokens'] for r in all_results if r.get('Category') == 'toxic']
pos_defects = [r['Total_Defects'] for r in all_results if r.get('Category') == 'positive']
tox_defects = [r['Total_Defects'] for r in all_results if r.get('Category') == 'toxic']

if pos_tokens and tox_tokens:
    print(f"\n  Positifs: {statistics.mean(pos_tokens):.1f} tokens, {statistics.mean(pos_defects):.2f} défauts (n={len(pos_tokens)})")
    print(f"  Toxiques: {statistics.mean(tox_tokens):.1f} tokens, {statistics.mean(tox_defects):.2f} défauts (n={len(tox_tokens)})")
    print(f"  Ratio tox/pos tokens: ×{statistics.mean(tox_tokens)/statistics.mean(pos_tokens):.1f}")
    print(f"  Ratio tox/pos défauts: ×{statistics.mean(tox_defects)/max(0.001, statistics.mean(pos_defects)):.1f}")

    d_tokens = cohens_d(tox_tokens, pos_tokens)
    d_defects = cohens_d(tox_defects, pos_defects)
    print(f"  Cohen's d tokens: {d_tokens:.2f}")
    print(f"  Cohen's d défauts: {d_defects:.2f}")

    # Bootstrap CI
    diffs_tokens = [t - p for t, p in zip(
        [statistics.mean(tox_tokens)] * 100,
        [statistics.mean(pos_tokens)] * 100)]

    lo, hi, mean = bootstrap_ci(
        [t - p for t, p in zip(tox_tokens[:min(len(tox_tokens), len(pos_tokens))],
                                pos_tokens[:min(len(tox_tokens), len(pos_tokens))])])
    print(f"  Bootstrap CI 95% (tox-pos tokens): [{lo:.1f}, {hi:.1f}]")

# ============================================================================
# ANALYSE PAR BLOC GT
# ============================================================================

print(f"\n{'=' * 80}")
print("ANALYSE PAR BLOC GROUND TRUTH")
print(f"{'=' * 80}")

for gt_col, gt_label in zip(GT_COLS, ['Exact Match (éponge)', 'Décision (méduse)',
                                        'Hallucination (poisson-pierre)', 'Correction (synalpheus)']):
    print(f"\n  {gt_label}:")
    scores_by_config = []
    for config in configs_seen:
        vals = [r[gt_col] for r in all_results if r.get('Config') == config and r.get(gt_col) is not None]
        if vals:
            scores_by_config.append((config, statistics.mean(vals), len(vals)))

    if not scores_by_config:
        print(f"    (pas de données)")
        continue

    scores_by_config.sort(key=lambda x: -x[1])
    for config, mean_score, n in scores_by_config[:10]:
        print(f"    {config:35s} | score={mean_score:.3f} | n={n}")

# ============================================================================
# CROSS-MODEL
# ============================================================================

print(f"\n{'=' * 80}")
print("ANALYSE CROSS-MODEL")
print(f"{'=' * 80}")

for model in models_seen:
    model_results = [r for r in all_results if r.get('Model') == model]
    if not model_results:
        continue

    model_stats = aggregate_by_config(model_results)
    best = min(model_stats.items(), key=lambda x: x[1]['tokens_mean'])
    worst = max(model_stats.items(), key=lambda x: x[1]['tokens_mean'])

    # Score composite moyen
    model_composites = {config: composite_scores.get(config, 0) for config in model_stats}

    print(f"\n  {model}:")
    print(f"    Tokens — Best: {best[0]:30s} ({best[1]['tokens_mean']:.1f})")
    print(f"    Tokens — Worst: {worst[0]:30s} ({worst[1]['tokens_mean']:.1f})")

# ============================================================================
# SAUVEGARDE
# ============================================================================

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

# Stats JSON
stats_out = {}
for config, s in stats.items():
    stats_out[config] = {
        **s,
        'gt_exact_match': statistics.mean(gt_by_config[config]['GT_Exact_Match']) if gt_by_config[config]['GT_Exact_Match'] else None,
        'gt_decision': statistics.mean(gt_by_config[config]['GT_Decision']) if gt_by_config[config]['GT_Decision'] else None,
        'gt_hallucination': statistics.mean(gt_by_config[config]['GT_Hallucination']) if gt_by_config[config]['GT_Hallucination'] else None,
        'gt_correction': statistics.mean(gt_by_config[config]['GT_Correction']) if gt_by_config[config]['GT_Correction'] else None,
        'quality_composite': composite_scores.get(config, None),
    }

json_file = f"analysis_paired_{timestamp}.json"
with open(json_file, 'w', encoding='utf-8') as f:
    json.dump(stats_out, f, indent=2, default=str)
print(f"\nSauvegardé: {json_file}")

# LaTeX
print(f"\n{'=' * 80}")
print("TABLEAU LATEX (top 15 + GT scores)")
print(f"{'=' * 80}\n")

# Custom LaTeX avec GT
lines = []
lines.append("\\begin{table}[h]")
lines.append("\\centering")
lines.append("\\caption{Paired Evaluation: Token Count and Semantic Quality}")
lines.append("\\begin{tabular}{lccccccc}")
lines.append("\\hline")
lines.append("Approach & Tokens & Def. & EM & Dec & Hal & Cor & QUAL \\\\")
lines.append("\\hline")

for config, composite in sorted_gt[:15]:
    name = config.replace('_', '\\_')[:30]
    s = stats.get(config, {})
    tok = f"{s.get('tokens_mean', 0):.1f}"
    defs = f"{s.get('defects_mean', 0):.2f}"

    gt_vals = []
    for col in GT_COLS:
        vals = gt_by_config[config][col]
        if vals:
            gt_vals.append(f"{statistics.mean(vals):.2f}")
        else:
            gt_vals.append("---")

    lines.append(f"{name} & {tok} & {defs} & {' & '.join(gt_vals)} & {composite:.2f} \\\\")

lines.append("\\hline")
lines.append("\\end{tabular}")
lines.append("\\end{table}")

latex = "\n".join(lines)
print(latex)

latex_file = f"paired_latex_table_{timestamp}.txt"
with open(latex_file, 'w') as f:
    f.write(latex)
print(f"\nSauvegardé: {latex_file}")

print(f"\n{'=' * 80}")
print("ANALYSE APPARIÉE TERMINÉE")
print(f"{'=' * 80}")

sys.stdout.close()
sys.stdout = sys.__stdout__
print(f"\nSauvegardé: {_output_file}")
