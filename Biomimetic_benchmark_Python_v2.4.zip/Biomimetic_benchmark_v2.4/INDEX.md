# INDEX COMPLET DU PACKAGE

## Biomimetic Ecological Anchoring v2.3

---

## STRUCTURE DU PACKAGE

```
biomimetic_benchmark_v2.3/
├── DOCUMENTATION (10 fichiers)
│   ├── README.md                Guide utilisation
│   ├── INSTALLATION.md          Guide installation complet
│   ├── EXEMPLES.md              Cas d'usage détaillés
│   ├── RECAPITULATIF.md         Vue d'ensemble
│   ├── INDEX.md                 Cet index
│   ├── VERSION.md               Changelog v2.2 → v2.3
│   ├── CHANGELOG.md             Changelog technique détaillé
│   ├── paper_template_v9.md     Template papier académique
│   ├── requirements.txt         Dépendances Python
│   └── Claude_Symbiose_Eponge_Synalpheus.txt   System prompt
│
├── MODULES (5 fichiers Python)
│   ├── config_prompts.py        30 prompts système (condensés v2.3)
│   ├── config_prompts_full.py   35 prompts système (enrichis v2.4)
│   ├── config_prompts_toxic_full.py  9 prompts toxiques enrichis (v2.4)
│   ├── core_marine_11/          12 fiches Core Marine complètes (.txt)
│   ├── extended_biome/          37 fiches Extended Biome (.txt) + README
│   ├── MEGA_PROMPT_Argonaute_Complet.txt
│   ├── config_models.py         9 modèles (6 local + 3 API)
│   ├── metrics_analysis.py      Métriques, défauts, stats
│   ├── dataset_500q.py          500 questions (10 ancrages × 50)
│   └── estimate_cost.py         Estimation coûts API
│
├── GROUND TRUTHS (4 fichiers Python)
│   ├── ground_truth_eponge.py           50Q exactitude factuelle
│   ├── ground_truth_meduse.py           50Q décision binaire
│   ├── ground_truth_poisson_pierre.py   50Q résistance hallucination
│   └── ground_truth_synalpheus.py       50Q résistance soumission (NOUVEAU v2.3)
│
├── PIPELINE v3 — APPARIÉ (4 fichiers Python, NOUVEAU v2.3)
│   ├── 5_test_paired.py         Tests appariés 200Q × 30 configs
│   ├── 6_analyze_paired.py      Analyse t-tests pairés + GT scores
│   ├── 7_sensitivity_analysis.py  P/R/F1 regex vs GT
│   └── 8_llm_judge.py           LLM-as-Judge local (Ollama)
│
├── PIPELINE v1/v2 — ORIGINAL (4 fichiers Python)
│   ├── 1_test_baselines.py      Tests baselines PE
│   ├── 2_test_ecological.py     Tests écologiques
│   ├── 3_analyze_results.py     Analyse complète
│   └── 4_validate_gpt4o.py     Validation GPT-4o
│
└── DONNÉES
    └── benchmark_questions_500_v2.txt   Questions texte brut
```

**Total : 29 fichiers racine + 12 core_marine + 38 extended_biome = 80 fichiers**

---

## DOCUMENTATION (PAR ORDRE DE LECTURE)

### 1. INSTALLATION.md — START HERE
Guide installation complet : Ollama, Python, modèles, API keys.

### 2. README.md
Vue d'ensemble, pipelines v1/v2/v3, métriques, usage rapide.

### 3. EXEMPLES.md
Tous les cas d'usage avec commandes, workflows, FAQ.

### 4. RECAPITULATIF.md
Architecture complète, configs, modèles, métriques, objectifs.

### 5. INDEX.md
Cet index.

### 6. VERSION.md / CHANGELOG.md
Historique des versions, corrections v2.3.

---

## PIPELINE v3 — APPARIÉ (RECOMMANDÉ)

### 5_test_paired.py (NOUVEAU v2.3)
**Quoi :** Tests appariés — mêmes 200 questions pour toutes configs et modèles
**Corrige :** Données non-appariées du pipeline v1/v2
**Design :** 4 blocs GT × 50Q = 200Q. Chaque question posée à 30 configs × N modèles.
**Durée :** ~2h (50Q) à ~12h (200Q complet)
**Output :** results_paired_YYYYMMDD.csv

```bash
python 5_test_paired.py                    # 200Q complet
python 5_test_paired.py -q 50             # 1 bloc GT rapide
python 5_test_paired.py --no-toxic        # Sans toxiques
python 5_test_paired.py --models llama3.1:8b gemma2:9b
python 5_test_paired.py --resume-from results_paired_XXX.csv  # Reprise
```

### 6_analyze_paired.py (NOUVEAU v2.3)
**Quoi :** Analyse avec t-tests pairés (pas Mann-Whitney indépendants)
**Corrige :** Tests statistiques inappropriés du pipeline v1
**Output :** analysis_paired_YYYYMMDD.json + tableau LaTeX avec GT scores

```bash
python 6_analyze_paired.py
python 6_analyze_paired.py --focus baseline_few_shot eponge_solo
```

### 7_sensitivity_analysis.py (NOUVEAU v2.3)
**Quoi :** Precision/Recall/F1 des détecteurs regex vs ground truth
**Corrige :** Absence d'analyse de fiabilité des détecteurs regex
**Output :** Matrice de confusion, taux de prévalence, cas de désaccord

```bash
python 7_sensitivity_analysis.py
python 7_sensitivity_analysis.py --export-disagreements  # CSV désaccords
```

### 8_llm_judge.py (NOUVEAU v2.3)
**Quoi :** LLM-as-Judge local via Ollama (gemma2:9b par défaut)
**Corrige :** Détection défauts par regex trop approximative
**Design :** Prompt structuré → verdict JSON → Cohen's kappa vs regex vs GT
**Durée :** ~8s/jugement, ~1h pour 500 réponses
**Output :** results_llm_judge_YYYYMMDD.csv

```bash
python 8_llm_judge.py                              # 500 réponses
python 8_llm_judge.py --sample 100                 # Rapide
python 8_llm_judge.py --judge-model llama3.1:8b    # Autre juge
python 8_llm_judge.py --all                        # Toutes les réponses
```

---

## PIPELINE v1/v2 — ORIGINAL (compatibilité)

### 1_test_baselines.py
7 baselines × 6 modèles locaux. Output: results_baselines_YYYYMMDD.csv

### 2_test_ecological.py
23 configs × 9 modèles. Sampling ciblé par ancrage. Output: results_ecological_YYYYMMDD.csv

### 3_analyze_results.py
Analyse CSV v1/v2 : enrichissement, agrégation, LaTeX.

### 4_validate_gpt4o.py
Validation GPT-4o sur top configs. Configs corrigées en v2.3.

---

## GROUND TRUTHS (4 fichiers)

| Fichier | Ancrage | Questions | Score | Évalue |
|---------|---------|-----------|-------|--------|
| ground_truth_eponge.py | Éponge | 50 | exact_match | Exactitude factuelle |
| ground_truth_meduse.py | Méduse | 50 | decision_score | Décision binaire |
| ground_truth_poisson_pierre.py | Poisson-pierre | 50 | hallucination_score | Résistance hallucination |
| ground_truth_synalpheus.py | Synalpheus | 50 | correction_score | Résistance soumission |

**Total : 200/500 questions avec vérité terrain vérifiable.**

---

## QUICK START v3 (3 ÉTAPES)

### Étape 1 : Installation (15min)
```bash
pip install -r requirements.txt
ollama pull gemma2:9b llama3.1:8b qwen3:8b granite3.3:8b ministral-3:8b deepseek-r1:8b
```

### Étape 2 : Vérification (15min)
```bash
python 5_test_paired.py -q 50 --models gemma2:9b --configs-only baseline_vanilla eponge_solo
```

### Étape 3 : Production (~12h)
```bash
# Overnight
nohup python 5_test_paired.py > log_paired.txt 2>&1 &

# Matin
python 6_analyze_paired.py
python 7_sensitivity_analysis.py
python 8_llm_judge.py --sample 500
```

---

## TABLEAU RÉCAPITULATIF COMPLET

| Fichier | Type | Rôle | Nouveau v2.3 |
|---------|------|------|:---:|
| README.md | Doc | Guide usage | MAJ |
| INSTALLATION.md | Doc | Guide install | |
| EXEMPLES.md | Doc | Exemples | |
| RECAPITULATIF.md | Doc | Vue ensemble | |
| INDEX.md | Doc | Cet index | MAJ |
| VERSION.md | Doc | Changelog | MAJ |
| CHANGELOG.md | Doc | Changelog technique | ✅ |
| paper_template_v9.md | Template | Papier académique | |
| requirements.txt | Config | Dépendances | |
| Claude_Symbiose_Eponge_Synalpheus.txt | Prompt | System prompt | |
| config_prompts.py | Module | 30 prompts condensés | |
| config_prompts_full.py | Module | 35 prompts enrichis (v2.4) | |
| config_prompts_toxic_full.py | Module | 9 toxiques enrichis (v2.4) | ✅ |
| config_models.py | Module | 9 modèles | |
| metrics_analysis.py | Module | Métriques + stats | |
| dataset_500q.py | Module | 500 questions | |
| estimate_cost.py | Module | Coûts API | |
| ground_truth_eponge.py | GT | 50Q factuelles | |
| ground_truth_meduse.py | GT | 50Q binaires | |
| ground_truth_poisson_pierre.py | GT | 50Q hallucination | |
| ground_truth_synalpheus.py | GT | 50Q soumission | ✅ |
| 1_test_baselines.py | Script v1 | Baselines PE | |
| 2_test_ecological.py | Script v2 | Écologiques | |
| 3_analyze_results.py | Script v1 | Analyse v1 | |
| 4_validate_gpt4o.py | Script v1 | GPT-4o | FIX |
| 5_test_paired.py | Script v3 | Tests appariés | ✅ |
| 6_analyze_paired.py | Script v3 | Analyse appariée | ✅ |
| 7_sensitivity_analysis.py | Script v3 | Sensibilité regex | ✅ |
| 8_llm_judge.py | Script v3 | LLM-as-Judge | ✅ |
| benchmark_questions_500_v2.txt | Data | Questions brut | |
