#!/usr/bin/env python3
"""
4_validate_gpt4o.py - Validation GPT-4o des meilleures configs
Tests économiques ciblés.

Usage:
    python 4_validate_gpt4o.py              # Top 3 écologiques (~$5)
    python 4_validate_gpt4o.py --minimal    # Juste ocean (~$2)
    python 4_validate_gpt4o.py --full       # + baseline concise (~$8)
"""

import time
import random
import csv
import os
import argparse
from datetime import datetime

from config_prompts import get_prompt
from config_models import call_openai, OPENAI_AVAILABLE
from metrics_analysis import detect_defects, check_exact_match, calculate_concision_score
from dataset_500q import QUESTIONS_500

parser = argparse.ArgumentParser(description='Validation GPT-4o')
parser.add_argument('--minimal', action='store_true', help='1 config (~$2)')
parser.add_argument('--full', action='store_true', help='4 configs (~$8)')
parser.add_argument('-q', '--questions', type=int, default=100)
parser.add_argument('--seed', type=int, default=42)
args = parser.parse_args()

print("=" * 80)
print("VALIDATION GPT-4o")
print("=" * 80)

if not OPENAI_AVAILABLE or not os.environ.get("OPENAI_API_KEY"):
    print("\nERREUR: OPENAI_API_KEY non configurée")
    exit(1)

random.seed(args.seed)
QUESTIONS_TEST = random.sample(QUESTIONS_500, min(args.questions, 500))

if args.minimal:
    CONFIGS = ["ecosysteme_filtrage_marine"]
    cost_est = 2
elif args.full:
    CONFIGS = ["baseline_concise", "baseline_argonaute", "ecosysteme_filtrage_marine", "ecosysteme_precision_marine"]
    cost_est = 8
else:
    CONFIGS = ["baseline_argonaute", "ecosysteme_filtrage_marine", "symbiose_eponge_synalpheus"]
    cost_est = 5

total_tests = len(QUESTIONS_TEST) * len(CONFIGS)

print(f"\nConfiguration:")
print(f"  Questions: {len(QUESTIONS_TEST)}")
print(f"  Configs: {len(CONFIGS)}")
print(f"  Total tests: {total_tests}")
print(f"  Coût estimé: ~${cost_est}")
print(f"\nConfigs: {', '.join(CONFIGS)}")

confirm = input(f"\nContinuer? (~${cost_est}) [y/n]: ")
if confirm.lower() != 'y':
    print("Annulé.")
    exit(0)

print(f"\nLancement...\n")

results = []
current_test = 0
start_time = time.time()

for config_name in CONFIGS:
    system_prompt = get_prompt(config_name)
    config_short = config_name.replace('baseline_', '').replace('ecosysteme_', 'eco:')
    
    print(f"\n  {config_short}")
    
    for i, question in enumerate(QUESTIONS_TEST, 1):
        current_test += 1
        progress = (current_test / total_tests) * 100
        
        if i % 10 == 0:
            elapsed = time.time() - start_time
            eta = (elapsed / current_test) * (total_tests - current_test)
            print(f"  [{progress:5.1f}%] Q {i}/{len(QUESTIONS_TEST)} | ETA: {eta/60:.1f}min")
        
        response, tokens, elapsed_ms = call_openai("gpt-4o", system_prompt, question)
        
        if response is None:
            continue
        
        defects = detect_defects(response, question)
        em = check_exact_match(question, response)
        concision = calculate_concision_score(response, question)
        
        results.append({
            "Model": "GPT-4o",
            "Model_ID": "gpt-4o",
            "Model_Type": "api",
            "Provider": "openai",
            "Config": config_name,
            "Question": question,
            "Response": response,
            "Tokens": tokens,
            "Elapsed_ms": elapsed_ms,
            "Defects": ",".join(defects),
            "Total_Defects": len(defects),
            "Exact_Match": em,
            "Concision_Score": round(concision, 4),
        })

total_elapsed = time.time() - start_time
print(f"\nTemps total: {total_elapsed/60:.1f} min")

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
csv_file = f"results_gpt4o_validation_{timestamp}.csv"

with open(csv_file, 'w', newline='', encoding='utf-8') as f:
    if results:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)

print(f"Sauvegardé: {csv_file} ({len(results)} résultats)")

# Aperçu
from metrics_analysis import aggregate_by_config, rank_by_tokens

stats = aggregate_by_config(results)
ranked = rank_by_tokens(stats)

print(f"\nRanking GPT-4o:\n")
for i, (config, stat) in enumerate(ranked, 1):
    name = config.replace('baseline_', '').replace('ecosysteme_', 'eco:')
    em = f"{stat['exact_match_mean']:.2f}" if stat.get('exact_match_mean') is not None else " --- "
    co = f"{stat['concision_mean']:.2f}" if stat.get('concision_mean') is not None else " --- "
    print(f"  {i}. {name:25s} | {stat['tokens_mean']:6.1f} tok | {stat['defects_mean']:.2f} def | EM={em} | Con={co}")

print(f"\nProchaine étape: python 3_analyze_results.py")
