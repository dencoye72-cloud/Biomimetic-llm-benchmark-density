# CHANGELOG

## v2.3 (13 février 2026)

### Nouveaux fichiers
- `ground_truth_synalpheus.py` — GT manquant créé (50 questions, 12 types d'erreur, marqueurs FR/EN)
- `5_test_paired.py` — Tests appariés : 200Q identiques posées à toutes configs × modèles
- `6_analyze_paired.py` — Analyse appariée : t-tests pairés, 4 GT, score composite QUALITY

### Corrections
- `4_validate_gpt4o.py` — Configs inexistantes corrigées (`ecosysteme_ocean`/`savane` → configs réelles)

### Limites v2.1 corrigées
- Données non-appariées → appariement strict (mêmes questions partout)
- Pas de validation sémantique → 4 ground truths (exact_match, décision, hallucination, correction)
- GT Synalpheus absent → créé
- T-tests indépendants → t-tests pairés

## v2.2 (11 février 2026)

- `2_test_ecological.py` — Sampling ciblé par ancrage (CONFIG_ANCHOR_MAP)
- `config_prompts.py` — Configs écologiques reconstruites Core Marine 11 uniquement
- `dataset_500q.py` — 500Q (ajout 50Q Synalpheus)

## v2.1 (7 février 2026)

- `config_models.py` — Remplacement Phi-4/Ministral 14B → Qwen3 8B/Granite3.3 8B (tous <10B)
- Token count Ollama via eval_count (vrais tokens)
- Clients API singletons

## v1.0 (5 février 2026)

- Infrastructure initiale 9 fichiers
- 22 336 tests exécutés (9 modèles × 25 configs × 100Q)
- Résultats publiés HAL/Zenodo

### Ajout post-release
- `7_sensitivity_analysis.py` — Analyse sensibilité regex : precision/recall/F1 des détecteurs vs GT, export désaccords
