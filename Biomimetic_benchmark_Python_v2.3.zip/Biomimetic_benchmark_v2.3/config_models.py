#!/usr/bin/env python3
"""
config_models.py - Configuration modèles API Cloud + Ollama Local

CORRECTIONS vs v2.1:
- Remplacement Phi-4 14B → Qwen3 8B (alibaba, 8B, 128K context)
- Remplacement Ministral 3 14B → Granite3.3 8B (ibm, 8B, 128K context)
- Tous modèles maintenant <10B pour hardware plus accessible
- Token count Ollama via eval_count (vrais tokens) au lieu de len(split())
- Instanciation clients une seule fois (pas à chaque appel)
"""

import os
import time
from dotenv import load_dotenv

load_dotenv()

# ============================================================================
# IMPORTS CLIENTS
# ============================================================================

try:
    from anthropic import Anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

try:
    from mistralai import Mistral
    MISTRAL_AVAILABLE = True
except ImportError:
    MISTRAL_AVAILABLE = False

try:
    import ollama
    OLLAMA_AVAILABLE = True
except ImportError:
    OLLAMA_AVAILABLE = False

# ============================================================================
# CLIENTS SINGLETONS (instanciés une fois)
# ============================================================================

_clients = {}

def _get_client(provider):
    """Instancie le client une seule fois par provider."""
    if provider in _clients:
        return _clients[provider]
    
    if provider == "anthropic" and ANTHROPIC_AVAILABLE:
        key = os.environ.get("ANTHROPIC_API_KEY")
        if key:
            _clients[provider] = Anthropic(api_key=key)
            return _clients[provider]
    elif provider == "openai" and OPENAI_AVAILABLE:
        key = os.environ.get("OPENAI_API_KEY")
        if key:
            _clients[provider] = OpenAI(api_key=key)
            return _clients[provider]
    elif provider == "mistral" and MISTRAL_AVAILABLE:
        key = os.environ.get("MISTRAL_API_KEY")
        if key:
            _clients[provider] = Mistral(api_key=key)
            return _clients[provider]
    return None

# ============================================================================
# CONFIGURATION MODÈLES
# ============================================================================

MODELS_API = []

if ANTHROPIC_AVAILABLE and os.environ.get("ANTHROPIC_API_KEY"):
    MODELS_API.append({
        "name": "Claude Sonnet 4",
        "id": "claude-sonnet-4-20250514",
        "provider": "anthropic",
        "type": "api"
    })

if OPENAI_AVAILABLE and os.environ.get("OPENAI_API_KEY"):
    MODELS_API.append({
        "name": "GPT-4o",
        "id": "gpt-4o",
        "provider": "openai",
        "type": "api"
    })

if MISTRAL_AVAILABLE and os.environ.get("MISTRAL_API_KEY"):
    MODELS_API.append({
        "name": "Mistral Large",
        "id": "mistral-large-latest",
        "provider": "mistral",
        "type": "api"
    })

MODELS_LOCAL_STANDARD = [
    {"name": "Llama 3.1 8B",    "id": "llama3.1:8b",    "provider": "meta",     "type": "local_standard", "size": "8B"},
    {"name": "Gemma 2 9B",      "id": "gemma2:9b",      "provider": "google",   "type": "local_standard", "size": "9B"},
    {"name": "Qwen3 8B",        "id": "qwen3:8b",       "provider": "alibaba",  "type": "local_standard", "size": "8B"},
    {"name": "Granite3.3 8B",   "id": "granite3.3:8b",  "provider": "ibm",      "type": "local_standard", "size": "8B"},
    {"name": "Ministral 3 8B",  "id": "ministral-3:8b", "provider": "mistral",  "type": "local_standard", "size": "8B"},
]

MODELS_LOCAL_REASONING = [
    {"name": "DeepSeek-R1 8B", "id": "deepseek-r1:8b", "provider": "deepseek", "type": "local_reasoning", "size": "8B"},
]

MODELS_LOCAL = MODELS_LOCAL_STANDARD + MODELS_LOCAL_REASONING

# ============================================================================
# FONCTIONS D'APPEL
# ============================================================================

def call_anthropic(model_id, system_prompt, question):
    """Appel API Anthropic Claude. Retourne (content, token_count, elapsed_ms)."""
    client = _get_client("anthropic")
    if not client:
        return None, 0, 0
    try:
        t0 = time.time()
        response = client.messages.create(
            model=model_id,
            max_tokens=1000,
            system=system_prompt,
            messages=[{"role": "user", "content": question}]
        )
        elapsed = int((time.time() - t0) * 1000)
        return response.content[0].text, response.usage.output_tokens, elapsed
    except Exception as e:
        print(f"  ⚠️  Erreur Anthropic: {e}")
        return None, 0, 0

def call_openai(model_id, system_prompt, question):
    """Appel API OpenAI. Retourne (content, token_count, elapsed_ms)."""
    client = _get_client("openai")
    if not client:
        return None, 0, 0
    try:
        t0 = time.time()
        response = client.chat.completions.create(
            model=model_id,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": question}
            ],
            max_tokens=1000
        )
        elapsed = int((time.time() - t0) * 1000)
        return response.choices[0].message.content, response.usage.completion_tokens, elapsed
    except Exception as e:
        print(f"  ⚠️  Erreur OpenAI: {e}")
        return None, 0, 0

def call_mistral(model_id, system_prompt, question):
    """Appel API Mistral. Retourne (content, token_count, elapsed_ms)."""
    client = _get_client("mistral")
    if not client:
        return None, 0, 0
    try:
        t0 = time.time()
        response = client.chat.complete(
            model=model_id,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": question}
            ],
            max_tokens=1000
        )
        elapsed = int((time.time() - t0) * 1000)
        content = response.choices[0].message.content
        tokens = getattr(response.usage, 'completion_tokens', None)
        if tokens is None:
            tokens = len(content.split())  # fallback word count si API ne donne pas
        return content, tokens, elapsed
    except Exception as e:
        print(f"  ⚠️  Erreur Mistral: {e}")
        return None, 0, 0

def call_ollama(model_id, system_prompt, question):
    """
    Appel Ollama local. Retourne (content, token_count, elapsed_ms).
    
    CORRECTION vs v1: utilise eval_count (vrais tokens) au lieu de len(split()).
    len(split()) compte les mots, pas les tokens. Un mot français moyen
    fait 1.3-1.5 tokens. Comparer word_count Ollama vs token_count API
    introduit un biais systématique de ~30%.
    """
    if not OLLAMA_AVAILABLE:
        return None, 0, 0
    try:
        t0 = time.time()
        response = ollama.chat(
            model=model_id,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": question}
            ],
            options={"num_ctx": 8192}
        )
        elapsed = int((time.time() - t0) * 1000)
        content = response['message']['content']
        
        # eval_count = vrais tokens générés par le modèle
        # fallback sur word count si eval_count absent (vieilles versions Ollama)
        tokens = response.get('eval_count', None)
        if tokens is None:
            tokens = len(content.split())
        
        return content, tokens, elapsed
    except Exception as e:
        print(f"  ⚠️  Erreur Ollama {model_id}: {e}")
        return None, 0, 0

def call_model(model_config, system_prompt, question):
    """
    Appel universel. Retourne (content, token_count, elapsed_ms).
    
    CHANGEMENT vs v1: retourne maintenant 3 valeurs (ajout elapsed_ms).
    """
    model_type = model_config.get('type', '')
    model_id = model_config['id']
    provider = model_config['provider']
    
    if model_type.startswith('local_'):
        return call_ollama(model_id, system_prompt, question)
    elif provider == "anthropic":
        return call_anthropic(model_id, system_prompt, question)
    elif provider == "openai":
        return call_openai(model_id, system_prompt, question)
    elif provider == "mistral":
        return call_mistral(model_id, system_prompt, question)
    else:
        return call_ollama(model_id, system_prompt, question)

# ============================================================================
# HELPERS
# ============================================================================

def get_available_api_models():
    return MODELS_API

def get_available_local_models():
    return MODELS_LOCAL if OLLAMA_AVAILABLE else []

def get_all_models():
    return MODELS_API + (MODELS_LOCAL if OLLAMA_AVAILABLE else [])

def print_available_models():
    print("=" * 80)
    print("MODÈLES DISPONIBLES")
    print("=" * 80)
    
    if MODELS_API:
        print(f"\n  API CLOUD ({len(MODELS_API)}):")
        for m in MODELS_API:
            print(f"    - {m['name']} ({m['provider']})")
    else:
        print("\n  API CLOUD: Aucun (vérifiez .env)")
    
    if OLLAMA_AVAILABLE and MODELS_LOCAL:
        print(f"\n  OLLAMA LOCAL ({len(MODELS_LOCAL)}):")
        for m in MODELS_LOCAL:
            print(f"    - {m['name']} ({m['size']}, {m['type']})")
    else:
        print("\n  OLLAMA LOCAL: Non disponible")
    print()

if __name__ == "__main__":
    print_available_models()
