#!/usr/bin/env python3
"""
ground_truth_eponge.py - Ground Truth : 50 questions ÉPONGE

Réponses canoniques pour questions factuelles à réponse courte.
Chaque entrée contient:
  - answer: réponse canonique (forme la plus courte correcte)
  - variants: formes alternatives acceptables (exact match insensible à la casse)
  - max_tokens: longueur réponse idéale (pour concision score)
  - source: référence vérifiable

⚠️  VÉRIFIER CHAQUE ENTRÉE AVANT UTILISATION.
    Certaines réponses ont des ambiguïtés légitimes signalées par # ⚠️
"""

GROUND_TRUTH_EPONGE = {

    "Quelle est la capitale de la France ?": {
        "answer": "Paris",
        "variants": ["paris", "c'est paris"],
        "max_tokens": 3,
        "source": "fait établi",
    },

    "En quelle année l'homme a-t-il marché sur la Lune ?": {
        "answer": "1969",
        "variants": ["1969", "en 1969"],
        "max_tokens": 3,
        "source": "Apollo 11, 20 juillet 1969",
    },

    "Quel est le symbole chimique de l'or ?": {
        "answer": "Au",
        "variants": ["au"],
        "max_tokens": 3,
        "source": "tableau périodique",
    },

    "Combien de continents y a-t-il ?": {
        "answer": "7",
        "variants": ["7", "sept"],
        "max_tokens": 3,
        "source": "modèle 7 continents (standard FR/US)",
        # ⚠️ Certains modèles comptent 5 ou 6. Le standard scolaire FR = 7.
    },

    "Qui a peint la Joconde ?": {
        "answer": "Léonard de Vinci",
        "variants": ["léonard de vinci", "leonard de vinci", "leonardo da vinci", "de vinci", "vinci"],
        "max_tokens": 5,
        "source": "fait établi",
    },

    "Quelle est la vitesse de la lumière en km/s ?": {
        "answer": "299 792",
        "variants": ["299792", "299 792", "300 000", "300000", "~300 000", "environ 300 000"],
        "max_tokens": 5,
        "source": "NIST, c = 299 792,458 km/s",
        # ⚠️ 300 000 accepté comme approximation courante
    },

    "Quel est le plus grand océan du monde ?": {
        "answer": "Pacifique",
        "variants": ["pacifique", "l'océan pacifique", "océan pacifique", "le pacifique"],
        "max_tokens": 5,
        "source": "fait établi",
    },

    "Combien de planètes dans le système solaire ?": {
        "answer": "8",
        "variants": ["8", "huit"],
        "max_tokens": 3,
        "source": "UAI 2006 (Pluton reclassifiée)",
    },

    "Quelle est la formule de l'eau ?": {
        "answer": "H2O",
        "variants": ["h2o", "H₂O"],
        "max_tokens": 3,
        "source": "chimie élémentaire",
    },

    "Qui a écrit Les Misérables ?": {
        "answer": "Victor Hugo",
        "variants": ["victor hugo", "hugo"],
        "max_tokens": 5,
        "source": "fait établi, 1862",
    },

    "Quel est le plus long fleuve du monde ?": {
        "answer": "Nil",
        "variants": ["nil", "le nil"],
        "max_tokens": 5,
        "source": "fait établi (~6 695 km)",
        # ⚠️ Amazone parfois cité comme plus long selon méthode de mesure.
        #    Nil = réponse conventionnelle. Accepter Amazone serait défendable.
    },

    "En quelle année a commencé la Première Guerre mondiale ?": {
        "answer": "1914",
        "variants": ["1914", "en 1914"],
        "max_tokens": 3,
        "source": "fait établi",
    },

    "Quel est le point d'ébullition de l'eau en degrés Celsius ?": {
        "answer": "100",
        "variants": ["100", "100°c", "100 °c", "100 degrés"],
        "max_tokens": 5,
        "source": "à pression atmosphérique standard",
    },

    "Combien d'os dans le corps humain adulte ?": {
        "answer": "206",
        "variants": ["206"],
        "max_tokens": 3,
        "source": "anatomie standard",
    },

    "Quelle est la monnaie du Japon ?": {
        "answer": "Yen",
        "variants": ["yen", "le yen", "yen japonais", "¥"],
        "max_tokens": 5,
        "source": "fait établi",
    },

    "Quel est l'élément chimique le plus léger ?": {
        "answer": "Hydrogène",
        "variants": ["hydrogène", "hydrogene", "l'hydrogène", "h"],
        "max_tokens": 5,
        "source": "Z=1, tableau périodique",
    },

    "Combien de côtés a un hexagone ?": {
        "answer": "6",
        "variants": ["6", "six"],
        "max_tokens": 3,
        "source": "géométrie",
    },

    "Quelle est la racine carrée de 144 ?": {
        "answer": "12",
        "variants": ["12", "douze"],
        "max_tokens": 3,
        "source": "12² = 144",
    },

    "Quel est le plus petit pays du monde ?": {
        "answer": "Vatican",
        "variants": ["vatican", "le vatican", "cité du vatican", "état de la cité du vatican"],
        "max_tokens": 5,
        "source": "0,44 km²",
    },

    "En quelle année est tombé le mur de Berlin ?": {
        "answer": "1989",
        "variants": ["1989", "en 1989"],
        "max_tokens": 3,
        "source": "9 novembre 1989",
    },

    "Quel est le pH de l'eau pure ?": {
        "answer": "7",
        "variants": ["7", "sept"],
        "max_tokens": 3,
        "source": "à 25°C",
    },

    "Combien de chromosomes chez l'humain ?": {
        "answer": "46",
        "variants": ["46", "23 paires", "quarante-six"],
        "max_tokens": 5,
        "source": "cytogénétique",
    },

    "Quelle est la distance Terre-Lune en km ?": {
        "answer": "384 400",
        "variants": ["384400", "384 400", "~384 400", "environ 384 400", "380 000", "385 000"],
        "max_tokens": 5,
        "source": "distance moyenne, NASA",
        # ⚠️ Distance varie (356k-406k). 384 400 = moyenne. Approximations acceptées.
    },

    "Qui a découvert la pénicilline ?": {
        "answer": "Alexander Fleming",
        "variants": ["alexander fleming", "fleming", "alexander flemming"],
        "max_tokens": 5,
        "source": "1928",
    },

    "Quel est le métal le plus conducteur ?": {
        "answer": "Argent",
        "variants": ["argent", "l'argent", "ag"],
        "max_tokens": 5,
        "source": "conductivité 6,30×10⁷ S/m",
        # ⚠️ Cuivre souvent cité. Argent = correct (meilleur conducteur électrique).
    },

    "Combien de dents a un adulte ?": {
        "answer": "32",
        "variants": ["32", "trente-deux"],
        "max_tokens": 3,
        "source": "dentition adulte complète (avec dents de sagesse)",
    },

    "Quelle est la capitale de l'Australie ?": {
        "answer": "Canberra",
        "variants": ["canberra"],
        "max_tokens": 3,
        "source": "fait établi (pas Sydney)",
    },

    "En quelle année Christophe Colomb a-t-il atteint l'Amérique ?": {
        "answer": "1492",
        "variants": ["1492", "en 1492"],
        "max_tokens": 3,
        "source": "12 octobre 1492",
    },

    "Quel gaz les plantes absorbent-elles ?": {
        "answer": "CO2",
        "variants": ["co2", "dioxyde de carbone", "gaz carbonique", "CO₂"],
        "max_tokens": 5,
        "source": "photosynthèse",
    },

    "Combien font 17 × 23 ?": {
        "answer": "391",
        "variants": ["391"],
        "max_tokens": 3,
        "source": "calcul",
    },

    "Quel est le plus grand désert du monde ?": {
        "answer": "Sahara",
        "variants": ["sahara", "le sahara", "désert du sahara"],
        "max_tokens": 5,
        "source": "plus grand désert chaud (9,2M km²)",
        # ⚠️ Antarctique = plus grand désert au sens strict (14M km², désert froid).
        #    Sahara = réponse conventionnelle. Antarctique défendable.
    },

    "Quelle est la langue la plus parlée au monde ?": {
        "answer": "Mandarin",
        "variants": ["mandarin", "chinois", "chinois mandarin", "le mandarin", "le chinois"],
        "max_tokens": 5,
        "source": "par locuteurs natifs (~920M). Ethnologue 2024.",
        # ⚠️ Anglais = plus parlé total (natifs + L2). Mandarin = plus de natifs.
        #    Question ambiguë. Les deux réponses sont défendables.
    },

    "Combien de vertèbres dans la colonne vertébrale humaine ?": {
        "answer": "33",
        "variants": ["33", "trente-trois", "33 ou 34"],
        "max_tokens": 3,
        "source": "anatomie (7C+12T+5L+5S+4Co)",
        # ⚠️ 33 standard. Certaines sources disent 33-34 (coccyx variable).
    },

    "Quel est le numéro atomique du carbone ?": {
        "answer": "6",
        "variants": ["6", "six"],
        "max_tokens": 3,
        "source": "tableau périodique",
    },

    "En quelle année a été fondée l'ONU ?": {
        "answer": "1945",
        "variants": ["1945", "en 1945"],
        "max_tokens": 3,
        "source": "24 octobre 1945",
    },

    "Quelle est la planète la plus proche du Soleil ?": {
        "answer": "Mercure",
        "variants": ["mercure"],
        "max_tokens": 3,
        "source": "fait établi",
    },

    "Combien de faces a un cube ?": {
        "answer": "6",
        "variants": ["6", "six"],
        "max_tokens": 3,
        "source": "géométrie",
    },

    "Quel est le symbole chimique du sodium ?": {
        "answer": "Na",
        "variants": ["na"],
        "max_tokens": 3,
        "source": "tableau périodique (natrium)",
    },

    "Quelle est la vitesse du son dans l'air ?": {
        "answer": "343 m/s",
        "variants": ["343", "343 m/s", "340 m/s", "340", "~340 m/s", "environ 340"],
        "max_tokens": 5,
        "source": "à 20°C, pression standard. 331 m/s à 0°C.",
        # ⚠️ Varie avec température. 340-343 = approximations courantes acceptées.
    },

    "Qui a formulé la théorie de la relativité ?": {
        "answer": "Albert Einstein",
        "variants": ["albert einstein", "einstein"],
        "max_tokens": 5,
        "source": "1905 (restreinte), 1915 (générale)",
    },

    "Quel est le plus haut sommet du monde ?": {
        "answer": "Everest",
        "variants": ["everest", "l'everest", "mont everest", "le mont everest"],
        "max_tokens": 5,
        "source": "8 849 m (mesure 2020)",
    },

    "Combien de litres de sang dans le corps humain ?": {
        "answer": "5",
        "variants": ["5", "cinq", "5 litres", "environ 5", "4 à 6", "5 à 6"],
        "max_tokens": 5,
        "source": "adulte moyen ~5L (varie 4-6L)",
        # ⚠️ Varie selon poids/sexe. 5 = valeur conventionnelle.
    },

    "Quelle est la capitale du Canada ?": {
        "answer": "Ottawa",
        "variants": ["ottawa"],
        "max_tokens": 3,
        "source": "fait établi (pas Toronto/Montréal)",
    },

    "En quelle année la Révolution française a-t-elle commencé ?": {
        "answer": "1789",
        "variants": ["1789", "en 1789"],
        "max_tokens": 3,
        "source": "14 juillet 1789 (prise de la Bastille)",
    },

    "Quel est le plus grand pays du monde en superficie ?": {
        "answer": "Russie",
        "variants": ["russie", "la russie", "fédération de russie"],
        "max_tokens": 5,
        "source": "17,1M km²",
    },

    "Combien de secondes dans une heure ?": {
        "answer": "3600",
        "variants": ["3600", "3 600"],
        "max_tokens": 3,
        "source": "60 × 60",
    },

    "Quel organe produit l'insuline ?": {
        "answer": "Pancréas",
        "variants": ["pancréas", "pancreas", "le pancréas"],
        "max_tokens": 5,
        "source": "cellules bêta des îlots de Langerhans",
    },

    "Quelle est la formule du sel de table ?": {
        "answer": "NaCl",
        "variants": ["nacl", "chlorure de sodium"],
        "max_tokens": 5,
        "source": "chimie",
    },

    "Combien de pattes a une araignée ?": {
        "answer": "8",
        "variants": ["8", "huit"],
        "max_tokens": 3,
        "source": "arachnides",
    },

    "Quel est le diamètre de la Terre en km ?": {
        "answer": "12 742",
        "variants": ["12742", "12 742", "12 756", "~12 750", "environ 12 700", "12700"],
        "max_tokens": 5,
        "source": "diamètre moyen 12 742 km (équatorial 12 756 km)",
        # ⚠️ Diamètre moyen vs équatorial. Les deux sont corrects.
    },
}


# =============================================================================
# UTILITAIRES
# =============================================================================

def get_ground_truth(question: str) -> dict:
    """Retourne le GT pour une question, ou None."""
    return GROUND_TRUTH_EPONGE.get(question)


def check_exact_match(question: str, response: str) -> float:
    """
    Exact match insensible à la casse, avec word boundaries.
    Cherche si une variante apparaît dans la réponse comme mot entier.

    Utilise des word boundaries pour éviter les faux positifs
    (ex: "6" dans "16", "au" dans "aussi").

    Returns: 1.0 si match, 0.0 sinon, None si pas de GT.
    """
    import re

    gt = get_ground_truth(question)
    if not gt:
        return None  # Pas de GT pour cette question

    response_lower = response.lower().strip()
    all_variants = [gt["answer"].lower()] + [v.lower() for v in gt["variants"]]

    for variant in all_variants:
        # Word boundary : le variant doit être un mot entier
        # \b ne marche pas toujours avec accents/chiffres, on utilise un pattern custom
        pattern = r'(?<![a-zA-Z0-9àâéèêëïîôùûüçÀÂÉÈÊËÏÎÔÙÛÜÇ])' + \
                  re.escape(variant) + \
                  r'(?![a-zA-Z0-9àâéèêëïîôùûüçÀÂÉÈÊËÏÎÔÙÛÜÇ])'
        if re.search(pattern, response_lower):
            return 1.0
    return 0.0


def get_max_tokens(question: str) -> int:
    """Retourne max_tokens attendu pour concision score."""
    gt = get_ground_truth(question)
    if not gt:
        return None
    return gt["max_tokens"]


# =============================================================================
# AUTO-TEST
# =============================================================================

if __name__ == "__main__":
    print(f"Ground truth éponge: {len(GROUND_TRUTH_EPONGE)} entrées")

    # Compter les ⚠️
    ambiguous = sum(1 for q, gt in GROUND_TRUTH_EPONGE.items()
                    if "source" in gt and "⚠️" in str(gt))
    print(f"Questions avec ambiguïté signalée: {ambiguous}")

    # Tests exact match
    tests = [
        ("Quelle est la capitale de la France ?", "Paris", 1.0),
        ("Quelle est la capitale de la France ?", "La capitale est Paris.", 1.0),
        ("Quelle est la capitale de la France ?", "Berlin", 0.0),
        ("Combien font 17 × 23 ?", "391", 1.0),
        ("Combien font 17 × 23 ?", "Le résultat est 391.", 1.0),
        ("Combien font 17 × 23 ?", "392", 0.0),
        ("Quel est le symbole chimique de l'or ?", "Au", 1.0),
        ("Quel est le symbole chimique de l'or ?", "Le symbole est Au.", 1.0),
        ("Quel est le symbole chimique de l'or ?", "Or", 0.0),
    ]

    print("\nTests exact match:")
    all_pass = True
    for question, response, expected in tests:
        result = check_exact_match(question, response)
        status = "✓" if result == expected else "✗ FAIL"
        if result != expected:
            all_pass = False
        print(f"  {status} '{response}' → {result} (attendu {expected})")

    if all_pass:
        print("\n✅ Tous les tests passent")
    else:
        print("\n❌ Certains tests échouent")
