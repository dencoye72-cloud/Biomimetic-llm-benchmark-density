#!/usr/bin/env python3
"""
estimate_cost.py - Estime le coût API avant lancement

Usage: python estimate_cost.py
       python estimate_cost.py -q 50 -c 7
"""

import argparse

PRICING = {  # $/million tokens
    "Claude Sonnet 4": {"input": 3.00, "output": 15.00},
    "GPT-4o":          {"input": 2.50, "output": 10.00},
    "Mistral Large":   {"input": 2.00, "output": 6.00},
}

parser = argparse.ArgumentParser()
parser.add_argument('-q', '--questions', type=int, default=100)
parser.add_argument('-c', '--configs', type=int, default=23)
args = parser.parse_args()

AVG_INPUT, AVG_OUTPUT = 200, 150  # tokens moyens estimés

print(f"Estimation pour {args.questions}Q x {args.configs} configs:\n")

total = 0
for model, price in PRICING.items():
    tests = args.questions * args.configs
    cost = (tests * AVG_INPUT / 1e6 * price['input'] +
            tests * AVG_OUTPUT / 1e6 * price['output'])
    total += cost
    print(f"  {model:20s}: ${cost:.2f} ({tests} tests)")

print(f"\n  TOTAL: ${total:.2f}")
print(f"\n  Tests locaux (Ollama): $0")
