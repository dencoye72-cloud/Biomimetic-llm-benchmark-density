# VERSION

## v2.3 — 13 février 2026

### Nouveaux fichiers

- `ground_truth_synalpheus.py` — 50 questions à prémisses fausses, 12 types d'erreur, marqueurs FR/EN
- `5_test_paired.py` — Tests appariés : mêmes 200Q pour toutes configs × modèles (corrige données non-appariées v1)
- `6_analyze_paired.py` — Analyse appariée : t-tests pairés, 4 GT, score composite QUALITY, LaTeX
- `7_sensitivity_analysis.py` — Analyse sensibilité : P/R/F1 détecteurs regex vs ground truth, export désaccords
- `8_llm_judge.py` — LLM-as-Judge local Ollama : évaluation sémantique, Cohen's kappa, comparaison triple
- `INDEX.md` — Index complet mis à jour
- `CHANGELOG.md` — Changelog technique détaillé

### Corrections

- `4_validate_gpt4o.py` — Configs inexistantes corrigées (`ecosysteme_ocean`/`savane` → configs réelles)

### Limites v2.1 corrigées

| Limite | Correction |
|---|---|
| Données non-appariées | `5_test_paired.py` : mêmes 200Q partout |
| Pas de validation sémantique | 4 GT exploités (exact_match, décision, hallucination, correction) |
| GT Synalpheus manquant | `ground_truth_synalpheus.py` créé (50 entrées) |
| T-tests indépendants | `6_analyze_paired.py` : ttest_rel (pairé) |
| Détection regex non quantifiée | `7_sensitivity_analysis.py` : P/R/F1 vs GT |
| Pas de LLM-as-Judge | `8_llm_judge.py` : juge local Ollama, kappa, comparaison triple |
| Configs fantômes 4_validate | `4_validate_gpt4o.py` corrigé |

### Métriques v2 (inchangé depuis v2.2)

**Ground truth :**
- `exact_match` — correspondance avec ground truth éponge (word boundaries)
- `decision_score` — réponse binaire correcte (méduse)
- `hallucination_score` — admet ignorance sur entité inventée (poisson-pierre)
- `correction_score` — corrige prémisse fausse (synalpheus)
- `concision_score` — ratio tokens attendus/réels
- `semantic_similarity` — sentence-transformers si installé, BoW cosine fallback

**Statistiques :**
- `t_test_paired` — scipy.stats.ttest_rel
- `cohens_d` — effect size
- `bootstrap_ci` — intervalles de confiance 10 000 itérations

### Ce qui n'a PAS changé

- `config_prompts.py` — 30 configs, Core Marine 11
- `config_models.py` — 9 modèles (6 locaux <10B + 3 API)
- `dataset_500q.py` — 500 questions, 10 ancrages × 50
- `metrics_analysis.py` — Métriques et détection défauts
- `ground_truth_eponge.py`, `ground_truth_meduse.py`, `ground_truth_poisson_pierre.py`
- `1_test_baselines.py`, `2_test_ecological.py`, `3_analyze_results.py`
- Documentation : INSTALLATION.md, EXEMPLES.md, RECAPITULATIF.md, paper_template_v9.md

---

## v2.2 — 10 février 2026

### Métriques v2

**Ajoutées :**
- `exact_match` — word boundaries
- `concision_score` — ratio tokens attendus/réels
- `semantic_similarity` — sentence-transformers / BoW fallback
- `t_test_paired`, `cohens_d`, `bootstrap_ci` — stats scipy

**Retirées :**
- `calculate_rouge_l`, `calculate_bleu`, `calculate_perplexity_proxy` — redondants

**Scripts mis à jour :**
- `1_test_baselines.py`, `2_test_ecological.py`, `3_analyze_results.py`, `4_validate_gpt4o.py`

### Ground truth
- `ground_truth_eponge.py` : 50 entrées factuelles

### Config
- `config_models.py` : tous modèles <10B (Phi-4/Ministral 14B → Qwen3 8B/Granite3.3 8B)
- Token count Ollama via eval_count

---

## v2.1 — 7 février 2026

- Sampling ciblé par ancrage (`2_test_ecological.py`)
- Dataset 500Q avec 50Q Synalpheus
- Config prompts reconstruites Core Marine 11

---

## v1.0 — 5 février 2026

- Infrastructure initiale
- 22 336 tests exécutés
- Résultats publiés HAL/Zenodo
