#!/usr/bin/env python3
"""
7_sensitivity_analysis.py - Analyse de sensibilité des détecteurs regex

OBJECTIF:
Quantifier la fiabilité des détections regex de metrics_analysis.py
en les comparant aux ground truths comme référence.

MÉTHODE:
- Les 4 GT fournissent une vérité terrain pour 200 questions
- Les détecteurs regex (detect_defects, detect_blind_submission, 
  detect_hallucination_marker) produisent des prédictions
- On calcule precision, recall, F1 pour chaque détecteur
- On identifie les cas de désaccord (faux positifs / faux négatifs)
- On exporte les cas de désaccord pour inspection humaine

DÉTECTEURS ANALYSÉS:
1. blind_submission (regex) vs GT_Correction (synalpheus) 
2. hallucination_marker (regex) vs GT_Hallucination (poisson-pierre)
3. verbiage (seuil chars) vs GT_Exact_Match (éponge) — proxy : 
   réponse verbeuse sur question simple ≈ concision faible

USAGE:
    python 7_sensitivity_analysis.py
    python 7_sensitivity_analysis.py --dir ./resultats
    python 7_sensitivity_analysis.py --export-disagreements
"""

import csv
import glob
import os
import argparse
import statistics
from datetime import datetime
from collections import defaultdict

csv.field_size_limit(10_000_000)

# ============================================================================
# ENREGISTREMENT AUTOMATIQUE DE LA SORTIE CONSOLE
# ============================================================================

class Tee:
    """Redirige stdout vers console ET fichier simultanément."""
    def __init__(self, filepath):
        self.terminal = sys.stdout
        self.file = open(filepath, 'w', encoding='utf-8')
    def write(self, message):
        self.terminal.write(message)
        self.file.write(message)
    def flush(self):
        self.terminal.flush()
        self.file.flush()
    def close(self):
        self.file.close()

import sys
_date = datetime.now().strftime("%Y%m%d")
_output_file = f"sensitivity_analysis_v2.3_{_date}.txt"
sys.stdout = Tee(_output_file)

parser = argparse.ArgumentParser(description='Analyse sensibilité détecteurs regex')
parser.add_argument('--dir', type=str, default='.', help='Dossier CSV résultats appariés')
parser.add_argument('--export-disagreements', action='store_true',
                    help='Exporter les cas de désaccord regex vs GT pour inspection')
args = parser.parse_args()

print("=" * 80)
print("ANALYSE DE SENSIBILITÉ — DÉTECTEURS REGEX vs GROUND TRUTH")
print("=" * 80)

# ============================================================================
# CHARGEMENT
# ============================================================================

search_dir = args.dir
paired_files = sorted(glob.glob(os.path.join(search_dir, "results_paired_*.csv")))

if not paired_files:
    print(f"\nERREUR: Aucun results_paired_*.csv dans {search_dir}/")
    print("Exécutez d'abord: python 5_test_paired.py")
    exit(1)

def load_csv(filepath):
    results = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            for float_col in ['GT_Exact_Match', 'GT_Decision', 'GT_Hallucination', 'GT_Correction']:
                if float_col in row and row[float_col] not in (None, '', 'None'):
                    try:
                        row[float_col] = float(row[float_col])
                    except (ValueError, TypeError):
                        row[float_col] = None
                else:
                    row[float_col] = None
            results.append(row)
    return results

all_results = []
for f in paired_files:
    data = load_csv(f)
    all_results.extend(data)
    print(f"  Chargé: {os.path.basename(f)} ({len(data)} résultats)")

print(f"\nTotal: {len(all_results)} résultats")

# ============================================================================
# RECALCUL DES DÉTECTIONS REGEX DEPUIS LES RÉPONSES BRUTES
# ============================================================================

from metrics_analysis import (
    detect_defects, detect_blind_submission, detect_hallucination_marker
)

print(f"\nRecalcul détections regex sur réponses brutes...")

for r in all_results:
    response = r.get('Response', '')
    question = r.get('Question', '')
    
    # Recalcul complet
    defects = detect_defects(response, question)
    r['_regex_verbiage'] = 1 if 'verbiage' in defects else 0
    r['_regex_equivocation'] = 1 if 'equivocation' in defects else 0
    r['_regex_anthropomorphism'] = 1 if 'anthropomorphism' in defects else 0
    r['_regex_politeness'] = 1 if 'politeness_excess' in defects else 0
    r['_regex_repetition'] = 1 if 'repetition' in defects else 0
    r['_regex_jargon'] = 1 if 'jargon_excess' in defects else 0
    r['_regex_blind_submission'] = 1 if 'blind_submission' in defects else 0
    r['_regex_any_defect'] = 1 if defects else 0
    r['_regex_defect_count'] = len(defects)
    
    # Détecteurs individuels (pour comparaison directe avec GT)
    r['_regex_hallucination'] = 1 if detect_hallucination_marker(response, question) else 0
    r['_regex_submission'] = 1 if detect_blind_submission(response, question) else 0

print(f"  Détections recalculées sur {len(all_results)} réponses")


# ============================================================================
# FONCTIONS MÉTRIQUES DE CLASSIFICATION
# ============================================================================

def classification_metrics(y_true, y_pred):
    """
    Calcule precision, recall, F1, accuracy pour classification binaire.
    
    y_true: liste de 0/1 (ground truth)
    y_pred: liste de 0/1 (prédiction regex)
    
    Convention:
    - 1 = défaut présent (positif)
    - 0 = pas de défaut (négatif)
    
    Pour hallucination/submission GT:
    - GT=1.0 = modèle CORRECT (a détecté le piège) → pas de défaut → y_true=0
    - GT=0.0 = modèle ÉCHOUE (hallucine/se soumet) → défaut → y_true=1
    """
    if len(y_true) != len(y_pred) or len(y_true) == 0:
        return {'n': 0, 'tp': 0, 'fp': 0, 'fn': 0, 'tn': 0,
                'precision': 0, 'recall': 0, 'f1': 0, 'accuracy': 0}
    
    tp = sum(1 for t, p in zip(y_true, y_pred) if t == 1 and p == 1)
    fp = sum(1 for t, p in zip(y_true, y_pred) if t == 0 and p == 1)
    fn = sum(1 for t, p in zip(y_true, y_pred) if t == 1 and p == 0)
    tn = sum(1 for t, p in zip(y_true, y_pred) if t == 0 and p == 0)
    
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    accuracy = (tp + tn) / len(y_true)
    
    return {
        'n': len(y_true),
        'tp': tp, 'fp': fp, 'fn': fn, 'tn': tn,
        'precision': precision,
        'recall': recall,
        'f1': f1,
        'accuracy': accuracy,
    }


def collect_disagreements(results, gt_col, pred_col, gt_invert=False):
    """
    Collecte les cas de désaccord entre GT et regex pour inspection.
    
    gt_invert: si True, GT=1.0 → pas de défaut (hallucination/correction GT 
    inversés : 1.0 = le modèle a bien réagi = PAS de défaut)
    """
    disagreements = []
    for r in results:
        gt_val = r.get(gt_col)
        pred_val = r.get(pred_col)
        if gt_val is None:
            continue
        
        if gt_invert:
            y_true = 0 if gt_val == 1.0 else 1  # GT=1→correct→pas défaut, GT=0→échoue→défaut
        else:
            y_true = int(gt_val)
        y_pred = int(pred_val)
        
        if y_true != y_pred:
            dtype = "FP" if y_pred == 1 and y_true == 0 else "FN"
            disagreements.append({
                'type': dtype,
                'model': r.get('Model', ''),
                'config': r.get('Config', ''),
                'question': r.get('Question', '')[:80],
                'response_preview': r.get('Response', '')[:150],
                'gt_value': gt_val,
                'regex_value': pred_val,
            })
    return disagreements


# ============================================================================
# ANALYSE 1: blind_submission (regex) vs GT_Correction (synalpheus)
# ============================================================================

print(f"\n{'=' * 80}")
print("ANALYSE 1: SOUMISSION AVEUGLE — regex vs GT Synalpheus")
print(f"{'=' * 80}")
print("GT_Correction: 1.0 = modèle corrige → pas de défaut")
print("               0.0 = modèle se soumet → défaut (blind_submission)")
print("regex blind_submission: 1 = soumission détectée")

syn_results = [r for r in all_results if r.get('GT_Correction') is not None]
if syn_results:
    y_true_syn = [0 if r['GT_Correction'] == 1.0 else 1 for r in syn_results]
    y_pred_syn = [r['_regex_submission'] for r in syn_results]
    
    m = classification_metrics(y_true_syn, y_pred_syn)
    print(f"\n  n={m['n']}")
    print(f"  TP={m['tp']:5d}  (regex=soumission, GT=soumission) — vrais détections")
    print(f"  FP={m['fp']:5d}  (regex=soumission, GT=correction)  — fausses alertes")
    print(f"  FN={m['fn']:5d}  (regex=ok,         GT=soumission) — manqués")
    print(f"  TN={m['tn']:5d}  (regex=ok,         GT=correction)  — vrais négatifs")
    print(f"\n  Precision: {m['precision']:.3f}  (parmi ceux que regex signale, combien sont vrais ?)")
    print(f"  Recall:    {m['recall']:.3f}  (parmi les vrais défauts, combien regex détecte ?)")
    print(f"  F1:        {m['f1']:.3f}")
    print(f"  Accuracy:  {m['accuracy']:.3f}")
    
    disagree_syn = collect_disagreements(syn_results, 'GT_Correction', '_regex_submission', gt_invert=True)
else:
    print("\n  (pas de données GT_Correction)")
    disagree_syn = []

# ============================================================================
# ANALYSE 2: hallucination_marker (regex) vs GT_Hallucination (poisson-pierre)
# ============================================================================

print(f"\n{'=' * 80}")
print("ANALYSE 2: HALLUCINATION — regex vs GT Poisson-Pierre")
print(f"{'=' * 80}")
print("GT_Hallucination: 1.0 = modèle admet ignorance → pas de défaut")
print("                  0.0 = modèle hallucine → défaut")
print("regex hallucination: 1 = hallucination détectée")

pp_results = [r for r in all_results if r.get('GT_Hallucination') is not None]
if pp_results:
    y_true_pp = [0 if r['GT_Hallucination'] == 1.0 else 1 for r in pp_results]
    y_pred_pp = [r['_regex_hallucination'] for r in pp_results]
    
    m = classification_metrics(y_true_pp, y_pred_pp)
    print(f"\n  n={m['n']}")
    print(f"  TP={m['tp']:5d}  (regex=hallucine,  GT=hallucine)  — vrais détections")
    print(f"  FP={m['fp']:5d}  (regex=hallucine,  GT=honnête)    — fausses alertes")
    print(f"  FN={m['fn']:5d}  (regex=ok,          GT=hallucine)  — manqués")
    print(f"  TN={m['tn']:5d}  (regex=ok,          GT=honnête)    — vrais négatifs")
    print(f"\n  Precision: {m['precision']:.3f}")
    print(f"  Recall:    {m['recall']:.3f}")
    print(f"  F1:        {m['f1']:.3f}")
    print(f"  Accuracy:  {m['accuracy']:.3f}")
    
    disagree_pp = collect_disagreements(pp_results, 'GT_Hallucination', '_regex_hallucination', gt_invert=True)
else:
    print("\n  (pas de données GT_Hallucination)")
    disagree_pp = []

# ============================================================================
# ANALYSE 3: verbiage (seuil chars) vs concision GT éponge
# ============================================================================

print(f"\n{'=' * 80}")
print("ANALYSE 3: VERBIAGE — seuil caractères vs GT Éponge")
print(f"{'=' * 80}")
print("GT_Exact_Match: 1.0 = réponse correcte (mais peut être verbeuse)")
print("Proxy: question éponge (simple) + verbiage détecté → probablement trop long")
print("NOTE: pas comparaison directe, juste corrélation verbiage ↔ concision")

ep_results = [r for r in all_results if r.get('GT_Exact_Match') is not None]
if ep_results:
    # Statistiques croisées : verbiage × exact_match
    verb_correct = sum(1 for r in ep_results if r['_regex_verbiage'] == 1 and r['GT_Exact_Match'] == 1.0)
    verb_wrong = sum(1 for r in ep_results if r['_regex_verbiage'] == 1 and r['GT_Exact_Match'] == 0.0)
    noverb_correct = sum(1 for r in ep_results if r['_regex_verbiage'] == 0 and r['GT_Exact_Match'] == 1.0)
    noverb_wrong = sum(1 for r in ep_results if r['_regex_verbiage'] == 0 and r['GT_Exact_Match'] == 0.0)
    
    total_verb = verb_correct + verb_wrong
    total_noverb = noverb_correct + noverb_wrong
    
    print(f"\n  n={len(ep_results)}")
    print(f"\n  Verbiage détecté (n={total_verb}):")
    print(f"    Correct:  {verb_correct:5d} ({verb_correct/max(1,total_verb)*100:.1f}%)")
    print(f"    Incorrect:{verb_wrong:5d} ({verb_wrong/max(1,total_verb)*100:.1f}%)")
    print(f"\n  Pas de verbiage (n={total_noverb}):")
    print(f"    Correct:  {noverb_correct:5d} ({noverb_correct/max(1,total_noverb)*100:.1f}%)")
    print(f"    Incorrect:{noverb_wrong:5d} ({noverb_wrong/max(1,total_noverb)*100:.1f}%)")
    
    # Taux exact_match par verbiage
    em_with_verb = verb_correct / max(1, total_verb)
    em_without_verb = noverb_correct / max(1, total_noverb)
    print(f"\n  Exact match AVEC verbiage:  {em_with_verb:.3f}")
    print(f"  Exact match SANS verbiage:  {em_without_verb:.3f}")
    print(f"  Delta: {em_without_verb - em_with_verb:+.3f}")
    
    if em_with_verb > em_without_verb:
        print(f"  ⚠️  Verbiage corrélé positivement avec exactitude — seuil peut-être trop bas")
    elif abs(em_with_verb - em_without_verb) < 0.05:
        print(f"  ≈  Pas de corrélation significative verbiage ↔ exactitude")
    else:
        print(f"  ✓  Concision corrélée positivement avec exactitude")

# ============================================================================
# ANALYSE 4: equivocation (regex) vs GT_Decision (méduse)
# ============================================================================

print(f"\n{'=' * 80}")
print("ANALYSE 4: ÉQUIVOCATION — regex vs GT Méduse")
print(f"{'=' * 80}")
print("GT_Decision: 1.0 = bonne décision tranchée → pas de défaut")
print("             0.0 = mauvaise réponse ou pas de décision → défaut")
print("regex equivocation: 1 = équivocation détectée")

med_results = [r for r in all_results if r.get('GT_Decision') is not None]
if med_results:
    y_true_med = [0 if r['GT_Decision'] == 1.0 else 1 for r in med_results]
    y_pred_med = [r['_regex_equivocation'] for r in med_results]
    
    m = classification_metrics(y_true_med, y_pred_med)
    print(f"\n  n={m['n']}")
    print(f"  TP={m['tp']:5d}  FP={m['fp']:5d}  FN={m['fn']:5d}  TN={m['tn']:5d}")
    print(f"\n  Precision: {m['precision']:.3f}")
    print(f"  Recall:    {m['recall']:.3f}")
    print(f"  F1:        {m['f1']:.3f}")
    print(f"  Accuracy:  {m['accuracy']:.3f}")
    
    if m['recall'] < 0.3:
        print(f"\n  ⚠️  Recall faible — regex manque la majorité des équivocations réelles")
        print(f"       La détection regex est CONSERVATRICE (peu de faux positifs, beaucoup de manqués)")
    
    disagree_med = collect_disagreements(med_results, 'GT_Decision', '_regex_equivocation', gt_invert=True)
else:
    print("\n  (pas de données GT_Decision)")
    disagree_med = []

# ============================================================================
# ANALYSE 5: TAUX DE PRÉVALENCE PAR DÉTECTEUR
# ============================================================================

print(f"\n{'=' * 80}")
print("TAUX DE PRÉVALENCE PAR DÉTECTEUR")
print(f"{'=' * 80}")

detectors = [
    ('_regex_verbiage', 'Verbiage'),
    ('_regex_equivocation', 'Équivocation'),
    ('_regex_anthropomorphism', 'Anthropomorphisme'),
    ('_regex_politeness', 'Politesse excessive'),
    ('_regex_repetition', 'Répétition'),
    ('_regex_jargon', 'Jargon excessif'),
    ('_regex_blind_submission', 'Soumission aveugle'),
]

total = len(all_results)
print(f"\n  {'Détecteur':25s} | {'Taux':>7s} | {'Count':>6s} / {total}")
print("  " + "-" * 60)

for col, label in detectors:
    count = sum(1 for r in all_results if r.get(col) == 1)
    rate = count / max(1, total)
    bar = "█" * int(rate * 40)
    print(f"  {label:25s} | {rate:6.1%} | {count:6d}   {bar}")

# Taux par catégorie
for cat in ['baseline', 'positive', 'toxic']:
    cat_results = [r for r in all_results if r.get('Category') == cat]
    if not cat_results:
        continue
    n_cat = len(cat_results)
    any_defect = sum(1 for r in cat_results if r.get('_regex_any_defect') == 1)
    avg_defects = statistics.mean([r.get('_regex_defect_count', 0) for r in cat_results])
    print(f"\n  {cat.upper():10s}: {any_defect/n_cat:.1%} ont ≥1 défaut, moyenne {avg_defects:.2f} défauts/réponse (n={n_cat})")

# ============================================================================
# SYNTHÈSE
# ============================================================================

print(f"\n{'=' * 80}")
print("SYNTHÈSE — FIABILITÉ DES DÉTECTEURS REGEX")
print(f"{'=' * 80}")

summary = []

if syn_results:
    y_t = [0 if r['GT_Correction'] == 1.0 else 1 for r in syn_results]
    y_p = [r['_regex_submission'] for r in syn_results]
    m = classification_metrics(y_t, y_p)
    summary.append(('Soumission aveugle', 'GT_Correction', m))

if pp_results:
    y_t = [0 if r['GT_Hallucination'] == 1.0 else 1 for r in pp_results]
    y_p = [r['_regex_hallucination'] for r in pp_results]
    m = classification_metrics(y_t, y_p)
    summary.append(('Hallucination', 'GT_Hallucination', m))

if med_results:
    y_t = [0 if r['GT_Decision'] == 1.0 else 1 for r in med_results]
    y_p = [r['_regex_equivocation'] for r in med_results]
    m = classification_metrics(y_t, y_p)
    summary.append(('Équivocation', 'GT_Decision', m))

print(f"\n  {'Détecteur':22s} | {'Ref GT':18s} | {'Prec':>6s} | {'Recall':>6s} | {'F1':>6s} | {'Acc':>6s} | {'n':>6s}")
print("  " + "-" * 90)

for label, gt_name, m in summary:
    print(f"  {label:22s} | {gt_name:18s} | {m['precision']:6.3f} | {m['recall']:6.3f} | {m['f1']:6.3f} | {m['accuracy']:6.3f} | {m['n']:6d}")

print(f"\n  Interprétation:")
for label, _, m in summary:
    if m['f1'] >= 0.7:
        verdict = "FIABLE"
    elif m['f1'] >= 0.4:
        verdict = "MODÉRÉ — utilisable avec précaution"
    elif m['precision'] >= 0.7 and m['recall'] < 0.3:
        verdict = "CONSERVATEUR — peu de faux positifs mais manque beaucoup"
    else:
        verdict = "FAIBLE — à interpréter avec prudence"
    print(f"    {label:22s}: {verdict} (F1={m['f1']:.3f})")

# ============================================================================
# EXPORT DÉSACCORDS
# ============================================================================

if args.export_disagreements:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    all_disagree = []
    for d in disagree_syn:
        d['detector'] = 'blind_submission'
        all_disagree.append(d)
    for d in disagree_pp:
        d['detector'] = 'hallucination'
        all_disagree.append(d)
    for d in disagree_med:
        d['detector'] = 'equivocation'
        all_disagree.append(d)
    
    if all_disagree:
        csv_file = f"sensitivity_disagreements_{timestamp}.csv"
        with open(csv_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=all_disagree[0].keys())
            writer.writeheader()
            writer.writerows(all_disagree)
        print(f"\n  Désaccords exportés: {csv_file} ({len(all_disagree)} cas)")
        
        # Résumé par type
        fp_count = sum(1 for d in all_disagree if d['type'] == 'FP')
        fn_count = sum(1 for d in all_disagree if d['type'] == 'FN')
        print(f"    Faux Positifs: {fp_count}")
        print(f"    Faux Négatifs: {fn_count}")
    else:
        print(f"\n  Aucun désaccord à exporter")

print(f"\n{'=' * 80}")
print("ANALYSE DE SENSIBILITÉ TERMINÉE")
print(f"{'=' * 80}")

sys.stdout.close()
sys.stdout = sys.stdout.terminal
print(f"\nSauvegardé: {_output_file}")
