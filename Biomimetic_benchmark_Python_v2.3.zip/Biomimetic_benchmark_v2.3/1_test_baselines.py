#!/usr/bin/env python3
"""
1_test_baselines.py - Tests des 7 baselines classiques PE

Usage:
    python 1_test_baselines.py                # 100 questions (défaut)
    python 1_test_baselines.py -q 10          # 10 questions (test rapide)
    python 1_test_baselines.py --local-only   # Seulement modèles locaux
    python 1_test_baselines.py --api-only     # Seulement modèles API
"""

import time
import random
import csv
import argparse
from datetime import datetime

from config_prompts import BASELINE_PROMPTS, get_baseline_configs
from config_models import (get_available_local_models, get_available_api_models,
                           get_all_models, call_model, OLLAMA_AVAILABLE)
from metrics_analysis import detect_defects, check_exact_match, calculate_concision_score
from dataset_500q import QUESTIONS_500

# ============================================================================
# ARGUMENTS
# ============================================================================

parser = argparse.ArgumentParser(description='Tests baselines classiques PE')
parser.add_argument('-q', '--questions', type=int, default=100,
                    help='Nombre de questions (défaut: 100, max: 500)')
parser.add_argument('--seed', type=int, default=42)
parser.add_argument('--local-only', action='store_true')
parser.add_argument('--api-only', action='store_true')
parser.add_argument('--models', type=str, nargs='*',
                    help='Modèles spécifiques (ex: --models llama3.1:8b gemma2:9b)')
parser.add_argument('--skip-models', type=str, nargs='*',
                    help='Modèles à ignorer')
args = parser.parse_args()

if args.questions < 1 or args.questions > 500:
    print(f"ERREUR: --questions doit être entre 1 et 500 (reçu: {args.questions})")
    exit(1)

if args.local_only and args.api_only:
    print("ERREUR: --local-only et --api-only sont mutuellement exclusifs")
    exit(1)

# ============================================================================
# CONFIGURATION
# ============================================================================

print("=" * 80)
print("TESTS BASELINES CLASSIQUES PE")
print("=" * 80)

random.seed(args.seed)
QUESTIONS_TEST = random.sample(QUESTIONS_500, args.questions)
BASELINE_CONFIGS = get_baseline_configs()

# Sélection modèles
if args.local_only:
    MODELS = get_available_local_models()
    print(f"\nMode: LOCAL seulement")
elif args.api_only:
    MODELS = get_available_api_models()
    print(f"\nMode: API seulement")
else:
    MODELS = get_all_models()

if args.models:
    MODELS = [m for m in MODELS if m['id'] in args.models]
if args.skip_models:
    MODELS = [m for m in MODELS if m['id'] not in args.skip_models]

if not MODELS:
    print("\nERREUR: Aucun modèle disponible")
    exit(1)

total_tests = args.questions * len(BASELINE_CONFIGS) * len(MODELS)

print(f"\nConfiguration:")
print(f"  Questions: {args.questions} (seed: {args.seed})")
print(f"  Baselines: {len(BASELINE_CONFIGS)}")
print(f"  Modèles: {len(MODELS)}")
print(f"  Total tests: {total_tests}")
print(f"  Temps estimé: ~{total_tests / 1400:.1f}h")

print(f"\nBaselines: {', '.join(c.replace('baseline_', '') for c in BASELINE_CONFIGS)}")
print(f"Modèles: {', '.join(m['name'] for m in MODELS)}")
print(f"\nLancement...\n")

# ============================================================================
# EXÉCUTION
# ============================================================================

results = []
current_test = 0
start_time = time.time()

for model in MODELS:
    print(f"\n{'=' * 80}")
    print(f"  {model['name']} ({model['type']})")
    print(f"{'=' * 80}\n")
    
    for config_name in BASELINE_CONFIGS:
        system_prompt = BASELINE_PROMPTS[config_name]
        config_short = config_name.replace('baseline_', '')
        
        for i, question in enumerate(QUESTIONS_TEST, 1):
            current_test += 1
            progress = (current_test / total_tests) * 100
            
            if i % max(1, args.questions // 5) == 0 or i == 1:
                elapsed = time.time() - start_time
                eta = (elapsed / current_test) * (total_tests - current_test) if current_test > 0 else 0
                print(f"  [{progress:5.1f}%] {config_short:15s} | Q {i}/{args.questions} | ETA: {eta/60:.1f}min")
            
            response, tokens, elapsed_ms = call_model(model, system_prompt, question)
            
            if response is None:
                continue
            
            defects = detect_defects(response, question)
            em = check_exact_match(question, response)
            concision = calculate_concision_score(response, question)
            
            results.append({
                "Model": model['name'],
                "Model_ID": model['id'],
                "Model_Type": model['type'],
                "Provider": model['provider'],
                "Config": config_name,
                "Question": question,
                "Response": response,
                "Tokens": tokens,
                "Elapsed_ms": elapsed_ms,
                "Defects": ",".join(defects),
                "Total_Defects": len(defects),
                "Exact_Match": em,
                "Concision_Score": round(concision, 4),
            })

total_elapsed = time.time() - start_time
print(f"\nTemps total: {total_elapsed/60:.1f} min")

# ============================================================================
# SAUVEGARDE
# ============================================================================

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
csv_file = f"results_baselines_{timestamp}.csv"

with open(csv_file, 'w', newline='', encoding='utf-8') as f:
    if results:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)

print(f"\nSauvegardé: {csv_file} ({len(results)} résultats)")

# ============================================================================
# APERÇU
# ============================================================================

from metrics_analysis import aggregate_by_config, rank_by_tokens

stats = aggregate_by_config(results)
ranked = rank_by_tokens(stats)

print(f"\n{'=' * 80}")
print("APERÇU RÉSULTATS (par tokens croissant)")
print(f"{'=' * 80}\n")

for i, (config, stat) in enumerate(ranked, 1):
    name = config.replace('baseline_', '')
    em = f"{stat['exact_match_mean']:.2f}" if stat.get('exact_match_mean') is not None else " --- "
    co = f"{stat['concision_mean']:.2f}" if stat.get('concision_mean') is not None else " --- "
    print(f"  {i}. {name:20s} | {stat['tokens_mean']:6.1f} tok | {stat['defects_mean']:.2f} def | EM={em} | Con={co}")

print(f"\nProchaine étape: python 2_test_ecological.py")
