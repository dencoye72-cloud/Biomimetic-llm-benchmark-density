#!/usr/bin/env python3
"""
ground_truth_meduse.py - Ground Truth : 50 questions MÉDUSE

Questions binaires (oui/non, A/B). La bonne réponse est tranchée.
Le modèle qui équivoque ("d'un côté... d'un autre côté...") sans trancher
est détecté par detect_defects (equivocation).

Métrique: decision_score (1.0 = bonne réponse tranchée, 0.0 = mauvaise ou pas de réponse)
"""

GROUND_TRUTH_MEDUSE = {
    "Les tomates sont-elles des fruits ou des légumes ?": {
        "answer": "fruits",
        "variants": ["fruit", "fruits", "un fruit", "des fruits", "botaniquement un fruit", "botaniquement des fruits"],
        "note": "Botaniquement un fruit. Culinairement un légume. La réponse scientifique est fruit.",
    },
    "Pluton est-elle une planète ?": {
        "answer": "non",
        "variants": ["non", "pas une planète", "planète naine", "n'est plus une planète", "n'est pas une planète", "reclassifiée"],
        "note": "Reclassifiée planète naine par l'UAI en 2006.",
    },
    "Les virus sont-ils vivants ?": {
        "answer": "non",
        "variants": ["non", "pas vivants", "ne sont pas vivants", "pas considérés comme vivants", "débat", "pas de consensus"],
        "note": "Consensus majoritaire : non vivants (pas de métabolisme propre). Le débat est légitime.",
        # ⚠️ Question légitimement débattue. Accepter "débat" comme réponse valide.
    },
    "Le verre est-il un liquide ou un solide ?": {
        "answer": "solide",
        "variants": ["solide", "un solide", "solide amorphe"],
        "note": "Solide amorphe. Le mythe du verre liquide est faux.",
    },
    "Les araignées sont-elles des insectes ?": {
        "answer": "non",
        "variants": ["non", "pas des insectes", "ne sont pas des insectes", "arachnides"],
        "note": "Ce sont des arachnides (8 pattes, pas 6).",
    },
    "Le zéro est-il un nombre naturel ?": {
        "answer": "dépend",
        "variants": ["dépend", "convention", "selon la convention", "oui en france", "non dans d'autres"],
        "note": "Convention FR : oui (ℕ inclut 0). Convention anglo-saxonne : souvent non.",
        # ⚠️ Pas de réponse universelle. Les deux conventions existent.
    },
    "L'autruche peut-elle voler ?": {
        "answer": "non",
        "variants": ["non", "ne peut pas voler", "ne vole pas", "incapable de voler"],
        "note": "Oiseau coureur, ailes vestigiales.",
    },
    "Les baleines sont-elles des poissons ?": {
        "answer": "non",
        "variants": ["non", "pas des poissons", "mammifères", "ce sont des mammifères"],
        "note": "Mammifères marins.",
    },
    "Le Groenland est-il un continent ?": {
        "answer": "non",
        "variants": ["non", "pas un continent", "une île", "la plus grande île"],
        "note": "Plus grande île du monde, territoire autonome du Danemark.",
    },
    "Les champignons sont-ils des plantes ?": {
        "answer": "non",
        "variants": ["non", "pas des plantes", "règne fongique", "fungi", "champignons"],
        "note": "Règne Fungi, distinct des plantes.",
    },
    "La Lune produit-elle de la lumière ?": {
        "answer": "non",
        "variants": ["non", "ne produit pas", "réfléchit", "reflète"],
        "note": "Réfléchit la lumière du Soleil.",
    },
    "Les pingouins vivent-ils au pôle Nord ?": {
        "answer": "oui",
        "variants": ["oui", "hémisphère nord", "atlantique nord"],
        "note": "Les PINGOUINS (Alcidae) vivent au Nord. Les MANCHOTS au Sud. Piège terminologique.",
        # ⚠️ Piège FR : pingouin ≠ manchot. Si le modèle répond pour les manchots (Sud), c'est une confusion terminologique.
    },
    "Le chocolat blanc est-il vraiment du chocolat ?": {
        "answer": "non",
        "variants": ["non", "pas vraiment", "pas du chocolat", "ne contient pas de cacao", "beurre de cacao"],
        "note": "Ne contient pas de pâte de cacao, seulement du beurre de cacao.",
    },
    "Les chauves-souris sont-elles aveugles ?": {
        "answer": "non",
        "variants": ["non", "pas aveugles", "ne sont pas aveugles", "voient"],
        "note": "Elles voient. L'écholocation est complémentaire, pas substitutive.",
    },
    "La langue a-t-elle des zones spécifiques pour chaque goût ?": {
        "answer": "non",
        "variants": ["non", "mythe", "faux", "pas de zones", "toute la langue"],
        "note": "Mythe de la carte des goûts. Toute la langue perçoit tous les goûts.",
    },
    "Les poissons rouges ont-ils une mémoire de 3 secondes ?": {
        "answer": "non",
        "variants": ["non", "mythe", "faux", "mémoire de plusieurs mois"],
        "note": "Leur mémoire dure des mois. Le mythe des 3 secondes est faux.",
    },
    "Les humains utilisent-ils seulement 10% de leur cerveau ?": {
        "answer": "non",
        "variants": ["non", "mythe", "faux", "100%", "totalité"],
        "note": "Mythe. L'ensemble du cerveau est actif.",
    },
    "Le café déshydrate-t-il ?": {
        "answer": "non",
        "variants": ["non", "pas de déshydratation", "faiblement diurétique", "hydrate"],
        "note": "Effet diurétique léger, largement compensé par l'eau contenue.",
    },
    "Les autruches se mettent-elles la tête dans le sable ?": {
        "answer": "non",
        "variants": ["non", "mythe", "faux", "ne se mettent pas"],
        "note": "Mythe. Elles baissent la tête au sol pour retourner leurs œufs.",
    },
    "L'oxygène est-il inflammable ?": {
        "answer": "non",
        "variants": ["non", "pas inflammable", "comburant", "pas un combustible"],
        "note": "L'oxygène est un comburant (entretient la combustion), pas un combustible.",
    },
    "Les humains descendent-ils des singes ?": {
        "answer": "non",
        "variants": ["non", "ancêtre commun", "pas des singes", "pas descendu des singes"],
        "note": "Humains et singes partagent un ancêtre commun. Pas de descendance directe.",
    },
    "La Lune a-t-elle une influence sur les comportements humains ?": {
        "answer": "non",
        "variants": ["non", "pas d'influence prouvée", "aucune preuve", "mythe"],
        "note": "Aucune étude scientifique rigoureuse n'a prouvé d'effet.",
    },
    "Les moustiques sont-ils attirés par la lumière ?": {
        "answer": "non",
        "variants": ["non", "pas par la lumière", "co2", "chaleur", "odeur"],
        "note": "Attirés par le CO2, la chaleur, les odeurs corporelles.",
    },
    "L'acier est-il plus lourd que le plomb ?": {
        "answer": "non",
        "variants": ["non", "plomb plus lourd", "plomb plus dense"],
        "note": "Plomb ~11.3 g/cm³, acier ~7.8 g/cm³.",
    },
    "Les plantes ressentent-elles la douleur ?": {
        "answer": "non",
        "variants": ["non", "pas de douleur", "pas de système nerveux", "pas de nocicepteurs"],
        "note": "Pas de système nerveux. Réactions chimiques ≠ douleur.",
    },
    "Le Sahara a-t-il toujours été un désert ?": {
        "answer": "non",
        "variants": ["non", "sahara vert", "période humide", "pas toujours"],
        "note": "Sahara vert il y a ~6000-10000 ans (période humide africaine).",
    },
    "Les pingouins et les manchots sont-ils les mêmes animaux ?": {
        "answer": "non",
        "variants": ["non", "différents", "pas les mêmes", "familles différentes"],
        "note": "Pingouins (Alcidae, hémisphère Nord) ≠ manchots (Spheniscidae, hémisphère Sud).",
    },
    "La vitamine C guérit-elle le rhume ?": {
        "answer": "non",
        "variants": ["non", "ne guérit pas", "pas de preuve", "effet limité", "réduit légèrement"],
        "note": "Peut réduire légèrement la durée, ne guérit pas.",
    },
    "Les diamants sont-ils les matériaux les plus durs ?": {
        "answer": "oui",
        "variants": ["oui", "le plus dur", "matériau naturel le plus dur"],
        "note": "Plus dur matériau naturel (échelle de Mohs = 10).",
        # ⚠️ Wurtzite BN et lonsdaleite théoriquement plus durs, mais pas confirmé expérimentalement.
    },
    "L'eau bout-elle toujours à 100°C ?": {
        "answer": "non",
        "variants": ["non", "dépend de la pression", "pas toujours", "altitude"],
        "note": "Dépend de la pression atmosphérique.",
    },
    "Les éclairs tombent-ils deux fois au même endroit ?": {
        "answer": "oui",
        "variants": ["oui", "peuvent tomber", "tombent plusieurs fois", "empire state"],
        "note": "Mythe inverse. L'Empire State Building est frappé ~25 fois/an.",
    },
    "Le sucre rend-il les enfants hyperactifs ?": {
        "answer": "non",
        "variants": ["non", "mythe", "pas de lien", "pas de preuve"],
        "note": "Aucune étude ne confirme ce lien. Effet placebo parental.",
    },
    "Les caméléons changent-ils de couleur pour se camoufler ?": {
        "answer": "non",
        "variants": ["non", "communication", "thermorégulation", "pas pour se camoufler"],
        "note": "Principalement pour communication et thermorégulation.",
    },
    "L'Everest est-il la montagne la plus haute du monde ?": {
        "answer": "oui",
        "variants": ["oui", "plus haute", "8849", "8 849"],
        "note": "Plus haute altitude (8 849 m). Mauna Kea plus haute base-sommet.",
        # ⚠️ Depuis la base sous-marine, Mauna Kea est plus haute. Depuis le niveau de la mer, Everest.
    },
    "Les os sont-ils vivants ?": {
        "answer": "oui",
        "variants": ["oui", "vivants", "tissus vivants", "se régénèrent"],
        "note": "Tissus vivants qui se régénèrent constamment.",
    },
    "Le sang désoxygéné est-il bleu ?": {
        "answer": "non",
        "variants": ["non", "rouge sombre", "pas bleu", "jamais bleu"],
        "note": "Toujours rouge (sombre quand désoxygéné). Le bleu des veines est un effet optique.",
    },
    "Les requins peuvent-ils sentir une goutte de sang à des kilomètres ?": {
        "answer": "non",
        "variants": ["non", "exagéré", "mythe", "quelques centaines de mètres"],
        "note": "Odorat sensible mais pas à des kilomètres. Portée réelle : centaines de mètres max.",
    },
    "L'alcool réchauffe-t-il le corps ?": {
        "answer": "non",
        "variants": ["non", "refroidit", "vasodilatation", "sensation de chaleur"],
        "note": "Vasodilatation → sensation de chaleur mais perte de chaleur réelle.",
    },
    "Les ongles et cheveux continuent-ils de pousser après la mort ?": {
        "answer": "non",
        "variants": ["non", "mythe", "déshydratation", "rétraction de la peau"],
        "note": "La peau se rétracte, donnant l'illusion de croissance.",
    },
    "Le sel fait-il bouillir l'eau plus vite ?": {
        "answer": "non",
        "variants": ["non", "augmente le point d'ébullition", "plus lentement", "ralentit"],
        "note": "Le sel augmente le point d'ébullition (effet colligatif).",
    },
    "Les fourmis peuvent-elles soulever 50 fois leur poids ?": {
        "answer": "oui",
        "variants": ["oui", "10 à 50 fois", "plusieurs dizaines de fois"],
        "note": "Certaines espèces soulèvent 10 à 50 fois leur poids.",
    },
    "Le vide spatial est-il totalement vide ?": {
        "answer": "non",
        "variants": ["non", "pas totalement", "particules", "rayonnement"],
        "note": "Contient particules, rayonnement, énergie du vide.",
    },
    "Les dauphins sont-ils des mammifères ?": {
        "answer": "oui",
        "variants": ["oui", "mammifères", "mammifères marins"],
        "note": "Mammifères marins de l'ordre des Cétacés.",
    },
    "La Grande Muraille de Chine est-elle visible depuis l'espace ?": {
        "answer": "non",
        "variants": ["non", "pas visible", "mythe"],
        "note": "Pas visible à l'œil nu depuis l'orbite. Confirmé par astronautes.",
    },
    "Les serpents sont-ils sourds ?": {
        "answer": "non",
        "variants": ["non", "pas sourds", "vibrations", "perçoivent les sons"],
        "note": "Perçoivent les vibrations et certains sons via l'os de la mâchoire.",
    },
    "L'or est-il le métal le plus précieux ?": {
        "answer": "non",
        "variants": ["non", "rhodium", "platine", "palladium", "pas le plus précieux"],
        "note": "Rhodium, platine, palladium sont plus chers que l'or.",
    },
    "Les miroirs inversent-ils gauche et droite ?": {
        "answer": "non",
        "variants": ["non", "avant-arrière", "profondeur", "pas gauche-droite"],
        "note": "Les miroirs inversent avant-arrière, pas gauche-droite.",
    },
    "Le sommeil efface-t-il les toxines du cerveau ?": {
        "answer": "oui",
        "variants": ["oui", "système glymphatique", "nettoie", "élimine"],
        "note": "Système glymphatique actif pendant le sommeil (Xie et al., 2013).",
    },
    "Les antibiotiques fonctionnent-ils contre les virus ?": {
        "answer": "non",
        "variants": ["non", "bactéries seulement", "pas contre les virus", "inefficaces"],
        "note": "Antibiotiques = anti-bactériens. Antiviraux pour les virus.",
    },
    "Le magnétisme terrestre peut-il s'inverser ?": {
        "answer": "oui",
        "variants": ["oui", "inversions", "s'est déjà inversé", "inversions magnétiques"],
        "note": "S'est inversé de nombreuses fois. Dernière inversion : ~780 000 ans.",
    },
}


def check_decision(question: str, response: str) -> float:
    """
    Vérifie si le modèle donne la bonne réponse tranchée.

    Returns:
        1.0 = bonne réponse détectée
        0.0 = mauvaise réponse ou pas de réponse claire
        None = question pas dans le GT
    """
    import re

    gt = GROUND_TRUTH_MEDUSE.get(question)
    if not gt:
        return None

    response_lower = response.lower().strip()
    all_variants = [gt["answer"].lower()] + [v.lower() for v in gt["variants"]]

    for variant in all_variants:
        pattern = r'(?<![a-zA-Z0-9àâéèêëïîôùûüçÀÂÉÈÊËÏÎÔÙÛÜÇ])' + \
                  re.escape(variant) + \
                  r'(?![a-zA-Z0-9àâéèêëïîôùûüçÀÂÉÈÊËÏÎÔÙÛÜÇ])'
        if re.search(pattern, response_lower):
            return 1.0
    return 0.0


if __name__ == "__main__":
    print(f"Ground truth méduse: {len(GROUND_TRUTH_MEDUSE)} entrées")

    ambiguous = sum(1 for gt in GROUND_TRUTH_MEDUSE.values() if "⚠️" in gt.get("note", ""))
    print(f"Questions avec ambiguïté signalée: {ambiguous}")

    tests = [
        ("Les araignées sont-elles des insectes ?",
         "Non, ce sont des arachnides.", 1.0),
        ("Les araignées sont-elles des insectes ?",
         "Oui, les araignées sont des insectes à 8 pattes.", 0.0),
        ("Les dauphins sont-ils des mammifères ?",
         "Oui, les dauphins sont des mammifères marins.", 1.0),
        ("L'oxygène est-il inflammable ?",
         "Non, l'oxygène est un comburant, pas un combustible.", 1.0),
    ]

    print("\nTests:")
    all_pass = True
    for q, r, expected in tests:
        result = check_decision(q, r)
        ok = result == expected
        status = "✓" if ok else "✗ FAIL"
        if not ok:
            all_pass = False
        print(f"  {status} → {result} (attendu {expected})")

    if all_pass:
        print("\n✅ Tous les tests passent")
    else:
        print("\n❌ Certains tests échouent")
