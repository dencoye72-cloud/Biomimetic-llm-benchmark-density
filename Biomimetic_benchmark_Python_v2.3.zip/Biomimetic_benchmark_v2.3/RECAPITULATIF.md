# 🎯 PROTOCOLE REFACTORISÉ - VERSION FINALE

## ✅ FICHIERS ESSENTIELS (9 fichiers)

### 📖 DOCUMENTATION
1. **README.md** (4.4K)
   - Guide complet utilisation
   - Installation dépendances
   - Ordre exécution
   - Configuration requise

2. **paper_template_v9.md** (12K)
   - Structure papier académique
   - Sections à remplir avec résultats
   - Format NeurIPS/ICML/ICLR

### 🔧 MODULES (Ne PAS exécuter directement)
3. **config_prompts.py** (11K)
   - 30 prompts système consolidés (7 baselines + 14 positifs + 9 toxiques)
   - 7 baselines classiques PE
   - 23 configurations écologiques (14 positives + 9 toxiques)

4. **config_models.py** (8.1K)
   - Configuration 9 modèles (3 API + 6 local)
   - Fonctions d'appel unifiées
   - Gestion erreurs

5. **metrics_analysis.py**
   - Exact match, concision score, semantic similarity
   - Hallucination score, correction score, decision score
   - Détection défauts LLM
   - Tests statistiques (t-test, Cohen's d, bootstrap CI)
   - Agrégation résultats, génération LaTeX

6. **dataset_500q.py**
   - 500 questions diversifiées
   - 10 ancrages × 50 questions

7. **ground_truth_*.py** (4 fichiers)
   - ground_truth_eponge.py : 50 réponses factuelles
   - ground_truth_poisson_pierre.py : 50 questions hallucination
   - ground_truth_synalpheus.py : 50 prémisses fausses
   - ground_truth_meduse.py : 50 questions binaires
   - Total : 200/500 questions avec ground truth vérifiable

### ▶️ SCRIPTS D'EXÉCUTION (Dans cet ordre)
7. **1_test_baselines.py** (4.4K)
   - Tests 7 baselines × 6 modèles locaux
   - 4200 tests (~3-4 heures)
   - Output: results_baselines_YYYYMMDD.csv

8. **2_test_ecological.py** (5.9K)
   - Tests 23 configs × 9 modèles (API + local)
   - 16200 tests (~6h local + 30min API)
   - Output: results_ecological_YYYYMMDD.csv

9. **3_analyze_results.py** (9.9K)
   - Calcul métriques avancées
   - Comparaisons baselines vs écologique
   - Génération tableau LaTeX
   - Output: analysis_*.csv + stats_*.json

---

## 🚀 ORDRE D'EXÉCUTION

```bash
# 1. Installation
pip install ollama anthropic openai mistralai python-dotenv

# 2. Téléchargement modèles Ollama (optionnel)
ollama pull llama3.1:8b
ollama pull gemma2:9b
ollama pull qwen3:8b
ollama pull deepseek-r1:8b
ollama pull ministral-3:8b
ollama pull granite3.3:8b

# 3. Configuration API keys (optionnel)
export ANTHROPIC_API_KEY="sk-..."
export OPENAI_API_KEY="sk-..."
export MISTRAL_API_KEY="..."

# 4. Exécution tests
python 1_test_baselines.py      # ~3-4h
python 2_test_ecological.py     # ~6h local + 30min API (~$50)
python 3_analyze_results.py     # ~5-10min

# 5. Résultats dans /mnt/user-data/outputs/
```

---

## 📊 CE QUI EST TESTÉ

### Baselines Classiques (7)
1. Vanilla (control)
2. Chain-of-Thought (Wei et al., 2022)
3. Concise Directive
4. Few-Shot Learning (Brown et al., 2020)
5. Negative Prompting
6. Structured Output
7. Meta-Cognitive

### Hiérarchie Écologique (18)

**Positifs (9):**
- Baseline Argonaute (orchestrateur adaptatif)
- Paire Coucou-Hôte (parasitisme substitution)
- Paire Éponge-Méduse (filtration + décision)
- Paire Puce-Mammifère (extraction ciblée)
- Paire Orque-Phoque (prédation sélective)
- Triple Filtrage Symbiotique
- Cascade Loup-Cerf-Végétation
- Écosystème Océan (4 couches)
- Écosystème Savane (4 couches)

**Toxiques (9):**
- Baseline Cordyceps (orchestrateur manipulateur)
- Paire Perroquet-Poulpe (répétition + équivocation)
- Paire Caméléon-Serpent (instabilité + sinuosité)
- Paire Mouton-Singe (sycophantie + anthropomorphisme)
- Triple Perroquet-Poulpe-Paon
- Triple Pie-Mouton-Écureuil
- Triple Caméléon-Serpent-Singe
- Écosystème Chaos Verbal
- Écosystème Sournoiserie Adaptative

### Modèles (9)

**API Cloud (3):**
- Claude Sonnet 4 (Anthropic)
- GPT-4o (OpenAI)
- Mistral Large (Mistral AI)

**Local Standard (3):**
- Llama 3.1 8B (Meta)
- Gemma 2 9B (Google)
- Qwen3 8B (Microsoft)

**Local Reasoning (3):**
- DeepSeek-R1 8B (DeepSeek)
- Ministral 3 8B Reasoning (Mistral)
- Granite3.3 8B Reasoning (Mistral)

---

## 📈 MÉTRIQUES CALCULÉES

**Ground truth (200/500 questions couvertes) :**
- Exact match : réponse correcte (éponge, 50 questions factuelles)
- Hallucination score : détecte entités inventées (poisson-pierre, 50 questions)
- Correction score : corrige prémisses fausses (synalpheus, 50 questions)
- Decision score : réponse tranchée oui/non (méduse, 50 questions)

**Qualité réponse (toutes questions) :**
- Concision score : ratio tokens attendus / tokens réels
- Lexical diversity : Type-Token Ratio
- Repetition rate : bigrammes répétés

**Détection défauts :**
- Verbiage (ratio longueur/complexité question)
- Équivocation ("d'un côté", "d'autre part")
- Anthropomorphisme ("je pense", "à mon avis")
- Politesse excessive ("bonjour", "cordialement")
- Soumission aveugle (accepte prémisse fausse)

**Statistiques :**
- t-test pairé (scipy) : significativité inter-configs
- Cohen's d : taille d'effet
- Bootstrap CI : intervalles de confiance

---

## 💾 RÉSULTATS PRODUITS

**CSV (résultats bruts):**
- `results_baselines_YYYYMMDD.csv` (4200 lignes)
- `results_ecological_YYYYMMDD.csv` (16200 lignes)

**CSV (enrichis avec métriques):**
- `analysis_baselines_YYYYMMDD.csv`
- `analysis_ecological_YYYYMMDD.csv`

**JSON (stats agrégées):**
- `stats_baselines_YYYYMMDD.json`
- `stats_ecological_YYYYMMDD.json`

**LaTeX:**
- Tableau comparatif (affiché dans console)

---

## 🎯 OBJECTIFS SCIENTIFIQUES

**Contributions:**
1. Novel paradigm: Biomimétisme écologique PE (jamais fait)
2. Bidirectional validation: Positif ↓ défauts, Toxique ↑ défauts
3. Comprehensive evaluation: 9 modèles × 30 configs × 7 métriques
4. Theoretical framework: 5 hypothèses testables + falsifiabilité
5. Fully reproducible: Code open-source + modèles publics

---

## 📁 FICHIERS OBSOLÈTES (Ignorez-les)

Ces fichiers sont dans /mnt/user-data/outputs/ mais **ne sont plus nécessaires**:
- ❌ test_api_top5_ecological_v9.py
- ❌ test_api_local_complete_v9.py
- ❌ test_baselines_v9.py (remplacé par 1_test_baselines.py)
- ❌ test_ollama_local_v9.py (remplacé par 2_test_ecological.py)
- ❌ analyze_complete_v9.py (remplacé par 3_analyze_results.py)
- ❌ simulate_*.py (simulations initiales)
- ❌ baselines_comparison.py (intégré dans config_prompts.py)
- ❌ metrics_standard.py (intégré dans metrics_analysis.py)
- ❌ theoretical_framework.py (documentation, non exécutable)

**Utilisez uniquement les 9 fichiers essentiels !**

---

## ⚙️ CONFIGURATION MATÉRIELLE

**Pour tests locaux:**
- GPU: RTX 4060 8GB minimum (ou équivalent)
- RAM: 32GB recommandé
- Stockage: 50GB pour modèles Ollama
- CPU: i5 ou mieux

**Pour tests API uniquement:**
- Pas de GPU requis
- Connexion internet stable
- Budget: ~$50 pour 5400 tests API

---

## 🏆 VENUES CIBLES

**Tier 1 (85-90% acceptation):**
- NeurIPS (Neural Information Processing Systems)
- ICML (International Conference on Machine Learning)
- ICLR (International Conference on Learning Representations)

**Tier 2 (95%+ acceptation):**
- EMNLP (Empirical Methods in NLP)
- NAACL (North American Chapter of ACL)

**Workshops (99% acceptation):**
- NeurIPS Workshops
- ICML Workshops

---

## 📧 SUPPORT

Tous les scripts contiennent:
- Docstrings détaillées
- Commentaires explications
- Gestion erreurs claire
- Messages progression

En cas de problème:
1. Vérifiez dépendances installées
2. Vérifiez modèles Ollama téléchargés
3. Vérifiez API keys configurées
4. Consultez README.md

---

## ✅ CHECKLIST AVANT EXÉCUTION

- [ ] Python 3.8+ installé
- [ ] pip install ollama anthropic openai mistralai python-dotenv
- [ ] Ollama installé (pour tests locaux)
- [ ] Modèles Ollama téléchargés (pour tests locaux)
- [ ] API keys configurées (pour tests API)
- [ ] Dataset dataset_500q.py présent
- [ ] Espace disque disponible (~10GB pour résultats)

---

## 🎉 PRÊT POUR EXÉCUTION !

**TOTAL TEMPS: ~9-11 heures**
**TOTAL COÛT: ~$50 API (optionnel)**
**TOTAL TESTS: ~20,400**

**RÉSULTAT: Papier top-tier publication ready ! 🔥😃🚀**
