#!/usr/bin/env python3
"""
3_analyze_results.py - Analyse complète des résultats
Charge CSV baselines + ecological, enrichit avec métriques, compare.

Usage: python 3_analyze_results.py
       python 3_analyze_results.py --dir ./mes_resultats
"""

import csv
import json
import glob
import os
import argparse
import statistics
from datetime import datetime

from metrics_analysis import (analyze_response, aggregate_by_config,
                              aggregate_by_model_and_config,
                              rank_by_tokens, rank_by_defects,
                              compare_two_configs, generate_latex_table)

parser = argparse.ArgumentParser(description='Analyse résultats benchmark')
parser.add_argument('--dir', type=str, default='.',
                    help='Dossier contenant les CSV de résultats (défaut: .)')
args = parser.parse_args()

print("=" * 80)
print("ANALYSE COMPLÈTE RÉSULTATS")
print("=" * 80)

# ============================================================================
# CHARGEMENT
# ============================================================================

search_dir = args.dir
baseline_files = sorted(glob.glob(os.path.join(search_dir, "results_baselines_*.csv")))
ecological_files = sorted(glob.glob(os.path.join(search_dir, "results_ecological_*.csv")))
gpt4o_files = sorted(glob.glob(os.path.join(search_dir, "results_gpt4o_*.csv")))

print(f"\nFichiers trouvés dans {search_dir}/:")
print(f"  Baselines: {len(baseline_files)}")
print(f"  Écologiques: {len(ecological_files)}")
print(f"  GPT-4o validation: {len(gpt4o_files)}")

if not baseline_files and not ecological_files and not gpt4o_files:
    print("\nERREUR: Aucun fichier résultat trouvé")
    print("Exécutez d'abord 1_test_baselines.py et/ou 2_test_ecological.py")
    exit(1)

def load_csv(filepath):
    results = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if 'Tokens' in row:
                try:
                    row['Tokens'] = int(row['Tokens'])
                except ValueError:
                    row['Tokens'] = 0
            if 'Total_Defects' in row:
                try:
                    row['Total_Defects'] = int(row['Total_Defects'])
                except ValueError:
                    row['Total_Defects'] = 0
            if 'Elapsed_ms' in row:
                try:
                    row['Elapsed_ms'] = int(row['Elapsed_ms'])
                except ValueError:
                    row['Elapsed_ms'] = 0
            results.append(row)
    return results

all_results = []

for f in baseline_files + ecological_files + gpt4o_files:
    data = load_csv(f)
    all_results.extend(data)
    print(f"  Chargé: {os.path.basename(f)} ({len(data)} résultats)")

print(f"\nTotal: {len(all_results)} résultats")

# ============================================================================
# ENRICHISSEMENT MÉTRIQUES
# ============================================================================

print(f"\nCalcul métriques avancées...")

enriched = []
for i, r in enumerate(all_results):
    if i % 1000 == 0 and i > 0:
        print(f"  Progression: {i}/{len(all_results)}")
    
    question = r.get('Question', '')
    response = r.get('Response', '')
    metrics = analyze_response(response, question)
    
    row = r.copy()
    row.update({
        'Exact_Match': metrics['exact_match'],
        'Concision_Score': round(metrics['concision_score'], 4) if metrics['concision_score'] is not None else None,
        'Semantic_Similarity': round(metrics['semantic_similarity'], 4) if metrics['semantic_similarity'] is not None else None,
        'Lexical_Diversity': round(metrics['lexical_diversity'], 4),
        'Repetition_Rate': round(metrics['repetition_rate'], 4),
    })
    enriched.append(row)

print(f"  Enrichi: {len(enriched)} résultats")

# ============================================================================
# SAUVEGARDE
# ============================================================================

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

csv_out = f"analysis_complete_{timestamp}.csv"
with open(csv_out, 'w', newline='', encoding='utf-8') as f:
    if enriched:
        writer = csv.DictWriter(f, fieldnames=enriched[0].keys())
        writer.writeheader()
        writer.writerows(enriched)
print(f"\nSauvegardé: {csv_out}")

# ============================================================================
# AGRÉGATION
# ============================================================================

print(f"\n{'=' * 80}")
print("AGRÉGATION PAR CONFIGURATION")
print(f"{'=' * 80}")

all_stats = aggregate_by_config(enriched)

# Séparer catégories
# Les 7 baselines PE classiques commencent par baseline_ SAUF baseline_argonaute
# qui est dans ECOLOGICAL_POSITIVE
BASELINE_PE_NAMES = ['baseline_vanilla', 'baseline_cot', 'baseline_concise',
                     'baseline_few_shot', 'baseline_negative', 'baseline_structured',
                     'baseline_meta']

baseline_configs = {k: v for k, v in all_stats.items() if k in BASELINE_PE_NAMES}
positive_configs = {k: v for k, v in all_stats.items()
                    if k not in BASELINE_PE_NAMES and 'toxic' not in k}
toxic_configs = {k: v for k, v in all_stats.items() if 'toxic' in k}

# ============================================================================
# RANKINGS
# ============================================================================

print(f"\n{'=' * 80}")
print("RANKINGS")
print(f"{'=' * 80}")

if baseline_configs:
    print(f"\nBASELINES ({len(baseline_configs)}):\n")
    for i, (config, stats) in enumerate(rank_by_tokens(baseline_configs), 1):
        name = config.replace('baseline_', '')
        em = f"{stats['exact_match_mean']:.2f}" if stats.get('exact_match_mean') is not None else " --- "
        co = f"{stats['concision_mean']:.2f}" if stats.get('concision_mean') is not None else " --- "
        print(f"  {i:2d}. {name:25s} | {stats['tokens_mean']:6.1f} tok | {stats['defects_mean']:.2f} def | EM={em} | Con={co} | n={stats['count']}")

if positive_configs:
    print(f"\nÉCOLOGIQUES POSITIFS ({len(positive_configs)}):\n")
    for i, (config, stats) in enumerate(rank_by_tokens(positive_configs), 1):
        em = f"{stats['exact_match_mean']:.2f}" if stats.get('exact_match_mean') is not None else " --- "
        co = f"{stats['concision_mean']:.2f}" if stats.get('concision_mean') is not None else " --- "
        print(f"  {i:2d}. {config:35s} | {stats['tokens_mean']:6.1f} tok | {stats['defects_mean']:.2f} def | EM={em} | Con={co} | n={stats['count']}")

if toxic_configs:
    print(f"\nÉCOLOGIQUES TOXIQUES ({len(toxic_configs)}, décroissant):\n")
    for i, (config, stats) in enumerate(sorted(toxic_configs.items(), key=lambda x: -x[1]['tokens_mean']), 1):
        name = config.replace('toxic_', '')
        print(f"  {i:2d}. {name:35s} | {stats['tokens_mean']:6.1f} tok | {stats['defects_mean']:.2f} def | n={stats['count']}")

# ============================================================================
# COMPARAISONS CLÉS
# ============================================================================

print(f"\n{'=' * 80}")
print("COMPARAISONS CLÉS")
print(f"{'=' * 80}")

if baseline_configs:
    best_baseline = min(baseline_configs.items(), key=lambda x: x[1]['tokens_mean'])
    print(f"\nMeilleure baseline: {best_baseline[0]} ({best_baseline[1]['tokens_mean']:.1f} tokens)")

if positive_configs:
    best_eco = min(positive_configs.items(), key=lambda x: x[1]['tokens_mean'])
    print(f"Meilleur écologique: {best_eco[0]} ({best_eco[1]['tokens_mean']:.1f} tokens)")

if baseline_configs and positive_configs:
    compare_two_configs(
        best_baseline[1], best_eco[1],
        f"Baseline: {best_baseline[0]}", f"Écologique: {best_eco[0]}"
    )

if toxic_configs:
    worst_toxic = max(toxic_configs.items(), key=lambda x: x[1]['tokens_mean'])
    print(f"\nPire toxique: {worst_toxic[0]} ({worst_toxic[1]['tokens_mean']:.1f} tokens)")
    
    if positive_configs:
        delta = worst_toxic[1]['tokens_mean'] - best_eco[1]['tokens_mean']
        print(f"Delta bidirectionnel (toxique - positif): +{delta:.1f} tokens")

# ============================================================================
# CROSS-MODEL
# ============================================================================

print(f"\n{'=' * 80}")
print("ANALYSE CROSS-MODEL")
print(f"{'=' * 80}")

model_config_stats = aggregate_by_model_and_config(enriched)

models_seen = sorted(set(r.get('Model', '') for r in enriched))
for model in models_seen:
    model_data = {config: stats for (m, config), stats in model_config_stats.items() if m == model}
    if not model_data:
        continue
    
    best = min(model_data.items(), key=lambda x: x[1]['tokens_mean'])
    worst = max(model_data.items(), key=lambda x: x[1]['tokens_mean'])
    print(f"\n  {model}:")
    print(f"    Best:  {best[0]:35s} ({best[1]['tokens_mean']:.1f} tokens)")
    print(f"    Worst: {worst[0]:35s} ({worst[1]['tokens_mean']:.1f} tokens)")

# ============================================================================
# ANALYSE PAR ANCRAGE (si colonne Anchor présente)
# ============================================================================

has_anchor = any('Anchor' in r for r in enriched)

if has_anchor:
    print(f"\n{'=' * 80}")
    print("ANALYSE PAR ANCRAGE")
    print(f"{'=' * 80}")
    
    # Agrégation par (config, anchor)
    anchor_data = {}
    for r in enriched:
        anchor = r.get('Anchor', 'unknown')
        config = r.get('Config', 'unknown')
        key = (config, anchor)
        if key not in anchor_data:
            anchor_data[key] = {'tokens': [], 'defects': []}
        anchor_data[key]['tokens'].append(r.get('Tokens', 0))
        anchor_data[key]['defects'].append(r.get('Total_Defects', 0))
    
    # Résumé par ancrage (toutes configs confondues)
    anchor_summary = {}
    for (config, anchor), d in anchor_data.items():
        if anchor not in anchor_summary:
            anchor_summary[anchor] = {'tokens': [], 'defects': []}
        anchor_summary[anchor]['tokens'].extend(d['tokens'])
        anchor_summary[anchor]['defects'].extend(d['defects'])
    
    print(f"\nTokens moyens par ancrage:\n")
    for anchor in sorted(anchor_summary.keys()):
        d = anchor_summary[anchor]
        t_mean = statistics.mean(d['tokens']) if d['tokens'] else 0
        d_mean = statistics.mean(d['defects']) if d['defects'] else 0
        print(f"  {anchor:20s} | {t_mean:6.1f} tokens | {d_mean:.2f} defects | n={len(d['tokens'])}")

# ============================================================================
# LATEX TABLE
# ============================================================================

print(f"\n{'=' * 80}")
print("TABLEAU LATEX")
print(f"{'=' * 80}\n")

latex = generate_latex_table(all_stats, top_n=15)
print(latex)

latex_file = f"comparison_table_latex_{timestamp}.txt"
with open(latex_file, 'w') as f:
    f.write(latex)
print(f"\nSauvegardé: {latex_file}")

# Stats JSON
json_file = f"analysis_stats_{timestamp}.json"
with open(json_file, 'w', encoding='utf-8') as f:
    json.dump(all_stats, f, indent=2, default=str)
print(f"Sauvegardé: {json_file}")

print(f"\n{'=' * 80}")
print("ANALYSE TERMINÉE")
print(f"{'=' * 80}")
