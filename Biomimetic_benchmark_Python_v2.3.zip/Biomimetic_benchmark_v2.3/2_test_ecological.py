#!/usr/bin/env python3
"""
2_test_ecological.py - Tests hiérarchie écologique (14 positifs + 9 toxiques)

v2.2 CORRECTION: Sampling ciblé par ancrage.
- Configs positives → questions de leurs ancrages constitutifs
- Configs toxiques → pool complet (pas d'ancrage ciblé)
- Colonne 'Anchor' ajoutée dans CSV pour traçabilité

Usage:
    python 2_test_ecological.py                 # 100 questions (défaut)
    python 2_test_ecological.py -q 10           # 10 questions (rapide)
    python 2_test_ecological.py --local-only    # Seulement locaux
    python 2_test_ecological.py --api-only      # Seulement API
"""

import time
import random
import csv
import argparse
from datetime import datetime

from config_prompts import ECOLOGICAL_POSITIVE, ECOLOGICAL_TOXIC, get_prompt
from config_models import (get_available_api_models, get_available_local_models,
                           get_all_models, call_model, OLLAMA_AVAILABLE)
from metrics_analysis import detect_defects, check_exact_match, calculate_concision_score
from dataset_500q import QUESTIONS_500, QUESTIONS_BY_ANCHOR

# ============================================================================
# ARGUMENTS
# ============================================================================

parser = argparse.ArgumentParser(description='Tests hiérarchie écologique')
parser.add_argument('-q', '--questions', type=int, default=100,
                    help='Nombre de questions (défaut: 100, max: 500)')
parser.add_argument('--seed', type=int, default=42)
parser.add_argument('--local-only', action='store_true')
parser.add_argument('--api-only', action='store_true')
parser.add_argument('--positive-only', action='store_true',
                    help='Tester seulement configs positives (pas toxiques)')
parser.add_argument('--toxic-only', action='store_true',
                    help='Tester seulement configs toxiques')
args = parser.parse_args()

if args.questions < 1 or args.questions > 500:
    print(f"ERREUR: --questions doit être entre 1 et 500 (reçu: {args.questions})")
    exit(1)

if args.local_only and args.api_only:
    print("ERREUR: --local-only et --api-only sont mutuellement exclusifs")
    exit(1)

# ============================================================================
# CONFIGURATION
# ============================================================================

print("=" * 80)
print("TESTS HIÉRARCHIE ÉCOLOGIQUE")
print("=" * 80)

random.seed(args.seed)

# ============================================================================
# MAPPING CONFIG → ANCRAGES CIBLÉS
# Chaque config est testée sur les questions de ses ancrages constitutifs
# Les toxiques n'ont pas d'ancrage ciblé → pool complet (comportement v1)
# ============================================================================

CONFIG_ANCHOR_MAP = {
    # Solos
    "eponge_solo":                  ["eponge"],
    "meduse_solo":                  ["meduse"],
    "espadon_solo":                 ["espadon"],
    "poisson_pierre_solo":          ["poisson_pierre"],
    "synalpheus_solo":              ["synalpheus"],
    # Paires
    "eponge_meduse":                ["eponge", "meduse"],
    "eponge_espadon":               ["eponge", "espadon"],
    "poisson_pierre_meduse":        ["poisson_pierre", "meduse"],
    "nemo_espadon":                 ["nemo", "espadon"],
    # Symbiose
    "symbiose_eponge_synalpheus":   ["eponge", "synalpheus"],
    # Orchestrateur
    "baseline_argonaute":           ["argonaute"],
    # Écosystèmes
    "ecosysteme_filtrage_marine":   ["eponge", "poisson_pierre", "meduse", "espadon"],
    "ecosysteme_precision_marine":  ["dauphin", "tortue", "nemo"],
    "ecosysteme_creativite_marine": ["seiche", "argonaute", "eponge"],
}

def sample_questions_for_config(config_name, n_questions, rng):
    """
    Échantillonne n_questions équilibré par ancrage pour une config donnée.
    - Config positive avec mapping → pioche dans ses ancrages ciblés
    - Config toxique ou sans mapping → pioche dans pool complet (QUESTIONS_500)
    """
    anchors = CONFIG_ANCHOR_MAP.get(config_name)
    
    if not anchors:
        # Toxiques : pool complet, comportement v1
        return rng.sample(QUESTIONS_500, min(n_questions, len(QUESTIONS_500)))
    
    # Pool ciblé : concatène les questions des ancrages concernés
    pool = []
    for anchor in anchors:
        pool.extend(QUESTIONS_BY_ANCHOR.get(anchor, []))
    
    if n_questions >= len(pool):
        return pool[:]
    
    # Échantillonnage équilibré par ancrage
    per_anchor = max(1, n_questions // len(anchors))
    remainder = n_questions - per_anchor * len(anchors)
    
    selected = []
    for anchor in anchors:
        anchor_qs = QUESTIONS_BY_ANCHOR.get(anchor, [])
        n = min(per_anchor, len(anchor_qs))
        selected.extend(rng.sample(anchor_qs, n))
    
    # Distribuer le reste depuis le pool entier (sans doublons)
    if remainder > 0:
        remaining_pool = [q for q in pool if q not in selected]
        selected.extend(rng.sample(remaining_pool, min(remainder, len(remaining_pool))))
    
    return selected

# Sélection configs
if args.positive_only:
    ECOLOGICAL_CONFIGS = list(ECOLOGICAL_POSITIVE.keys())
    print("\nMode: POSITIFS seulement")
elif args.toxic_only:
    ECOLOGICAL_CONFIGS = list(ECOLOGICAL_TOXIC.keys())
    print("\nMode: TOXIQUES seulement")
else:
    ECOLOGICAL_CONFIGS = list(ECOLOGICAL_POSITIVE.keys()) + list(ECOLOGICAL_TOXIC.keys())

# Sélection modèles
if args.local_only:
    ALL_MODELS = get_available_local_models()
elif args.api_only:
    ALL_MODELS = get_available_api_models()
else:
    ALL_MODELS = get_all_models()

if not ALL_MODELS:
    print("\nERREUR: Aucun modèle disponible")
    exit(1)


# Calcul total réel (les solos sont plafonnés à 50Q)
real_questions_per_config = 0
for config_name in ECOLOGICAL_CONFIGS:
    rng_count = random.Random(args.seed)
    qs = sample_questions_for_config(config_name, args.questions, rng_count)
    real_questions_per_config += len(qs)
total_tests = real_questions_per_config * len(ALL_MODELS)

print(f"\nConfiguration:")
print(f"  Questions/config: {args.questions} (seed: {args.seed})")
print(f"  Configs: {len(ECOLOGICAL_CONFIGS)} ({len(ECOLOGICAL_POSITIVE)} positifs + {len(ECOLOGICAL_TOXIC)} toxiques)")
print(f"  Modèles: {len(ALL_MODELS)}")
print(f"  Total tests: {total_tests}")
print(f"  Temps estimé: ~{total_tests / 1400:.1f}h")
print(f"  Sampling: CIBLÉ par ancrage (positifs) / ALÉATOIRE (toxiques)")

print(f"\nModèles: {', '.join(m['name'] for m in ALL_MODELS)}")
print(f"\nLancement...\n")

# ============================================================================
# EXÉCUTION
# ============================================================================

results = []
current_test = 0
start_time = time.time()

for model in ALL_MODELS:
    print(f"\n{'=' * 80}")
    print(f"  {model['name']} ({model['type']})")
    print(f"{'=' * 80}\n")
    
    for config_name in ECOLOGICAL_CONFIGS:
        system_prompt = get_prompt(config_name)
        config_short = config_name.replace('toxic_', 'T:').replace('ecosysteme_', 'eco:').replace('baseline_', '')
        
        # Sampling ciblé par ancrage pour cette config
        rng = random.Random(args.seed)  # Reset seed par config pour reproductibilité
        questions_for_config = sample_questions_for_config(config_name, args.questions, rng)
        n_qs = len(questions_for_config)
        
        anchors = CONFIG_ANCHOR_MAP.get(config_name)
        anchor_info = f"[{'+'.join(anchors)}]" if anchors else "[pool_complet]"
        print(f"  Config: {config_short} {anchor_info} ({n_qs}Q)")
        
        for i, question in enumerate(questions_for_config, 1):
            current_test += 1
            progress = (current_test / total_tests) * 100
            
            if i % max(1, n_qs // 5) == 0 or i == 1:
                elapsed = time.time() - start_time
                eta = (elapsed / current_test) * (total_tests - current_test) if current_test > 0 else 0
                print(f"  [{progress:5.1f}%] {config_short:20s} | Q {i}/{n_qs} | ETA: {eta/60:.1f}min")
            
            response, tokens, elapsed_ms = call_model(model, system_prompt, question)
            
            if response is None:
                continue
            
            defects = detect_defects(response, question)
            em = check_exact_match(question, response)
            concision = calculate_concision_score(response, question)
            category = "toxic" if "toxic" in config_name else "positive"
            
            # Identifier l'ancrage source de la question
            question_anchor = "mixed"
            for anchor_name, anchor_qs in QUESTIONS_BY_ANCHOR.items():
                if question in anchor_qs:
                    question_anchor = anchor_name
                    break
            
            results.append({
                "Model": model['name'],
                "Model_ID": model['id'],
                "Model_Type": model['type'],
                "Provider": model['provider'],
                "Config": config_name,
                "Category": category,
                "Anchor": question_anchor,
                "Question": question,
                "Response": response,
                "Tokens": tokens,
                "Elapsed_ms": elapsed_ms,
                "Defects": ",".join(defects),
                "Total_Defects": len(defects),
                "Exact_Match": em,
                "Concision_Score": round(concision, 4),
            })

total_elapsed = time.time() - start_time
print(f"\nTemps total: {total_elapsed/60:.1f} min")

# ============================================================================
# SAUVEGARDE
# ============================================================================

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
csv_file = f"results_ecological_{timestamp}.csv"

with open(csv_file, 'w', newline='', encoding='utf-8') as f:
    if results:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)

print(f"\nSauvegardé: {csv_file} ({len(results)} résultats)")

# ============================================================================
# APERÇU
# ============================================================================

from metrics_analysis import aggregate_by_config, rank_by_tokens

positive_results = [r for r in results if r['Category'] == 'positive']
toxic_results = [r for r in results if r['Category'] == 'toxic']

if positive_results:
    pos_stats = aggregate_by_config(positive_results)
    ranked_pos = rank_by_tokens(pos_stats)
    
    print(f"\n{'=' * 80}")
    print("TOP 5 POSITIFS (tokens croissant)")
    print(f"{'=' * 80}\n")
    for i, (config, stat) in enumerate(ranked_pos[:5], 1):
        em = f"{stat['exact_match_mean']:.2f}" if stat.get('exact_match_mean') is not None else " --- "
        co = f"{stat['concision_mean']:.2f}" if stat.get('concision_mean') is not None else " --- "
        print(f"  {i}. {config:35s} | {stat['tokens_mean']:6.1f} tok | {stat['defects_mean']:.2f} def | EM={em} | Con={co}")

if toxic_results:
    tox_stats = aggregate_by_config(toxic_results)
    ranked_tox = sorted(tox_stats.items(), key=lambda x: -x[1]['tokens_mean'])
    
    print(f"\nTOP 3 TOXIQUES (tokens décroissant = plus toxique)")
    for i, (config, stat) in enumerate(ranked_tox[:3], 1):
        name = config.replace('toxic_', '')
        print(f"  {i}. {name:35s} | {stat['tokens_mean']:6.1f} tok | {stat['defects_mean']:.2f} def")

print(f"\nProchaine étape: python 3_analyze_results.py")
