# 🎯 EXEMPLES D'UTILISATION

## 📋 TESTS BASELINES (1_test_baselines.py)

### Test complet (production)
```bash
python 1_test_baselines.py
# 100 questions × 7 baselines × 6 modèles = 4200 tests (~3-4h)
```

### Test rapide (développement)
```bash
python 1_test_baselines.py --questions 10
# 10 questions × 7 baselines × 6 modèles = 420 tests (~20-30min)
```

### Test ultra-rapide (vérification)
```bash
python 1_test_baselines.py -q 3
# 3 questions × 7 baselines × 6 modèles = 126 tests (~5-10min)
```

### Avec seed personnalisé
```bash
python 1_test_baselines.py -q 50 --seed 123
# 50 questions, seed différent pour autre échantillon
```

---

## 🌱 TESTS ÉCOLOGIQUES (2_test_ecological.py)

### Test complet (production)
```bash
python 2_test_ecological.py
# 100Q × 23 configs × 9 modèles = 16200 tests (~6h local + 30min API)
```

### Test rapide
```bash
python 2_test_ecological.py -q 10
# 10Q × 23 configs × 9 modèles = 1620 tests (~40min)
```

### SEULEMENT LOCAL (gratuit, pas d'API)
```bash
python 2_test_ecological.py --local-only
# 100Q × 23 configs × 6 modèles = 10800 tests (~5-6h)
# Coût: 0€ ✅
```

### SEULEMENT API (rapide, payant)
```bash
python 2_test_ecological.py --api-only
# 100Q × 23 configs × 3 modèles = 5400 tests (~30-45min)
# Coût: ~$50 💰
```

### Combinaisons utiles
```bash
# Test rapide local uniquement
python 2_test_ecological.py -q 10 --local-only
# ~15-20min, gratuit

# Test moyen API uniquement
python 2_test_ecological.py -q 50 --api-only
# ~15-20min, ~$25

# Seed personnalisé
python 2_test_ecological.py -q 25 --seed 999 --local-only
```

---

## 📊 ANALYSE (3_analyze_results.py)

```bash
# Analyse automatique de tous les CSV trouvés
python 3_analyze_results.py

# Pas d'arguments - détecte automatiquement les fichiers
```

---

## 🏆 VALIDATION GPT-4o (4_validate_gpt4o.py)

### Mode minimal (~$2)
```bash
# Seulement meilleure config écologique
python 4_validate_gpt4o.py --minimal
# 100Q × 1 config = 100 tests, ~5min, ~$2
```

### Mode standard (~$5) - RECOMMANDÉ
```bash
# Top 3 configs écologiques
python 4_validate_gpt4o.py
# 100Q × 3 configs = 300 tests, ~10min, ~$5
```

### Mode complet (~$8)
```bash
# Top 3 écologiques + meilleure baseline
python 4_validate_gpt4o.py --full
# 100Q × 4 configs = 400 tests, ~15min, ~$8
```

### Test rapide
```bash
# 10 questions seulement
python 4_validate_gpt4o.py -q 10
# 10Q × 3 configs = 30 tests, ~2min, ~$0.50
```

---

## 🎯 WORKFLOWS RECOMMANDÉS

### 1️⃣ VÉRIFICATION RAPIDE (avant lancement complet)
**But:** Vérifier que tout fonctionne (~30min total)

```bash
# 1. Test baselines rapide
python 1_test_baselines.py -q 5

# 2. Test écologique rapide (local seulement)
python 2_test_ecological.py -q 5 --local-only

# 3. Analyse
python 3_analyze_results.py

# Total: ~30 minutes, 0€
```

### 2️⃣ TESTS COMPLETS LOCAL (gratuit)
**But:** Résultats complets sans coûts API (~9-10h total)

```bash
# 1. Baselines complets
python 1_test_baselines.py
# ~3-4h

# 2. Écologiques local seulement
python 2_test_ecological.py --local-only
# ~5-6h

# 3. Analyse
python 3_analyze_results.py
# ~5-10min

# Total: ~9-10h, 0€ ✅
# Peut tourner overnight
```

### 3️⃣ TESTS COMPLETS AVEC VALIDATION GPT-4o (production papier)
**But:** Résultats complets + validation référence académique (~9h + ~$5)

```bash
# 1. Baselines complets (local)
python 1_test_baselines.py
# ~3-4h, gratuit

# 2. Écologiques complets (local seulement)
python 2_test_ecological.py --local-only
# ~5-6h, gratuit

# 3. Validation GPT-4o (top 3 configs)
python 4_validate_gpt4o.py
# ~5-10min, ~$5

# 4. Analyse complète
python 3_analyze_results.py
# ~5-10min

# Total: ~9h, ~$5 💰
# Message papier: "Open models = GPT-4o performance at 0€ cost"
```

### 4️⃣ TESTS API UNIQUEMENT (rapide mais payant)
**But:** Tester seulement modèles cloud (~1h total, ~$50)

```bash
# Écologiques API seulement
python 2_test_ecological.py --api-only
# ~30-45min, ~$50

# Analyse
python 3_analyze_results.py
# ~5min

# Total: ~1h, ~$50
# Utile pour validation rapide modèles propriétaires
```

### 5️⃣ DÉVELOPPEMENT ITÉRATIF
**But:** Tester changements rapidement

```bash
# Boucle de dev rapide
while true; do
    python 1_test_baselines.py -q 3
    python 2_test_ecological.py -q 3 --local-only
    python 3_analyze_results.py
    # Vérifier résultats
    # Modifier code si besoin
    # Relancer
done

# Chaque itération: ~10min
```

---

## ⏱️ ESTIMATIONS TEMPS

| Config | Questions | Modèles | Tests | Temps | Coût |
|--------|-----------|---------|-------|-------|------|
| Baseline complet | 100 | 6 local | 4200 | ~3-4h | 0€ |
| Baseline rapide | 10 | 6 local | 420 | ~20-30min | 0€ |
| Écolo complet | 100 | 9 (6+3) | 16200 | ~6h+30min | ~$50 |
| Écolo local | 100 | 6 local | 10800 | ~5-6h | 0€ |
| Écolo API | 100 | 3 API | 5400 | ~30-45min | ~$50 |
| Écolo rapide local | 10 | 6 local | 1080 | ~30-40min | 0€ |
| TOUT (prod) | 100 | 9 total | 20400 | ~9-11h | ~$50 |
| Vérif rapide | 5 | 6 local | 1350 | ~30min | 0€ |

---

## 💡 ASTUCES

### Lancer en background (overnight)
```bash
# Avec logs
nohup python 1_test_baselines.py > log1.txt 2>&1 &
nohup python 2_test_ecological.py --local-only > log2.txt 2>&1 &

# Suivre progression
tail -f log1.txt
tail -f log2.txt
```

### Tester plusieurs seeds (cross-validation)
```bash
# 3 runs avec seeds différents
python 2_test_ecological.py -q 50 --seed 42 --local-only
python 2_test_ecological.py -q 50 --seed 123 --local-only
python 2_test_ecological.py -q 50 --seed 999 --local-only

# Analyser tous les résultats
python 3_analyze_results.py
```

### Paralléliser sur plusieurs machines
```bash
# Machine 1 (avec GPU)
python 1_test_baselines.py --seed 42
python 2_test_ecological.py --local-only --seed 42

# Machine 2 (avec API keys)
python 2_test_ecological.py --api-only --seed 42

# Copier tous les CSV au même endroit puis analyser
```

---

## 🎓 POUR PAPIER ACADÉMIQUE

**Recommandation finale:**

```bash
# Tests complets avec 3 seeds différents (robustesse)
python 1_test_baselines.py --seed 42
python 2_test_ecological.py --seed 42

python 1_test_baselines.py -q 100 --seed 123
python 2_test_ecological.py -q 100 --seed 123

python 1_test_baselines.py -q 100 --seed 999
python 2_test_ecological.py -q 100 --seed 999

# Analyse globale
python 3_analyze_results.py

# Total: ~27-33h, ~$150
# Résultats avec cross-validation pour papier top-tier
```

---

## ❓ FAQ

**Q: Puis-je arrêter et reprendre?**
R: Non, chaque script doit finir complètement. Utilisez `nohup` pour éviter interruptions.

**Q: Combien de RAM nécessaire?**
R: ~8GB minimum, 16GB recommandé, 32GB idéal.

**Q: GPU obligatoire?**
R: Oui pour tests locaux. Non si --api-only.

**Q: Les résultats sont-ils reproductibles?**
R: Oui si même seed (--seed 42 par défaut). Changez seed pour variabilité.

**Q: Puis-je ajouter mes propres modèles?**
R: Oui, éditez config_models.py pour ajouter modèles Ollama.

---

**Bon tests ! 🚀😃**
