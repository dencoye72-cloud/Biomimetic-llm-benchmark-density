# Biomimetic Ecological Anchoring — Benchmark v2.3

Protocole de test pour le prompting biomimétique marin.

## Fichiers

### Pipeline v3 — Tests appariés (RECOMMANDÉ)

| # | Fichier | Rôle |
|---|---------|------|
| 5 | `5_test_paired.py` | 200Q appariées × 30 configs × N modèles, 4 ground truths |
| 6 | `6_analyze_paired.py` | T-tests pairés, scores GT, score composite QUALITY, LaTeX |
| 7 | `7_sensitivity_analysis.py` | Precision/Recall/F1 des détecteurs regex vs GT |
| 8 | `8_llm_judge.py` | LLM-as-Judge local (Ollama), Cohen's kappa regex vs juge vs GT |

### Pipeline v1/v2 — Tests originaux (compatibilité)

| # | Fichier | Rôle |
|---|---------|------|
| 1 | `1_test_baselines.py` | 7 baselines PE classiques |
| 2 | `2_test_ecological.py` | 14 configs positives + 9 toxiques, sampling ciblé par ancrage |
| 3 | `3_analyze_results.py` | Enrichissement métriques, agrégation, rankings, LaTeX |
| 4 | `4_validate_gpt4o.py` | Validation croisée GPT-4o |

### Configuration

| Fichier | Contenu |
|---------|---------|
| `config_prompts.py` | 30 system prompts (7 baselines + 14 positifs + 9 toxiques) |
| `config_models.py` | 9 modèles (6 locaux Ollama + 3 API) |
| `dataset_500q.py` | 500 questions, 10 ancrages × 50 |
| `benchmark_questions_500_v2.txt` | Questions en texte brut |

### Métriques et Ground Truths

| Fichier | Contenu |
|---------|---------|
| `metrics_analysis.py` | exact_match, concision_score, semantic_similarity, detect_defects, t_test, Cohen's d, bootstrap CI |
| `ground_truth_eponge.py` | 50 réponses canoniques (exactitude factuelle) |
| `ground_truth_meduse.py` | 50 questions binaires (décision tranchée) |
| `ground_truth_poisson_pierre.py` | 50 questions à entités inventées (résistance hallucination) |
| `ground_truth_synalpheus.py` | 50 questions à prémisses fausses (résistance soumission aveugle) |

### Documentation

| Fichier | Contenu |
|---------|---------|
| `INSTALLATION.md` | Guide installation complet |
| `EXEMPLES.md` | Cas d'usage et commandes |
| `RECAPITULATIF.md` | Vue d'ensemble protocole |
| `INDEX.md` | Index complet de tous les fichiers |
| `VERSION.md` | Changelog v2.2 → v2.3 |
| `CHANGELOG.md` | Changelog technique détaillé |
| `paper_template_v9.md` | Template article académique |
| `Claude_Symbiose_Eponge_Synalpheus.txt` | System prompt symbiose |

## Installation

```bash
pip install -r requirements.txt
```

## Usage rapide — Pipeline v3 (recommandé)

```bash
# Test rapide (1 bloc GT, ~2h)
python 5_test_paired.py -q 50

# Test complet (4 blocs GT, 200Q × 30 configs, ~10-12h)
python 5_test_paired.py

# Analyse appariée
python 6_analyze_paired.py

# Sensibilité regex (après analyse)
python 7_sensitivity_analysis.py

# LLM-as-Judge (optionnel, ~1h pour 500 réponses)
python 8_llm_judge.py --sample 500
```

## Usage — Pipeline v1/v2 (compatibilité)

```bash
python 1_test_baselines.py -q 10
python 2_test_ecological.py -q 10
python 3_analyze_results.py
```

## Métriques

**Ground truth (200/500 questions couvertes) :**
- **exact_match** : la réponse contient-elle la bonne réponse ? (éponge, 0/1)
- **decision_score** : réponse binaire tranchée (méduse, 0/1)
- **hallucination_score** : admet ignorance sur entité inventée (poisson-pierre, 0/1)
- **correction_score** : corrige prémisse fausse (synalpheus, 0/1)

**Qualité réponse :**
- **concision_score** : ratio tokens attendus / tokens réels (0.0–1.0)
- **detect_defects** : verbiage, anthropomorphisme, équivocation, soumission aveugle...

**Statistiques :**
- **t_test_paired** + **cohens_d** : tests statistiques publication-ready (scipy)
- **bootstrap_ci** : intervalles de confiance 95%
